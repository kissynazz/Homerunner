package com.home.automation;

import android.content.Context;
import android.os.Environment;
import android.util.Log;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.Part;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.UIDFolder;
import javax.mail.internet.MimeMultipart;
import javax.mail.search.FromStringTerm;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * EmailWatcher — Android background thread.
 *
 * Polls Gmail (IMAP SSL) every 6 s for the newest self-sent email.
 * When a NEW email arrives it:
 *   1. Extracts the body (text/plain preferred; text/html fallback).
 *   2. Strips HTML tags / decodes HTML entities (&#39; → ', &amp; → &, etc.)
 *      so the body looks like the plain-text the Python sees.
 *   3. Mirrors Python startadd loop: collect between first '$' and '@' or '/'.
 *   4. Trims at first '#'  →  mh2.
 *   5. Dispatches the ugly=[…] command to adbcom.txt.
 *
 * KEY FIXES vs. original:
 *   ① mail.imaps.ssl.trust=*  — Android rejects Gmail's cert without this; the
 *       SSL handshake fails silently (exception caught at poll level, email skipped).
 *   ② UID marked AFTER successful processing — no more silent "permanent skip"
 *       when body extraction throws an exception.
 *   ③ htmlToPlain() before extractMha — Gmail sometimes returns the HTML part;
 *       without decoding, &#39; corrupts the 'home'/'click' search, and <br>
 *       ends up inside mha.
 *   ④ Fallback search — if FROM search returns 0 messages, fetch ALL inbox msgs.
 */
public class EmailWatcher {

    private static final String TAG = "EmailWatcher";

    private static final String USER      = "nazzyburpee0@gmail.com";
    private static final String PASSWORD  = "qntc kxxr wybp bdng";
    private static final String IMAP_HOST = "imap.gmail.com";
    private static final long   POLL_MS   = 6000L;

    private static volatile long    lastProcessedUid = -1L;
    private static volatile int     seq              = 0;
    private static volatile boolean running          = false;
    private static          Thread  watcherThread    = null;

    private static String adbcomPath  = null;
    private static String lastseqPath = null;

    // ═════════════════════════════════════════════════════════════════════════
    //  Lifecycle
    // ═════════════════════════════════════════════════════════════════════════

    public static synchronized void start(Context context) {
        if (running) {
            Log.i(TAG, "Already running — ignoring duplicate start()");
            return;
        }
        File screenshots = new File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
                "Screenshots");
        screenshots.mkdirs();
        adbcomPath  = new File(screenshots, "adbcom.txt").getAbsolutePath();
        lastseqPath = new File(screenshots, "lastseq.txt").getAbsolutePath();
        seq = readSeq();
        Log.i(TAG, "=== STARTING — seq=" + seq + "  adbcom=" + adbcomPath + " ===");
        running = true;

        watcherThread = new Thread(new Runnable() {
            public void run() {
                while (running && !Thread.currentThread().isInterrupted()) {
                    try {
                        poll();
                    } catch (Exception e) {
                        Log.e(TAG, "poll error: " + e.getClass().getSimpleName()
                                   + ": " + e.getMessage());
                    }
                    try {
                        Thread.sleep(POLL_MS);
                    } catch (InterruptedException ex) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
                Log.i(TAG, "Stopped.");
            }
        }, "EmailWatcher");
        watcherThread.setDaemon(true);
        watcherThread.start();
    }

    public static synchronized void stop() {
        running = false;
        if (watcherThread != null) {
            watcherThread.interrupt();
            watcherThread = null;
        }
        Log.i(TAG, "stop() called.");
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  Core poll
    // ═════════════════════════════════════════════════════════════════════════

    private static void poll() throws Exception {
        Properties props = new Properties();
        props.put("mail.store.protocol",              "imaps");
        props.put("mail.imaps.host",                  IMAP_HOST);
        props.put("mail.imaps.port",                  "993");
        props.put("mail.imaps.ssl.enable",            "true");
        // ── FIX ①: trust Gmail's cert on Android (otherwise SSL handshake fails silently)
        props.put("mail.imaps.ssl.trust",             "*");
        props.put("mail.imaps.ssl.checkserveridentity", "false");
        props.put("mail.imaps.connectiontimeout",     "15000");
        props.put("mail.imaps.timeout",               "15000");

        Session session = Session.getInstance(props);
        Store  store = null;
        Folder inbox = null;

        try {
            store = session.getStore("imaps");
            store.connect(IMAP_HOST, USER, PASSWORD);
            inbox = store.getFolder("INBOX");
            inbox.open(Folder.READ_ONLY);

            // ── ④ Search FROM self; fall back to all messages if empty ────
            Message[] msgs = inbox.search(new FromStringTerm(USER));
            if (msgs == null || msgs.length == 0) {
                Log.d(TAG, "FROM search returned 0 — trying ALL messages");
                msgs = inbox.getMessages();
            }
            if (msgs == null || msgs.length == 0) {
                Log.d(TAG, "Inbox is empty.");
                return;
            }

            Message latest = msgs[msgs.length - 1];

            // ── UID dedup ─────────────────────────────────────────────────
            long uid;
            try {
                uid = ((UIDFolder) inbox).getUID(latest);
            } catch (Exception e) {
                // android-mail may not expose UIDFolder; fall back to msg number
                uid = latest.getMessageNumber();
            }

            if (uid == lastProcessedUid) {
                Log.d(TAG, "No new email (UID " + uid + " already processed).");
                return;
            }
            Log.i(TAG, "New email! UID=" + uid + " (previous=" + lastProcessedUid + ")");

            // ── ② Extract body BEFORE updating UID ───────────────────────
            String rawBody = extractBody(latest);
            Log.i(TAG, "rawBody(0..300)=[" + rawBody.substring(0, Math.min(300, rawBody.length())) + "]");

            // ── ③ Strip HTML / decode entities ───────────────────────────
            String plainBody = htmlToPlain(rawBody);
            Log.i(TAG, "plainBody(0..300)=[" + plainBody.substring(0, Math.min(300, plainBody.length())) + "]");

            String mha = extractMha(plainBody);
            Log.i(TAG, "mha=[" + mha + "]");

            if (mha.isEmpty()) {
                Log.w(TAG, "No '$' payload found. Body snippet: ["
                        + rawBody.substring(0, Math.min(200, rawBody.length())) + "]");
                lastProcessedUid = uid;   // mark so we stop logging this same email
                return;
            }

            String mh2 = extractMh2(mha);
            Log.i(TAG, "mh2=[" + mh2 + "]");

            processUgly(mh2);
            writeSeq(seq);

            // ── ② Record UID only after successful dispatch ───────────────
            lastProcessedUid = uid;

        } finally {
            try { if (inbox != null) inbox.close(false); } catch (Exception ignored) {}
            try { if (store != null) store.close();      } catch (Exception ignored) {}
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  Body extraction — text/plain preferred, HTML fallback
    // ═════════════════════════════════════════════════════════════════════════

    private static String extractBody(Part part) throws Exception {
        try {
            Object content = part.getContent();
            if (content instanceof String) {
                return (String) content;
            }
            if (content instanceof MimeMultipart) {
                MimeMultipart mp = (MimeMultipart) content;
                String htmlFallback = null;
                for (int i = 0; i < mp.getCount(); i++) {
                    Part bp = mp.getBodyPart(i);
                    String ct = bp.getContentType().toLowerCase();
                    if (ct.startsWith("text/plain")) return extractBody(bp);
                    if (ct.startsWith("text/html"))  htmlFallback = extractBody(bp);
                }
                if (htmlFallback != null) return htmlFallback;
            }
            if (content instanceof InputStream) {
                InputStream is = (InputStream) content;
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = is.read(buf)) != -1) baos.write(buf, 0, n);
                return baos.toString("UTF-8");
            }
            return content.toString();
        } catch (Exception e) {
            Log.e(TAG, "extractBody error: " + e.getMessage());
            return "";
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  FIX ③ — HTML → plain text
    //
    //  The Python script receives raw RFC 2822 bytes and does a string search,
    //  so HTML entities like &#39; appear as literal characters that the Python
    //  exec() never sees (it reads the plain-text MIME part).  When the Java
    //  getContent() returns the HTML part instead (multipart with no text/plain),
    //  HTML entities corrupt mha.  Convert to plain text first.
    // ═════════════════════════════════════════════════════════════════════════

    private static String htmlToPlain(String html) {
        // Fast path: no HTML present
        if (html.indexOf('<') < 0 && html.indexOf('&') < 0) return html;

        // <br> variants → newline
        String s = html
                .replace("<br>",   "\n")
                .replace("<BR>",   "\n")
                .replace("<br/>",  "\n")
                .replace("<BR/>",  "\n")
                .replace("<br />", "\n")
                .replace("<BR />", "\n");

        // Strip all remaining tags
        StringBuffer sb = new StringBuffer();
        boolean inTag = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '<') { inTag = true; continue; }
            if (c == '>') { inTag = false; continue; }
            if (!inTag) sb.append(c);
        }
        s = sb.toString();

        // Decode HTML entities (order matters: &amp; last)
        s = s.replace("&#39;",  "'")
             .replace("&quot;", "\"")
             .replace("&lt;",   "<")
             .replace("&gt;",   ">")
             .replace("&nbsp;", " ")
             .replace("&amp;",  "&");

        return s;
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  extractMha — mirrors Python startadd loop exactly
    //
    //  Python sends:  #Message_you_need_to_send2$ugly=['home']$\n#$$##@@
    //  We collect everything between the first '$' and first '@' or '/'.
    //  Spaces (0x20) are stripped; all other chars kept (matches Python).
    //  A second '$' simply resets startadd=1 and continues (Python behaviour).
    // ═════════════════════════════════════════════════════════════════════════

    private static String extractMha(String data) {
        // Mirror Python: find "ltr", skip +5, clip at </div>
        // If not found, use the whole body (better than Python's data[4:] quirk)
        String data2;
        int ltrIdx = data.indexOf("ltr");
        if (ltrIdx >= 0) {
            int start = Math.min(ltrIdx + 5, data.length());
            data2 = data.substring(start);
            int divEnd = data2.indexOf("</div>");
            if (divEnd >= 0) data2 = data2.substring(0, divEnd);
        } else {
            data2 = data;
        }

        // Only parse if '$' is present (mirrors Python's 'if "$" in data2')
        if (data2.indexOf('$') < 0) return "";

        int startAdd = 0;
        StringBuffer mha = new StringBuffer();
        for (int i = 0; i < data2.length(); i++) {
            char c = data2.charAt(i);
            if (c == '$') {
                startAdd = 1;
                continue;
            }
            if (startAdd == 1) {
                if (c == '@' || c == '/') break;
                if (c != ' ')            mha.append(c);
            }
        }
        return mha.toString();
    }

    // ── mh2: mha up to first '#', trailing newlines stripped ─────────────────

    private static String extractMh2(String mha) {
        int hashIdx = mha.indexOf('#');
        String raw = (hashIdx >= 0) ? mha.substring(0, hashIdx) : mha;
        // Strip trailing \r\n that collect after the second '$' in the message
        int end = raw.length();
        while (end > 0 && (raw.charAt(end - 1) == '\n' || raw.charAt(end - 1) == '\r')) end--;
        return raw.substring(0, end);
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  Command dispatcher (replaces Python exec(mh2) + if ugly[0]==... chain)
    // ═════════════════════════════════════════════════════════════════════════

    private static void processUgly(String mh2) throws Exception {
        String cmd = parseUglyCommand(mh2);
        Log.i(TAG, "ugly command='" + cmd + "'  (mh2=[" + mh2 + "])");

        if (cmd == null) {
            Log.w(TAG, "Could not identify command in: [" + mh2 + "]");
            return;
        }

        if ("home".equals(cmd)) {
            Thread.sleep(2000);
            seq++;
            writeAdbcom("3 " + seq);

        } else if ("screen".equals(cmd)) {
            Thread.sleep(2000);
            seq++;
            writeAdbcom("7 " + seq);

        } else if ("didstart".equals(cmd)) {
            seq++;
            writeAdbcom("3" + seq);
            Thread.sleep(2000);
            seq++;
            writeAdbcom("tap 100 500 " + seq);

        } else if ("click".equals(cmd)) {
            int[] xy = parseClickCoords(mh2);
            if (xy != null) {
                Thread.sleep(2000);
                seq++;
                writeAdbcom("tap " + xy[0] + " " + xy[1] + " " + seq);
            } else {
                Log.w(TAG, "click: could not parse coords from: " + mh2);
            }

        } else if ("sol".equals(cmd) || "checkscreen".equals(cmd)
                || "verse".equals(cmd) || "multi".equals(cmd)) {
            Log.i(TAG, "'" + cmd + "' — no adbcom action defined.");

        } else {
            Log.w(TAG, "Unhandled command: " + cmd);
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  Parsing helpers
    // ═════════════════════════════════════════════════════════════════════════

    /**
     * Finds the command name in ugly=['home'] or ugly=["click",[x,y]].
     * After htmlToPlain(), single quotes are literal ' so this just works.
     */
    private static String parseUglyCommand(String mh2) {
        String[] known = { "home", "screen", "click", "didstart",
                           "sol", "verse", "checkscreen", "multi" };
        String lower = mh2.toLowerCase();
        for (int i = 0; i < known.length; i++) {
            if (lower.contains("'" + known[i] + "'")
                    || lower.contains("\"" + known[i] + "\"")) {
                return known[i];
            }
        }
        return null;
    }

    /** Extracts [x, y] from ugly=['click',[540,1000]] */
    private static int[] parseClickCoords(String mh2) {
        int clickPos = mh2.toLowerCase().indexOf("click");
        if (clickPos < 0) return null;
        int open  = mh2.indexOf('[', clickPos);
        if (open  < 0) return null;
        int close = mh2.indexOf(']', open);
        if (close < 0) return null;
        String[] parts = mh2.substring(open + 1, close).trim().split(",");
        if (parts.length < 2) return null;
        try {
            return new int[]{
                Integer.parseInt(parts[0].trim()),
                Integer.parseInt(parts[1].trim())
            };
        } catch (NumberFormatException e) {
            return null;
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  File helpers
    // ═════════════════════════════════════════════════════════════════════════

    private static void writeAdbcom(String line) throws IOException {
        FileWriter fw = null;
        try {
            fw = new FileWriter(adbcomPath);
            fw.write(line);
        } finally {
            if (fw != null) try { fw.close(); } catch (IOException ignored) {}
        }
        Log.i(TAG, "adbcom.txt <- \"" + line + "\"");
    }

    private static int readSeq() {
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(lastseqPath));
            return Integer.parseInt(br.readLine().trim());
        } catch (Exception e) {
            return 0;
        } finally {
            if (br != null) try { br.close(); } catch (IOException ignored) {}
        }
    }

    private static void writeSeq(int s) throws IOException {
        FileWriter fw = null;
        try {
            fw = new FileWriter(lastseqPath);
            fw.write(String.valueOf(s));
        } finally {
            if (fw != null) try { fw.close(); } catch (IOException ignored) {}
        }
    }
}
