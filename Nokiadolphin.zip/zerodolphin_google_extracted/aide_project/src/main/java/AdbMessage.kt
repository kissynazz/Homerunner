package com.home.automation

import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * ADB wire-protocol message.
 * Header is always 24 bytes (6 × little-endian INT32), followed by optional data.
 */
class AdbMessage(
    val command    : Int,
    val arg0       : Int,
    val arg1       : Int,
    val data_length: Int     = 0,
    val data_crc32 : Int     = 0,
    val magic      : Int     = command xor -1,
    val data       : ByteArray? = null
) {
    companion object {
        const val HEADER_LENGTH = 24

        fun create(command: Int, arg0: Int, arg1: Int, data: ByteArray?): AdbMessage {
            val crc = crc32(data)
            return AdbMessage(command, arg0, arg1, data?.size ?: 0, crc, command xor -1, data)
        }

        fun create(command: Int, arg0: Int, arg1: Int, text: String): AdbMessage =
            create(command, arg0, arg1, "$text\u0000".toByteArray(Charsets.UTF_8))

        private fun crc32(data: ByteArray?): Int {
            if (data == null) return 0
            var res = 0
            for (b in data) res += if (b >= 0) b.toInt() else b.toInt() + 256
            return res
        }
    }

    /** Throws if the magic does not match (corrupt packet). */
    fun validateOrThrow() {
        if (magic != (command xor -1)) throw IOException("ADB bad magic: cmd=0x${command.toString(16)} magic=0x${magic.toString(16)}")
    }

    fun toByteArray(): ByteArray {
        val buf = ByteBuffer.allocate(HEADER_LENGTH + (data?.size ?: 0)).order(ByteOrder.LITTLE_ENDIAN)
        buf.putInt(command).putInt(arg0).putInt(arg1)
            .putInt(data_length).putInt(data_crc32).putInt(magic)
        data?.let { buf.put(it) }
        return buf.array()
    }

    fun toStringShort(): String {
        val name = when (command) {
            AdbProtocol.A_CNXN -> "A_CNXN"; AdbProtocol.A_AUTH -> "A_AUTH"
            AdbProtocol.A_OPEN -> "A_OPEN"; AdbProtocol.A_OKAY -> "A_OKAY"
            AdbProtocol.A_CLSE -> "A_CLSE"; AdbProtocol.A_WRTE -> "A_WRTE"
            AdbProtocol.A_STLS -> "A_STLS"
            else -> "0x${command.toString(16)}"
        }
        return "$name arg0=$arg0 arg1=$arg1 len=$data_length"
    }
}
