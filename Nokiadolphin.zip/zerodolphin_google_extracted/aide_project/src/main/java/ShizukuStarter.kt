package com.home.automation

import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.Toast

private const val TAG = "ShizukuStarter"
private const val SHIZUKU_PKG = "moe.shizuku.privileged.api"

/**
 * Starts the Shizuku privileged server so that GamepadManager (via reflection)
 * can use dev.rikka.shizuku.Shizuku to open /dev/uinput for the virtual controller.
 *
 * Two start paths — try root first, fall back to wireless ADB:
 *
 *   ROOT PATH  — works on rooted devices even without wireless debugging.
 *                Runs `su -c <libshizuku.so> --apk=<shizuku.apk>` in a background thread.
 *
 *   ADB PATH   — works on stock devices with wireless debugging enabled (Android 11+).
 *                Connects to the ADB daemon on 127.0.0.1:<port>, authenticates with
 *                our stored RSA-2048 key, and runs the same shell command over the wire.
 *                Port is shown in Developer Options → Wireless debugging.
 *
 * Usage from MainActivity:
 *
 *   ShizukuStarter.startWithRoot(this)
 *   // or
 *   ShizukuStarter.startWithAdb(this, port = 12345)
 */
object ShizukuStarter {

    // ── Public API ────────────────────────────────────────────────────────────

    /** Returns true if the Shizuku binder is currently alive (server running). */
    fun isRunning(): Boolean = reflectPingBinder()

    /** Human-readable status string for the UI. */
    fun status(ctx: Context): String {
        val installed = isInstalled(ctx)
        if (!installed) return "Shizuku not installed.\nInstall from Play Store → search 'Shizuku'."
        return if (isRunning()) "✓ Shizuku server RUNNING — virtual controller active"
               else            "✗ Shizuku server NOT running — tap a start button below"
    }

    /**
     * Start the Shizuku server via root (su).
     * Works on rooted devices.  Call from any thread.
     */
    fun startWithRoot(ctx: Context) {
        val cmd = serverCommand(ctx) ?: run {
            toast(ctx, "Shizuku not installed"); return
        }
        Thread({
            try {
                val proc = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
                val out  = proc.inputStream.bufferedReader().readText()
                val err  = proc.errorStream.bufferedReader().readText()
                proc.waitFor()
                Log.i(TAG, "su exit=${proc.exitValue()} stdout=[$out] stderr=[$err]")
                val ok = isRunning()
                toast(ctx, if (ok) "✓ Shizuku started (root)" else "✗ Root start failed — are you rooted?")
            } catch (e: Exception) {
                Log.e(TAG, "startWithRoot: ${e.message}")
                toast(ctx, "Root start error: ${e.message}")
            }
        }, "ShizukuStarter-root").also { it.isDaemon = true; it.start() }
    }

    /**
     * Start the Shizuku server via wireless ADB.
     *
     * @param port  TCP port shown in Developer Options → Wireless debugging.
     *
     * The ADB RSA key pair is stored in SharedPreferences and reused across
     * launches.  On first use the device will prompt "Allow ADB debugging?" —
     * tap Allow to authorise, then call this method again.
     */
    fun startWithAdb(ctx: Context, port: Int) {
        val cmd = serverCommand(ctx) ?: run {
            toast(ctx, "Shizuku not installed"); return
        }
        val prefs = ctx.getSharedPreferences("homerunner_adb", Context.MODE_PRIVATE)
        val key   = AdbKey(prefs, "homerunner")

        Thread({
            val sb = StringBuilder()
            try {
                toast(ctx, "Connecting to ADB on port $port…")
                AdbClient("127.0.0.1", port, key).use { client ->
                    client.connect()
                    Log.i(TAG, "ADB connected, running: $cmd")
                    client.shellCommand(cmd) { bytes ->
                        sb.append(String(bytes, Charsets.UTF_8))
                    }
                }
                Log.i(TAG, "ADB shell done. output=[$sb]")
                Thread.sleep(1500)   // give the server a moment to bind
                val ok = isRunning()
                toast(ctx, if (ok) "✓ Shizuku started (ADB)" else "✗ ADB start returned but server not yet alive — try again")
            } catch (e: Exception) {
                Log.e(TAG, "startWithAdb: ${e.message}")
                val hint = when {
                    e.message?.contains("refused", ignoreCase = true) == true ->
                        "Connection refused — enable wireless debugging in Developer Options, port=$port"
                    e.message?.contains("handshake", ignoreCase = true) == true ||
                    e.message?.contains("SSL",       ignoreCase = true) == true ->
                        "TLS error — pair first in Shizuku app or in Developer Options → Pair device with code"
                    e.message?.contains("authoris", ignoreCase = true) == true ||
                    e.message?.contains("A_CNXN",   ignoreCase = true) == true ->
                        "Not authorised — tap 'Allow' on the 'Allow ADB debugging?' popup that appears on screen"
                    else -> e.message ?: "Unknown error"
                }
                toast(ctx, "ADB error: $hint")
            }
        }, "ShizukuStarter-adb").also { it.isDaemon = true; it.start() }
    }

    // ── Internal helpers ──────────────────────────────────────────────────────

    /** Build `<native_lib_path>/libshizuku.so --apk=<apk_path>` from the installed Shizuku package. */
    private fun serverCommand(ctx: Context): String? {
        return try {
            val info = ctx.packageManager.getPackageInfo(SHIZUKU_PKG, 0)
            val lib  = info.applicationInfo.nativeLibraryDir + "/libshizuku.so"
            val apk  = info.applicationInfo.sourceDir
            "$lib --apk=$apk"
        } catch (e: PackageManager.NameNotFoundException) {
            Log.e(TAG, "Shizuku package not found")
            null
        }
    }

    private fun isInstalled(ctx: Context): Boolean = try {
        ctx.packageManager.getPackageInfo(SHIZUKU_PKG, 0)
        true
    } catch (_: PackageManager.NameNotFoundException) { false }

    /** Shizuku.pingBinder() via reflection — no compile-time dependency. */
    private fun reflectPingBinder(): Boolean = try {
        Class.forName("dev.rikka.shizuku.Shizuku")
            .getMethod("pingBinder")
            .invoke(null) as? Boolean ?: false
    } catch (_: Exception) { false }

    private fun toast(ctx: Context, msg: String) {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
        }
    }
}
