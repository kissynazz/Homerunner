package com.home.automation

import android.content.SharedPreferences
import android.util.Base64
import android.util.Log
import java.io.ByteArrayInputStream
import java.math.BigInteger
import java.net.Socket
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.*
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.interfaces.RSAPublicKey
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.X509TrustManager

private const val TAG = "AdbKey"
private const val PREF_PRIV = "adb_priv_key"
private const val PREF_PUB  = "adb_pub_key"

private const val ANDROID_PUBKEY_MODULUS_SIZE       = 256   // bytes, RSA-2048
private const val ANDROID_PUBKEY_MODULUS_SIZE_WORDS = 64    // 256 / 4
private const val RSA_PUBLIC_KEY_SIZE               = 524   // full ADB struct size

/**
 * RSA-2048 key pair used for ADB authentication.
 *
 * Stored as base64 PKCS8/X509 bytes in SharedPreferences — no BouncyCastle,
 * no AndroidKeyStore, no external deps beyond standard Java crypto.
 *
 * Signing uses RSA/ECB/NoPadding with a manually-prepended PKCS#1 v1.5 + SHA1
 * DigestInfo block, exactly as AOSP adb_auth.cpp verifies (RSA_PKCS1_SHA1_PADDING).
 *
 * The TLS SSLContext uses the same key pair with a minimal self-signed X.509 v3
 * certificate generated from pure DER encoding (no BouncyCastle).
 */
class AdbKey(prefs: SharedPreferences, @Suppress("UNUSED_PARAMETER") name: String) {

    // ── PKCS#1 v1.5 type-1 prefix for RSA-2048 + SHA1 DigestInfo ────────────
    // = 0x00 0x01 [0xFF × 218] 0x00 [SHA1 DigestInfo 15 bytes]
    // Total = 236 bytes; + 20-byte token = 256 bytes (full RSA-2048 block).
    private val pkcs1Sha1Prefix: ByteArray by lazy {
        val buf = ByteArray(236)
        buf[0] = 0x00; buf[1] = 0x01
        for (i in 2..219) buf[i] = 0xFF.toByte()
        buf[220] = 0x00
        // SHA1 DigestInfo: SEQUENCE { SEQUENCE { OID sha1, NULL }, OCTET STRING (len 20) }
        val info = byteArrayOf(0x30,0x21,0x30,0x09,0x06,0x05,0x2b.toByte(),0x0e,0x03,0x02,0x1a,0x05,0x00,0x04,0x14)
        info.copyInto(buf, 221)
        buf
    }

    // ── Key pair ─────────────────────────────────────────────────────────────
    private val keyPair: KeyPair = run {
        val privB64 = prefs.getString(PREF_PRIV, null)
        if (privB64 != null) {
            try {
                val priv = KeyFactory.getInstance("RSA").generatePrivate(
                    PKCS8EncodedKeySpec(Base64.decode(privB64, Base64.NO_WRAP)))
                val pub = KeyFactory.getInstance("RSA").generatePublic(
                    X509EncodedKeySpec(Base64.decode(prefs.getString(PREF_PUB, "")!!, Base64.NO_WRAP)))
                KeyPair(pub, priv)
            } catch (e: Exception) {
                Log.w(TAG, "Stored key invalid, regenerating: ${e.message}")
                generateAndStore(prefs)
            }
        } else {
            generateAndStore(prefs)
        }
    }

    private fun generateAndStore(prefs: SharedPreferences): KeyPair {
        val kp = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
        prefs.edit()
            .putString(PREF_PRIV, Base64.encodeToString(kp.private.encoded, Base64.NO_WRAP))
            .putString(PREF_PUB,  Base64.encodeToString(kp.public.encoded,  Base64.NO_WRAP))
            .apply()
        Log.i(TAG, "Generated new RSA-2048 ADB key pair")
        return kp
    }

    // ── Signing ───────────────────────────────────────────────────────────────

    /**
     * Sign the 20-byte ADB auth token.
     * Produces a 256-byte RSA PKCS#1 v1.5 SHA1 signature (raw RSA with manual padding).
     */
    fun sign(token: ByteArray): ByteArray {
        val block = pkcs1Sha1Prefix + token   // 236 + 20 = 256 bytes
        val cipher = Cipher.getInstance("RSA/ECB/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, keyPair.private)
        return cipher.doFinal(block)
    }

    // ── ADB public key encoding ───────────────────────────────────────────────

    /**
     * Encodes the RSA public key in the ADB format used for the RSAPUBLICKEY auth message.
     * Mirrors the C struct: { modulus_size_words, n0inv, modulus[64], rr[64], exponent }.
     */
    val adbPublicKey: ByteArray get() {
        val pub = keyPair.public as RSAPublicKey
        val r32 = BigInteger.ZERO.setBit(32)
        val n0inv = pub.modulus.remainder(r32).modInverse(r32).negate()
        val r = BigInteger.ZERO.setBit(ANDROID_PUBKEY_MODULUS_SIZE * 8)
        val rr = r.modPow(BigInteger.valueOf(2), pub.modulus)

        val buf = ByteBuffer.allocate(RSA_PUBLIC_KEY_SIZE).order(ByteOrder.LITTLE_ENDIAN)
        buf.putInt(ANDROID_PUBKEY_MODULUS_SIZE_WORDS)
        buf.putInt(n0inv.toInt())
        adbEncode(pub.modulus).forEach  { buf.putInt(it) }
        adbEncode(rr).forEach           { buf.putInt(it) }
        buf.putInt(pub.publicExponent.toInt())

        val b64 = Base64.encode(buf.array(), Base64.NO_WRAP)
        val nameBytes = " homerunner\u0000".toByteArray(Charsets.UTF_8)
        return b64 + nameBytes
    }

    private fun adbEncode(n: BigInteger): IntArray {
        val r32 = BigInteger.ZERO.setBit(32)
        val encoded = IntArray(ANDROID_PUBKEY_MODULUS_SIZE_WORDS)
        var tmp = n
        for (i in 0 until ANDROID_PUBKEY_MODULUS_SIZE_WORDS) {
            val (q, rem) = tmp.divideAndRemainder(r32)
            tmp = q; encoded[i] = rem.toInt()
        }
        return encoded
    }

    // ── TLS SSLContext ────────────────────────────────────────────────────────

    /**
     * Builds an SSLContext for TLS ADB (Android 9+).
     * Uses a minimal self-signed X.509 v3 cert — no BouncyCastle required.
     * The TrustManager accepts any server cert (ADB doesn't use CA chains).
     */
    val sslContext: SSLContext get() {
        val cert = buildMinimalSelfSignedCert(keyPair)
        val ks = KeyStore.getInstance("PKCS12").apply { load(null) }
        ks.setKeyEntry("key", keyPair.private, null, arrayOf(cert))

        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm())
        kmf.init(ks, null)

        val trustAll = arrayOf<javax.net.ssl.TrustManager>(object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<java.security.cert.X509Certificate>?, t: String?) {}
            override fun checkServerTrusted(chain: Array<java.security.cert.X509Certificate>?, t: String?) {}
            override fun getAcceptedIssuers() = arrayOf<java.security.cert.X509Certificate>()
        })

        return SSLContext.getInstance("TLSv1.2").apply { init(kmf.keyManagers, trustAll, null) }
    }

    // ── Minimal self-signed X.509 v3 cert (pure DER encoding) ────────────────

    private fun buildMinimalSelfSignedCert(kp: KeyPair): X509Certificate {
        // --- DER helper lambdas ---
        fun lenOf(n: Int) = when {
            n < 128 -> byteArrayOf(n.toByte())
            n < 256 -> byteArrayOf(0x81.toByte(), n.toByte())
            else    -> byteArrayOf(0x82.toByte(), (n ushr 8).toByte(), (n and 0xFF).toByte())
        }
        fun tlv(tag: Int, v: ByteArray) = byteArrayOf(tag.toByte()) + lenOf(v.size) + v
        fun seq(v: ByteArray)  = tlv(0x30, v)
        fun set(v: ByteArray)  = tlv(0x31, v)
        fun ctx0(v: ByteArray) = tlv(0xA0, v)
        fun bitStr(v: ByteArray) = tlv(0x03, byteArrayOf(0) + v)
        fun oid(vararg b: Int)   = tlv(0x06, b.map { it.toByte() }.toByteArray())
        fun utf8(s: String)      = tlv(0x0C, s.toByteArray(Charsets.UTF_8))
        fun utcTime(s: String)   = tlv(0x17, s.toByteArray(Charsets.US_ASCII))
        fun intDer(n: Int): ByteArray {
            val bytes = mutableListOf<Byte>()
            var v = n
            do { bytes.add(0, (v and 0xFF).toByte()); v = v ushr 8 } while (v > 0)
            if (bytes[0].toInt() and 0x80 != 0) bytes.add(0, 0)
            return tlv(0x02, bytes.toByteArray())
        }

        // --- OIDs ---
        val sha256RsaOid = oid(0x2A, 0x86, 0x48, 0x86, 0xF7.toByte().toInt(), 0x0D, 0x01, 0x01, 0x0B)
        val cnOid        = oid(0x55, 0x04, 0x03)
        val nullV        = byteArrayOf(0x05, 0x00)
        val sigAlg       = seq(sha256RsaOid + nullV)

        // issuer / subject: SEQUENCE { SET { SEQUENCE { OID(cn), UTF8("homerunner") } } }
        val rdnName = seq(set(seq(cnOid + utf8("homerunner"))))

        // TBSCertificate
        val tbs = seq(
            ctx0(intDer(2)) +          // version v3 (explicit tag [0])
            intDer(1) +                // serialNumber 1
            sigAlg +                   // signatureAlgorithm
            rdnName +                  // issuer
            seq(utcTime("700101000000Z") + utcTime("491231235959Z")) + // validity
            rdnName +                  // subject
            kp.public.encoded          // subjectPublicKeyInfo (already DER SEQUENCE)
        )

        // Sign TBS with SHA256withRSA
        val sig = Signature.getInstance("SHA256withRSA").run {
            initSign(kp.private); update(tbs); sign()
        }

        // Certificate = SEQUENCE { TBS, signatureAlgorithm, BIT STRING(signature) }
        val certDer = seq(tbs + sigAlg + bitStr(sig))

        return CertificateFactory.getInstance("X.509")
            .generateCertificate(ByteArrayInputStream(certDer)) as X509Certificate
    }
}
