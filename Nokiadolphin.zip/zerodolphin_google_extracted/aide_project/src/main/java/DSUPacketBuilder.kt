package com.home.automation

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.CRC32

/**
 * Builds standard cemuhook DSU protocol data packets for Dolphin.
 * Fixed: Explicit byte array literal casting and explicit array-index CRC mutation.
 */
class DSUPacketBuilder {

    private var packetCounter = 0

    /** All gamepad state fields are volatile for thread safety. */
    class GamepadState {
        // Face buttons
        @Volatile var btnA   = false   // Cross / A
        @Volatile var btnB   = false   // Circle / B
        @Volatile var btnX   = false   // Triangle / X
        @Volatile var btnY   = false   // Square / Y
        // Shoulder / trigger
        @Volatile var btnL1  = false
        @Volatile var btnR1  = false
        @Volatile var btnL2d = false   // L2 digital
        @Volatile var btnR2d = false   // R2 digital
        @Volatile var triggerL: Byte = 0   // L2 analog
        @Volatile var triggerR: Byte = 0   // R2 analog
        // D-pad
        @Volatile var dpadUp    = false
        @Volatile var dpadDown  = false
        @Volatile var dpadLeft  = false
        @Volatile var dpadRight = false
        // Centre buttons
        @Volatile var btnSelect = false
        @Volatile var btnStart  = false
        @Volatile var btnL3     = false
        @Volatile var btnR3     = false
        // Sticks (0x80 = centre)
        @Volatile var leftStickX:  Byte = 0x80.toByte()
        @Volatile var leftStickY:  Byte = 0x80.toByte()
        @Volatile var rightStickX: Byte = 0x80.toByte()
        @Volatile var rightStickY: Byte = 0x80.toByte()
    }

    /**
     * Builds a full 100-byte DSU "Controller Data" packet from current gamepad state.
     * Enforcing 100 bytes adds safety margins for trailing motion state alignments.
     * @return ready-to-send byte array with CRC32 already set.
     */
    fun buildDataPacket(state: GamepadState): ByteArray {
        val packet = ByteArray(100)
        val buf = ByteBuffer.wrap(packet)
        buf.order(ByteOrder.LITTLE_ENDIAN)

        // ── HEADER (16 bytes total including message type block) ──────────
        buf.put(byteArrayOf(0x44, 0x53, 0x55, 0x53))   // Magic: "DSUS"
        buf.putShort(1001)                             // Protocol version
        buf.putShort(92)                               // Remaining length = 100 - 8
        buf.putInt(0)                                  // CRC placeholder (Bytes 8-11)
        buf.putInt(0x444F4C50)                         // Server ID ("DOLP")

        // ── MESSAGE TYPE ──
        buf.putInt(0x00001001)                         // Msg Type: Data Reply

        // ── CONTROLLER INFO (12 bytes) ────────────────────────────────────
        buf.put(0.toByte())                            // Slot = 0 (Controller 1 index)
        buf.put(2.toByte())                            // State: Connected
        buf.put(2.toByte())                            // Model: Full Gamepad
        buf.put(2.toByte())                            // Connection: Bluetooth
        
        // Explicit byte casts for signed range support
        buf.put(byteArrayOf(0x00.toByte(), 0x1A.toByte(), 0x7D.toByte(), 0xDA.toByte(), 0x71.toByte(), 0x11.toByte())) 
        
        buf.put(5.toByte())                            // Battery: Full
        buf.put(1.toByte())                            // Is active

        // ── PACKET SEQUENCE ───────────────────────────────────────────────
        buf.putInt(packetCounter++)

        // ── DIGITAL BUTTONS ───────────────────────────────────────────────
        var b1: Byte = 0
        var b2: Byte = 0

        if (state.dpadUp)    b1 = (b1.toInt() or 0x10).toByte()
        if (state.dpadRight) b1 = (b1.toInt() or 0x20).toByte()
        if (state.dpadDown)  b1 = (b1.toInt() or 0x40).toByte()
        if (state.dpadLeft)  b1 = (b1.toInt() or 0x80).toByte()
        if (state.btnStart)  b1 = (b1.toInt() or 0x08).toByte()
        if (state.btnSelect) b1 = (b1.toInt() or 0x01).toByte()
        if (state.btnL3)     b1 = (b1.toInt() or 0x02).toByte()
        if (state.btnR3)     b1 = (b1.toInt() or 0x04).toByte()

        if (state.btnY)   b2 = (b2.toInt() or 0x80).toByte()  // Square
        if (state.btnA)   b2 = (b2.toInt() or 0x40).toByte()  // Cross
        if (state.btnB)   b2 = (b2.toInt() or 0x20).toByte()  // Circle
        if (state.btnX)   b2 = (b2.toInt() or 0x10).toByte()  // Triangle
        if (state.btnR1)  b2 = (b2.toInt() or 0x08).toByte()
        if (state.btnL1)  b2 = (b2.toInt() or 0x04).toByte()
        if (state.btnR2d) b2 = (b2.toInt() or 0x02).toByte()
        if (state.btnL2d) b2 = (b2.toInt() or 0x01).toByte()

        buf.put(b1)
        buf.put(b2)
        buf.put(0.toByte())   // Home
        buf.put(0.toByte())   // Touchpad

        // ── ANALOG STICKS ─────────────────────────────────────────────────
        buf.put(state.leftStickX)
        buf.put(state.leftStickY)
        buf.put(state.rightStickX)
        buf.put(state.rightStickY)

        // ── ANALOG PRESSURE BUTTONS ───────────────────────────────────────
        buf.put(if (state.dpadLeft)  0xFF.toByte() else 0)
        buf.put(if (state.dpadDown)  0xFF.toByte() else 0)
        buf.put(if (state.dpadRight) 0xFF.toByte() else 0)
        buf.put(if (state.dpadUp)    0xFF.toByte() else 0)
        buf.put(if (state.btnA)      0xFF.toByte() else 0)
        buf.put(if (state.btnB)      0xFF.toByte() else 0)
        buf.put(if (state.btnY)      0xFF.toByte() else 0)
        buf.put(if (state.btnX)      0xFF.toByte() else 0)
        buf.put(if (state.btnR1)     0xFF.toByte() else 0)
        buf.put(if (state.btnL1)     0xFF.toByte() else 0)
        buf.put(state.triggerR)
        buf.put(state.triggerL)

        // ── GYRO / ACCEL (zeros) ──────────────────────────────────────────
        while (buf.hasRemaining()) buf.put(0.toByte())

        // ── CRC32 INJECTION ──
        applyCRC(packet)
        return packet
    }

    /**
     * Builds a corrected 32-byte "Controller Info" response packet.
     * Handshakes cleanly with Dolphin's background polling checks.
     */
    fun buildInfoPacket(): ByteArray {
        val packet = ByteArray(32)
        val buf = ByteBuffer.wrap(packet)
        buf.order(ByteOrder.LITTLE_ENDIAN)

        // Header
        buf.put(byteArrayOf(0x44, 0x53, 0x55, 0x53))   // Magic MUST be "DSUS"
        buf.putShort(1001)
        buf.putShort(24)                               // Payload size = 32 - 8
        buf.putInt(0)                                  // CRC Spaceholder
        buf.putInt(0x444F4C50)                         // Server ID ("DOLP")

        // Payload
        buf.putInt(0x00001000)                         // Message Type: Info Reply
        buf.put(0.toByte())                            // Slot = 0 (Controller 1 index)
        buf.put(2.toByte())                            // State: Connected
        buf.put(2.toByte())                            // Model: Full Gamepad
        buf.put(1.toByte())                            // Connection: USB style
        
        // Explicit byte casts for signed range support
        buf.put(byteArrayOf(0x00.toByte(), 0x1A.toByte(), 0x7D.toByte(), 0xDA.toByte(), 0x71.toByte(), 0x11.toByte()))
        
        buf.put(5.toByte())                            // Battery: Charged
        buf.put(0.toByte())                            // Padding byte to hit exactly 32 bytes

        applyCRC(packet)
        return packet
    }

    /**
     * Internal helper method to compute the CRC32 algorithm across the active payload
     * array block and safely mutate the target array indices directly.
     */
    private fun applyCRC(packet: ByteArray) {
        val crc = CRC32()
        crc.update(packet)
        val cv = crc.value.toInt()
        
        // Explicitly target and mutate the exact indices (8, 9, 10, 11) of the array
        packet[8]  = (cv        and 0xFF).toByte()
        packet[9]  = (cv ushr  8 and 0xFF).toByte()
        packet[10] = (cv ushr 16 and 0xFF).toByte()
        packet[11] = (cv ushr 24 and 0xFF).toByte()
    }
}
