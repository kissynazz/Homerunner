package com.home.automation

import android.util.Log
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Singleton DSU/cemuhook UDP server.
 * Fixes applied: Endian-safe packet handling, optimized info payload slicing, and reuse address handling.
 */
class DolphinInputServer private constructor() {

    companion object {
        private const val TAG      = "DolphinInputServer"
        private const val DSU_PORT = 26760

        @Volatile private var INSTANCE: DolphinInputServer? = null

        @JvmStatic
        fun getInstance(): DolphinInputServer =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: DolphinInputServer().also { INSTANCE = it }
            }
    }

    // ── State ──────────────────────────────────────────────────────────────
    private val builder = DSUPacketBuilder()
    private val state   = DSUPacketBuilder.GamepadState()

    @Volatile private var socket: DatagramSocket? = null
    @Volatile private var isRunning = false
    private var serverThread: Thread? = null

    // Last known Dolphin address — so we can push data unprompted
    @Volatile private var dolphinAddr: InetAddress? = null
    @Volatile private var dolphinPort: Int = -1

    // ── Lifecycle ──────────────────────────────────────────────────────────

    @Synchronized
    fun start() {
        if (isRunning) return
        isRunning = true
        serverThread = Thread(::serverLoop).apply {
            name = "DolphinInputServer"
            isDaemon = true
            start()
        }
        Log.i(TAG, "DSU server started on port $DSU_PORT")
    }

    @Synchronized
    fun stop() {
        isRunning = false
        socket?.takeIf { !it.isClosed }?.close()
        serverThread?.interrupt()
        serverThread = null
        Log.i(TAG, "DSU server stopped")
    }

    // ── Server loop ────────────────────────────────────────────────────────

    private fun serverLoop() {
        try {
            socket = DatagramSocket(DSU_PORT).apply {
                reuseAddress = true // Allows rapid rebinding on application hot-swaps and rebuilds
            }
            val inBuf = ByteArray(1024)
            while (isRunning) {
                val req = DatagramPacket(inBuf, inBuf.size)
                socket!!.receive(req)   // blocks until Dolphin pings
                handlePacket(req)
            }
        } catch (e: Exception) {
            if (isRunning) Log.e(TAG, "Server loop error: ${e.message}")
        }
    }

    private fun handlePacket(pkt: DatagramPacket) {
        val data = pkt.data
        val len  = pkt.length
        if (len < 20) return

        val buf = ByteBuffer.wrap(data, 0, len)
        buf.order(ByteOrder.LITTLE_ENDIAN)

        // Verify "DSUC" magic from incoming emulator frame (little-endian 0x43555344)
        val incomingMagic = buf.int
        if (incomingMagic != 0x43555344 && incomingMagic != 0x53555344) {
            Log.d(TAG, "Non-DSU packet, ignoring"); return
        }

        buf.short  // version
        buf.short  // length
        buf.int    // CRC (we trust Dolphin)
        buf.int    // client ID

        // Read message type safely with Little Endian verification
        val msgType = buf.int

        // Remember Dolphin's address so we can push data back
        dolphinAddr = pkt.address
        dolphinPort = pkt.port

        when (msgType) {
            0x00000010, 0x10000000 -> sendInfoReply(pkt.address, pkt.port)   // Protocol info request
            0x00000011, 0x10000001 -> sendDataReply(pkt.address, pkt.port)   // Slot info request
            0x00000012, 0x10000002 -> sendDataReply(pkt.address, pkt.port)   // Pad data request
            else       -> Log.d(TAG, "Unknown DSU msgType: 0x${msgType.toString(16)}")
        }
    }

    private fun sendInfoReply(addr: InetAddress, port: Int) {
        try {
            val payload = builder.buildInfoPacket()
            
            // FIX: Enforce a payload boundary limit of exactly 32 bytes for Info replies.
            // Trims trailing padding arrays to align with standard packet verification.
            val exactSize = 32
            socket?.send(DatagramPacket(payload, exactSize, addr, port))
            
            Log.d(TAG, "DSU Handshake success: Dispatched verification envelope to $addr:$port")
        } catch (e: Exception) { Log.w(TAG, "sendInfoReply: ${e.message}") }
    }

    private fun sendDataReply(addr: InetAddress, port: Int) {
        try {
            val payload = builder.buildDataPacket(state)
            socket?.send(DatagramPacket(payload, payload.size, addr, port))
        } catch (e: Exception) { Log.w(TAG, "sendDataReply: ${e.message}") }
    }

    /**
     * Push a data packet to Dolphin immediately, without waiting for a request.
     * Called from FloatingOverlay or Bluetooth command triggers every time a state mutates.
     */
    fun pushUpdate() {
        val addr = dolphinAddr ?: return
        val port = dolphinPort.takeIf { it >= 0 } ?: return
        val sock = socket?.takeIf { !it.isClosed } ?: return
        try {
            val payload = builder.buildDataPacket(state)
            sock.send(DatagramPacket(payload, payload.size, addr, port))
        } catch (e: Exception) { Log.w(TAG, "pushUpdate: ${e.message}") }
    }

    // ── Button state API ───────────────────────────────────────────────────

    fun setButton(refKey: String, pressed: Boolean) {
        when (refKey) {
            "BTN_A"      -> state.btnA      = pressed
            "BTN_B"      -> state.btnB      = pressed
            "BTN_X"      -> state.btnX      = pressed
            "BTN_Y"      -> state.btnY      = pressed
            "BTN_L1"     -> state.btnL1     = pressed
            "BTN_R1"     -> state.btnR1     = pressed
            "BTN_L2"     -> { state.btnL2d  = pressed; state.triggerL = if (pressed) 0xFF.toByte() else 0 }
            "BTN_R2"     -> { state.btnR2d  = pressed; state.triggerR = if (pressed) 0xFF.toByte() else 0 }
            "DPAD_UP"    -> state.dpadUp    = pressed
            "DPAD_DOWN"  -> state.dpadDown  = pressed
            "DPAD_LEFT"  -> state.dpadLeft  = pressed
            "DPAD_RIGHT" -> state.dpadRight = pressed
            "BTN_SELECT" -> state.btnSelect = pressed
            "BTN_START"  -> state.btnStart  = pressed
            "BTN_L3"     -> state.btnL3     = pressed
            "BTN_R3"     -> state.btnR3     = pressed
            // GCN-style aliases
            "GCN_A"      -> state.btnA      = pressed
            "GCN_B"      -> state.btnB      = pressed
            "GCN_X"      -> state.btnX      = pressed
            "GCN_Y"      -> state.btnY      = pressed
            "GCN_Z"      -> state.btnR1     = pressed   // Z → R1
            "GCN_L"      -> { state.btnL1   = pressed; state.triggerL = if (pressed) 0xFF.toByte() else 0 }
            "GCN_R"      -> { state.btnR1   = pressed; state.triggerR = if (pressed) 0xFF.toByte() else 0 }
            "GCN_START"  -> state.btnStart  = pressed
            "GCN_DU"     -> state.dpadUp    = pressed
            "GCN_DD"     -> state.dpadDown  = pressed
            "GCN_DL"     -> state.dpadLeft  = pressed
            "GCN_DR"     -> state.dpadRight = pressed
            else         -> { Log.v(TAG, "setButton: unknown refKey '$refKey'"); return }
        }
        pushUpdate()
    }

    // ── Stick API ──────────────────────────────────────────────────────────

    fun setLeftStick(x: Byte, y: Byte) {
        state.leftStickX = x; state.leftStickY = y; pushUpdate()
    }

    fun setRightStick(x: Byte, y: Byte) {
        state.rightStickX = x; state.rightStickY = y; pushUpdate()
    }

    fun centreLeftStick()  { setLeftStick(0x80.toByte(), 0x80.toByte()) }
    fun centreRightStick() { setRightStick(0x80.toByte(), 0x80.toByte()) }
}
