package com.home.automation

/**
 * Converts raw screen touch coordinates into standard DSU byte values (0x00–0xFF).
 *
 * DSU convention: 0x00 = fully negative (left / up), 0x80 = centre, 0xFF = fully positive.
 * For the Y-axis pass invert = true so that dragging *up* produces a high byte.
 */
object JoystickMath {

    /**
     * @param touchPos   Current X or Y pixel position of the finger.
     * @param centerPos  Absolute pixel centre of the joystick graphic.
     * @param maxRadius  Maximum travel radius in pixels.
     * @param invert     Pass true for the Y-axis (up = positive).
     * @return           Single DSU byte (0x00–0xFF), centred at 0x80.
     */
    @JvmStatic
    fun calculateJoystickByte(touchPos: Float, centerPos: Float,
                               maxRadius: Float, invert: Boolean): Byte {
        var delta = touchPos - centerPos
        if (invert) delta = -delta
        var normalized = delta / maxRadius
        if (normalized >  1.0f) normalized =  1.0f
        if (normalized < -1.0f) normalized = -1.0f
        if (Math.abs(normalized) < 0.05f) normalized = 0.0f
        return Math.round(128 + (normalized * 127)).toByte()
    }

    /**
     * Convenience: convert already-normalised float (-1.0…+1.0) straight to DSU byte.
     * Used by FloatingOverlay.JoystickView which normalises internally.
     */
    @JvmStatic
    fun fromNormalized(normalized: Float, invert: Boolean): Byte {
        var n = if (invert) -normalized else normalized
        if (n >  1.0f) n =  1.0f
        if (n < -1.0f) n = -1.0f
        if (Math.abs(n) < 0.05f) n = 0.0f
        return Math.round(128 + (n * 127)).toByte()
    }
}
