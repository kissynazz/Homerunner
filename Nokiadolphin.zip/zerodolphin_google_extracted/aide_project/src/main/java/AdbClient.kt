package com.home.automation

import android.os.Build
import android.util.Log
import java.io.Closeable
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.Socket
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.net.ssl.SSLSocket

private const val TAG = "AdbClient"

/**
 * Minimal ADB wire-protocol client.
 *
 * Adapted from Shizuku's AdbClient with all external dependencies removed:
 *   - rikka.core.util.BuildUtils  → Build.VERSION.SDK_INT
 *   - moe.shizuku.manager.ktx.logd → android.util.Log
 *
 * Supports:
 *   - Legacy RSA-token auth (Android < 9)
 *   - TLS upgrade + RSA or cert auth (Android 9+)
 *
 * After connect(), call shellCommand() to run a single shell command and
 * stream its output via the listener callback.
 */
class AdbClient(
    private val host: String,
    private val port: Int,
    private val key: AdbKey
) : Closeable {

    private lateinit var plainSocket: Socket
    private lateinit var plainIn:     DataInputStream
    private lateinit var plainOut:    DataOutputStream

    private var useTls = false
    private var tlsSocket: SSLSocket? = null
    private var tlsIn:  DataInputStream?  = null
    private var tlsOut: DataOutputStream? = null

    private val inputStream  get() = if (useTls) tlsIn!!  else plainIn
    private val outputStream get() = if (useTls) tlsOut!! else plainOut

    // ── Connection ────────────────────────────────────────────────────────────

    fun connect() {
        plainSocket = Socket(host, port)
        plainSocket.tcpNoDelay = true
        plainIn  = DataInputStream(plainSocket.getInputStream())
        plainOut = DataOutputStream(plainSocket.getOutputStream())

        write(AdbProtocol.A_CNXN, AdbProtocol.A_VERSION, AdbProtocol.A_MAXDATA, "host::")

        var msg = read()

        // ── TLS upgrade (Android 9+ / API 29+) ───────────────────────────────
        if (msg.command == AdbProtocol.A_STLS) {
            if (Build.VERSION.SDK_INT < 29) {
                error("TLS ADB requires Android 9 or later")
            }
            write(AdbProtocol.A_STLS, AdbProtocol.A_STLS_VERSION, 0)

            val sslCtx = key.sslContext
            val ss = sslCtx.socketFactory.createSocket(plainSocket, host, port, true) as SSLSocket
            ss.useClientMode = true
            ss.startHandshake()
            Log.d(TAG, "TLS handshake succeeded")

            tlsSocket = ss
            tlsIn  = DataInputStream(ss.inputStream)
            tlsOut = DataOutputStream(ss.outputStream)
            useTls = true

            msg = read()   // expect A_CNXN after TLS

        } else if (msg.command == AdbProtocol.A_AUTH) {
            // ── Legacy RSA-token auth ─────────────────────────────────────────
            if (msg.arg0 != AdbProtocol.ADB_AUTH_TOKEN) {
                error("Expected ADB_AUTH_TOKEN, got arg0=${msg.arg0}")
            }
            // Try to sign the token with our stored key
            val signed = key.sign(msg.data!!)
            write(AdbProtocol.A_AUTH, AdbProtocol.ADB_AUTH_SIGNATURE, 0, signed)
            msg = read()

            if (msg.command != AdbProtocol.A_CNXN) {
                // Key not yet authorised — send public key so user can approve on device
                write(AdbProtocol.A_AUTH, AdbProtocol.ADB_AUTH_RSAPUBLICKEY, 0, key.adbPublicKey)
                msg = read()
            }
        }

        if (msg.command != AdbProtocol.A_CNXN) {
            error("ADB handshake failed — unexpected command ${msg.toStringShort()}")
        }
        Log.i(TAG, "ADB connected to $host:$port (tls=$useTls)")
    }

    // ── Shell command ─────────────────────────────────────────────────────────

    /**
     * Opens a shell channel, sends [command], and streams output bytes via [listener].
     * Blocks until the remote side closes the channel (command finishes).
     */
    fun shellCommand(command: String, listener: ((ByteArray) -> Unit)?) {
        val localId = 1
        write(AdbProtocol.A_OPEN, localId, 0, "shell:$command")

        var msg = read()
        when (msg.command) {
            AdbProtocol.A_OKAY -> {
                while (true) {
                    msg = read()
                    val remoteId = msg.arg0
                    when (msg.command) {
                        AdbProtocol.A_WRTE -> {
                            msg.data?.let { if (it.isNotEmpty()) listener?.invoke(it) }
                            write(AdbProtocol.A_OKAY, localId, remoteId)
                        }
                        AdbProtocol.A_CLSE -> {
                            write(AdbProtocol.A_CLSE, localId, remoteId)
                            return
                        }
                        else -> error("Shell: unexpected ${msg.toStringShort()}")
                    }
                }
            }
            AdbProtocol.A_CLSE -> {
                write(AdbProtocol.A_CLSE, localId, msg.arg0)
            }
            else -> error("Shell open: unexpected ${msg.toStringShort()}")
        }
    }

    // ── Internal write / read ─────────────────────────────────────────────────

    private fun write(command: Int, arg0: Int, arg1: Int, data: ByteArray? = null) =
        write(AdbMessage.create(command, arg0, arg1, data))

    private fun write(command: Int, arg0: Int, arg1: Int, text: String) =
        write(AdbMessage.create(command, arg0, arg1, text))

    private fun write(msg: AdbMessage) {
        outputStream.write(msg.toByteArray())
        outputStream.flush()
        Log.d(TAG, "→ ${msg.toStringShort()}")
    }

    private fun read(): AdbMessage {
        val hdr = ByteArray(AdbMessage.HEADER_LENGTH)
        inputStream.readFully(hdr)
        val buf = ByteBuffer.wrap(hdr).order(ByteOrder.LITTLE_ENDIAN)
        val command    = buf.int
        val arg0       = buf.int
        val arg1       = buf.int
        val dataLength = buf.int
        val dataCrc    = buf.int
        val magic      = buf.int

        val data = if (dataLength > 0) {
            ByteArray(dataLength).also { inputStream.readFully(it) }
        } else null

        val msg = AdbMessage(command, arg0, arg1, dataLength, dataCrc, magic, data)
        msg.validateOrThrow()
        Log.d(TAG, "← ${msg.toStringShort()}")
        return msg
    }

    // ── Closeable ─────────────────────────────────────────────────────────────

    override fun close() {
        try { tlsIn?.close()  } catch (_: Exception) {}
        try { tlsOut?.close() } catch (_: Exception) {}
        try { tlsSocket?.close() } catch (_: Exception) {}
        try { plainIn.close()  } catch (_: Exception) {}
        try { plainOut.close() } catch (_: Exception) {}
        try { plainSocket.close() } catch (_: Exception) {}
    }
}
