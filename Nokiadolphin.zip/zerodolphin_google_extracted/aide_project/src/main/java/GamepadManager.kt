package com.home.automation

import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.lang.reflect.InvocationHandler
import java.lang.reflect.Proxy

/**
 * Kernel-level virtual gamepad via the `virtual_gamepad` binary shipped in assets/.
 *
 * WHY THIS EXISTS
 * ───────────────
 * The Android sandbox blocks Dolphin's DSU/cemuhook UDP port (26760) on many devices.
 * This path bypasses DSU entirely — the binary opens /dev/uinput directly and registers
 * a real kernel input device that Dolphin (and any game) sees as a physical controller.
 *
 * EXECUTION MODEL
 * ───────────────
 * Primary:  Shizuku.newProcess() — runs the binary inside Shizuku's privileged shell
 *           without requiring a full root grant.  Shizuku must be running (Wireless
 *           Debugging or via ADB) and the user must tap "Allow" in the Shizuku UI.
 *           All Shizuku calls are made via pure Java Reflection so the compiler does
 *           not need to resolve dev.rikka.shizuku.* at compile time.
 * Fallback: Runtime.exec("su -c …") — works on rooted devices even without Shizuku.
 *
 * STDIN PROTOCOL (matches the virtual_gamepad C++ while-loop)
 * ────────────────────────────────────────────────────────────
 *   KEY <linux_code> <1|0>           — button press (1) or release (0)
 *   ABS <axis_code>  <-32768..32767> — analog axis value
 *
 * Axis codes  : 0=ABS_X  1=ABS_Y  3=ABS_RX  4=ABS_RY  16=ABS_HAT0X  17=ABS_HAT0Y
 * Button codes: 304=A  305=B  307=X  308=Y  310=L1  311=R1  312=L2  313=R2
 *               314=SELECT  315=START
 *
 * USAGE
 * ─────
 * 1. Call verifyAndStart(context) from your service / activity.
 *    It checks Shizuku availability → requests permission if needed → launches binary.
 * 2. Button presses: sendRefKey("BTN_A", true/false) — accepts same keys as DSU.
 * 3. Stick moves  : sendStick(isLeft, nx, ny)  (-1f..1f normalised).
 * 4. Call stop() when the accessibility service shuts down.
 */
object GamepadManager {

    private const val TAG        = "GamepadManager"
    private const val SHIZUKU_RC = 1001  // request code for Shizuku permission

    // Fully-qualified Shizuku class names — resolved at runtime, not compile time.
    private const val SHIZUKU_CLASS    = "dev.rikka.shizuku.Shizuku"
    private const val SHIZUKU_LISTENER = "dev.rikka.shizuku.Shizuku\$OnRequestPermissionResultListener"

    // ── Linux input keycodes (input-event-codes.h) ────────────────────────
    const val BTN_A      = 304
    const val BTN_B      = 305
    const val BTN_C      = 306
    const val BTN_X      = 307
    const val BTN_Y      = 308
    const val BTN_Z      = 309
    const val BTN_L1     = 310
    const val BTN_R1     = 311
    const val BTN_L2     = 312
    const val BTN_R2     = 313
    const val BTN_SELECT = 314
    const val BTN_START  = 315

    // ── Axis codes ────────────────────────────────────────────────────────
    const val ABS_X     = 0   // left stick X
    const val ABS_Y     = 1   // left stick Y
    const val ABS_RX    = 3   // right stick X
    const val ABS_RY    = 4   // right stick Y
    const val ABS_HAT0X = 16  // d-pad horizontal hat
    const val ABS_HAT0Y = 17  // d-pad vertical hat

    // ── Runtime state ─────────────────────────────────────────────────────
    @Volatile private var process: Process?     = null
    @Volatile private var stream: OutputStream? = null
    @Volatile private var _running              = false

    // Typed as Any? — the concrete type (Shizuku.OnRequestPermissionResultListener
    // Proxy) is only known at runtime.
    private var shizukuListener: Any? = null

    /** True while the kernel process is alive and accepting commands. */
    val isRunning: Boolean
        get() = _running && process?.let {
            try { it.exitValue(); false } catch (_: IllegalThreadStateException) { true }
        } ?: false

    // ═════════════════════════════════════════════════════════════════════
    //  Lifecycle — entry point
    // ═════════════════════════════════════════════════════════════════════

    /**
     * Main entry point. Call this from MyAutomationService.onServiceConnected().
     *
     * Flow:
     *   1. Check Shizuku is running (pingBinder).
     *   2. If permission already granted → launch immediately.
     *   3. If not → register a one-shot result listener, then fire the
     *      Shizuku permission overlay so the user can tap Allow.
     *   4. If Shizuku is absent / dead → fall back to "su -c" root exec.
     *
     * Safe to call from a background thread.
     */
    fun verifyAndStart(context: Context) {
        if (isRunning) return

        // ── Try Shizuku path ──────────────────────────────────────────────
        if (tryShizuku(context)) return

        // ── Shizuku unavailable — fall back to plain root exec ────────────
        Log.w(TAG, "Shizuku unavailable — trying su fallback")
        Thread {
            val ok = startWithSu(context)
            Log.i(TAG, "su fallback: ${if (ok) "ACTIVE" else "failed (no root?)"}")
        }.apply { name = "GamepadManager-su"; isDaemon = true; start() }
    }

    // ═════════════════════════════════════════════════════════════════════
    //  Stop
    // ═════════════════════════════════════════════════════════════════════

    fun stop() {
        _running = false
        shizukuListener?.let { reflectRemoveListener(it) }
        shizukuListener = null
        try { stream?.close()    } catch (_: Exception) {}
        try { process?.destroy() } catch (_: Exception) {}
        stream = null; process = null
        Log.i(TAG, "virtual_gamepad stopped")
    }

    // ═════════════════════════════════════════════════════════════════════
    //  Button events
    // ═════════════════════════════════════════════════════════════════════

    /** Raw button press (isPressed=1) or release (isPressed=0). */
    fun sendButton(linuxCode: Int, isPressed: Int) = write("KEY $linuxCode $isPressed")

    // ═════════════════════════════════════════════════════════════════════
    //  Axis events
    // ═════════════════════════════════════════════════════════════════════

    /** Raw axis value (-32768..32767). */
    fun sendAxis(axisCode: Int, value: Int) = write("ABS $axisCode $value")

    /** Normalised float (-1f..1f) scaled to kernel range. */
    fun sendStickAxis(axisCode: Int, normalised: Float) =
        sendAxis(axisCode, (normalised.coerceIn(-1f, 1f) * 32767f).toInt())

    // ═════════════════════════════════════════════════════════════════════
    //  High-level helpers — FloatingOverlay refKey strings
    // ═════════════════════════════════════════════════════════════════════

    /**
     * Accepts the same refKey strings used throughout FloatingOverlay
     * ("BTN_A", "DPAD_UP", "BTN_L1" …) and sends the matching kernel event.
     * D-pad is mapped to ABS_HAT0X/Y so Dolphin's hat binding works.
     */
    fun sendRefKey(refKey: String, pressed: Boolean) {
        val s = if (pressed) 1 else 0
        when (refKey) {
            "BTN_A"      -> sendButton(BTN_A,      s)
            "BTN_B"      -> sendButton(BTN_B,      s)
            "BTN_C"      -> sendButton(BTN_C,      s)
            "BTN_X"      -> sendButton(BTN_X,      s)
            "BTN_Y"      -> sendButton(BTN_Y,      s)
            "BTN_Z"      -> sendButton(BTN_Z,      s)
            "BTN_L1"     -> sendButton(BTN_L1,     s)
            "BTN_R1"     -> sendButton(BTN_R1,     s)
            "BTN_L2"     -> sendButton(BTN_L2,     s)
            "BTN_R2"     -> sendButton(BTN_R2,     s)
            "BTN_SELECT" -> sendButton(BTN_SELECT,  s)
            "BTN_START"  -> sendButton(BTN_START,   s)
            // D-pad as hat axes — on release snap back to 0
            "DPAD_UP"    -> sendAxis(ABS_HAT0Y, if (pressed) -32768 else 0)
            "DPAD_DOWN"  -> sendAxis(ABS_HAT0Y, if (pressed)  32767 else 0)
            "DPAD_LEFT"  -> sendAxis(ABS_HAT0X, if (pressed) -32768 else 0)
            "DPAD_RIGHT" -> sendAxis(ABS_HAT0X, if (pressed)  32767 else 0)
            else -> Log.v(TAG, "sendRefKey: no kernel mapping for '$refKey'")
        }
    }

    /**
     * Send normalised stick position.
     * isLeft=true  → ABS_X / ABS_Y   (left stick, labels "L" / "LS")
     * isLeft=false → ABS_RX / ABS_RY (right stick, label "C")
     */
    fun sendStick(isLeft: Boolean, nx: Float, ny: Float) {
        sendStickAxis(if (isLeft) ABS_X  else ABS_RX, nx)
        sendStickAxis(if (isLeft) ABS_Y  else ABS_RY, ny)
    }

    /** Snap a stick back to centre (ACTION_UP / CANCEL). */
    fun centreStick(isLeft: Boolean) = sendStick(isLeft, 0f, 0f)

    // ═════════════════════════════════════════════════════════════════════
    //  Internal — Shizuku path (all via Reflection, zero compile-time deps)
    // ═════════════════════════════════════════════════════════════════════

    /**
     * Returns true if we handled the launch (either immediately or via
     * the async permission callback). Returns false if Shizuku isn't running.
     */
    private fun tryShizuku(context: Context): Boolean {
        return try {
            if (!reflectPingBinder()) {
                Log.w(TAG, "Shizuku binder not alive")
                return false
            }

            if (reflectCheckSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                // Already authorised — launch right away on a background thread
                Thread {
                    launchViaShizuku(context)
                }.apply { name = "GamepadManager-shizuku"; isDaemon = true; start() }
            } else {
                // Need the user to tap Allow in the Shizuku overlay
                registerShizukuPermissionListener(context)
                reflectRequestPermission(SHIZUKU_RC)
            }
            true
        } catch (e: Exception) {
            Log.w(TAG, "Shizuku exception: ${e.message}")
            false
        }
    }

    private fun registerShizukuPermissionListener(context: Context) {
        // Remove any stale listener before registering a new one
        shizukuListener?.let { reflectRemoveListener(it) }

        // Build a Proxy that implements Shizuku.OnRequestPermissionResultListener
        val listenerIface = try {
            Class.forName(SHIZUKU_LISTENER)
        } catch (e: ClassNotFoundException) {
            Log.w(TAG, "Shizuku listener interface not found"); return
        }

        val handler = InvocationHandler { proxy, method, args ->
            if (method.name == "onRequestPermissionResult") {
                val requestCode = args?.getOrNull(0) as? Int ?: return@InvocationHandler null
                val grantResult = args.getOrNull(1) as? Int ?: PackageManager.PERMISSION_DENIED

                // One-shot — unregister immediately
                reflectRemoveListener(proxy)
                shizukuListener = null

                if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    Thread {
                        launchViaShizuku(context)
                    }.apply { name = "GamepadManager-shizuku"; isDaemon = true; start() }
                } else {
                    Log.w(TAG, "Shizuku permission denied — will retry su fallback")
                    Handler(Looper.getMainLooper()).post {
                        Toast.makeText(
                            context,
                            "Shizuku denied — trying root fallback for virtual controller",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                    Thread {
                        startWithSu(context)
                    }.apply { name = "GamepadManager-su-fallback"; isDaemon = true; start() }
                }
            }
            null
        }

        val listener = Proxy.newProxyInstance(
            listenerIface.classLoader,
            arrayOf(listenerIface),
            handler
        )

        shizukuListener = listener
        reflectAddListener(listener)
    }

    private fun launchViaShizuku(context: Context) {
        try {
            val dest = extractBinary(context)
            val proc = reflectNewProcess(arrayOf("sh", "-c", dest.absolutePath))
                ?: throw Exception("newProcess returned null")

            process  = proc
            stream   = proc.outputStream
            _running = true
            Log.i(TAG, "virtual_gamepad launched via Shizuku — kernel uinput path ACTIVE")
        } catch (e: Exception) {
            Log.e(TAG, "Shizuku launch failed: ${e.message} — trying su")
            startWithSu(context)
        }
    }

    // ═════════════════════════════════════════════════════════════════════
    //  Reflection helpers — thin wrappers around each Shizuku static method
    // ═════════════════════════════════════════════════════════════════════

    private fun shizukuClass(): Class<*>? = try {
        Class.forName(SHIZUKU_CLASS)
    } catch (_: ClassNotFoundException) { null }

    private fun listenerIface(): Class<*>? = try {
        Class.forName(SHIZUKU_LISTENER)
    } catch (_: ClassNotFoundException) { null }

    /** Shizuku.pingBinder() */
    private fun reflectPingBinder(): Boolean = try {
        shizukuClass()?.getMethod("pingBinder")?.invoke(null) as? Boolean ?: false
    } catch (_: Exception) { false }

    /** Shizuku.checkSelfPermission() */
    private fun reflectCheckSelfPermission(): Int = try {
        shizukuClass()?.getMethod("checkSelfPermission")?.invoke(null) as? Int
            ?: PackageManager.PERMISSION_DENIED
    } catch (_: Exception) { PackageManager.PERMISSION_DENIED }

    /** Shizuku.requestPermission(requestCode) */
    private fun reflectRequestPermission(code: Int) {
        try {
            shizukuClass()
                ?.getMethod("requestPermission", Int::class.java)
                ?.invoke(null, code)
        } catch (e: Exception) { Log.w(TAG, "reflectRequestPermission: ${e.message}") }
    }

    /** Shizuku.addRequestPermissionResultListener(listener) */
    private fun reflectAddListener(listener: Any) {
        try {
            val iface = listenerIface() ?: return
            shizukuClass()
                ?.getMethod("addRequestPermissionResultListener", iface)
                ?.invoke(null, listener)
        } catch (e: Exception) { Log.w(TAG, "reflectAddListener: ${e.message}") }
    }

    /** Shizuku.removeRequestPermissionResultListener(listener) */
    private fun reflectRemoveListener(listener: Any) {
        try {
            val iface = listenerIface() ?: return
            shizukuClass()
                ?.getMethod("removeRequestPermissionResultListener", iface)
                ?.invoke(null, listener)
        } catch (_: Exception) {}
    }

    /**
     * Shizuku.newProcess(String[] cmd, String[] env, String dir)
     * Returns the Process, or null if the call fails.
     */
    private fun reflectNewProcess(cmd: Array<String>): Process? = try {
        shizukuClass()
            ?.getMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            ?.invoke(null, cmd, null, null) as? Process
    } catch (e: Exception) {
        Log.w(TAG, "reflectNewProcess: ${e.message}")
        null
    }

    // ═════════════════════════════════════════════════════════════════════
    //  Internal — root / su fallback
    // ═════════════════════════════════════════════════════════════════════

    private fun startWithSu(context: Context): Boolean {
        return try {
            val dest = extractBinary(context)
            val proc = try {
                Runtime.getRuntime().exec(arrayOf("su", "-c", dest.absolutePath))
            } catch (e: Exception) {
                Log.w(TAG, "su failed ($e) — trying plain exec")
                Runtime.getRuntime().exec(arrayOf(dest.absolutePath))
            }
            process  = proc
            stream   = proc.outputStream
            _running = true
            Log.i(TAG, "virtual_gamepad launched via su — kernel uinput path ACTIVE")
            true
        } catch (e: Exception) {
            Log.e(TAG, "su launch failed: ${e.message}")
            false
        }
    }

    // ═════════════════════════════════════════════════════════════════════
    //  Internal — binary extraction
    // ═════════════════════════════════════════════════════════════════════

    /** Copy virtual_gamepad from assets → filesDir and chmod +x. */
    private fun extractBinary(context: Context): File {
        val dest = File(context.filesDir, "virtual_gamepad")
        context.assets.open("virtual_gamepad").use { inp ->
            FileOutputStream(dest).use { out -> inp.copyTo(out) }
        }
        dest.setExecutable(true, false)
        return dest
    }

    // ═════════════════════════════════════════════════════════════════════
    //  Internal — write to stdin pipe
    // ═════════════════════════════════════════════════════════════════════

    private fun write(cmd: String) {
        if (!_running) return
        try {
            stream?.let { s ->
                s.write("$cmd\n".toByteArray())
                s.flush()
            }
        } catch (e: Exception) {
            Log.e(TAG, "write '$cmd' failed — marking stopped: ${e.message}")
            _running = false
        }
    }
}
