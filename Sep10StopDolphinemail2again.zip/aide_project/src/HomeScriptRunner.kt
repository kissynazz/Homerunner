package com.albatrossone

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Path
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.InputDevice
import android.view.MotionEvent
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

object HomeScriptRunner {

    @Volatile var accessibilityService: AccessibilityService? = null

    @Suppress("DEPRECATION")
    @UseExperimental(kotlin.ExperimentalStdlibApi::class)
    fun executeAction(actionType: String, data: String = ""): String {
        return try {
            when (actionType.lowercase()) {
                "home", "3"       -> triggerHome()
                "screenshot", "7" -> triggerScreenshot()
                "bitscreen"       -> {
                    if (!ManualScreenCapture.hasProjection()) {
                        openMainActivityForScreenCapture("bitscreen")
                        "Screen capture permission requested in MainActivity"
                    } else {
                        ManualScreenCapture.captureOne(accessibilityService
                            ?: return "Error: No accessibility service")
                    }
                }
                "stream"          -> {
                    if (!ManualScreenCapture.hasProjection()) {
                        openMainActivityForScreenCapture("stream")
                        "Screen capture permission requested in MainActivity"
                    } else {
                        ManualScreenCapture.toggleStream(accessibilityService
                            ?: return "Error: No accessibility service")
                    }
                }
                "tap"             -> simulateViewTap(data)
                "swipe"           -> simulateViewSwipe(data)
                "multi"           -> simulateMultiTap()
                "record"           -> FloatingOverlay.toggleCommandRecord(
                    accessibilityService ?: return "Error: No accessibility service",
                    false
                )
                "recordsnip"       -> FloatingOverlay.toggleCommandRecord(
                    accessibilityService ?: return "Error: No accessibility service",
                    true
                )
                "clip"             -> {
                    val svc = accessibilityService
                    if (svc != null) {
                        readAdbClipAndSetClipboard(svc)
                    } else {
                        "Error: Accessibility Service disconnected"
                    }
                }
                "hide"             -> {
                    FloatingOverlay.toggleHidden()
                    "Success: Overlay visibility toggled"
                }
                else              -> "Error: Action '$actionType' not supported"
            }
        } catch (e: Exception) { "Action Error: ${e.message}" }
    }

    private fun triggerHome(): String {
        val svc = accessibilityService
        return if (svc != null) {
            val ok = svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            if (ok) "Success: Navigated to Home Screen" else "Error: performGlobalAction(HOME) returned false"
        } else {
            val ctx = getContext() ?: return "Error: No context"
            triggerHomeIntent(ctx)
        }
    }

    private fun triggerScreenshot(): String {
        val svc = accessibilityService
        return if (svc != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val ok = svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
            if (ok) "Success: Screenshot taken" else "Error: performGlobalAction(SCREENSHOT) returned false"
        } else {
            val ctx = getContext() ?: return "Error: No context"
            triggerNativeScreenshot(ctx)
        }
    }

    private fun getContext(): android.app.Application? = try {
        val at = Class.forName("android.app.ActivityThread")
        val cur = at.getDeclaredMethod("currentActivityThread").apply { isAccessible = true }.invoke(null)
        at.getDeclaredMethod("getApplication").apply { isAccessible = true }.invoke(cur) as android.app.Application
    } catch (_: Exception) { null }

    /**
     * MediaProjection permission must be requested by an Activity. If a
     * command arrives while the app UI is closed, bring MainActivity forward
     * so its existing permission flow can show the system approval dialog.
     */
    private fun openMainActivityForScreenCapture(action: String) {
        try {
            val context = getContext() ?: return
            val intent = android.content.Intent(context, MainActivity::class.java).apply {
                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                putExtra(MainActivity.EXTRA_REQUEST_SCREEN_CAPTURE, true)
                putExtra(MainActivity.EXTRA_SCREEN_CAPTURE_ACTION, action)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            android.util.Log.e("HomeScriptRunner", "Unable to open MainActivity for capture permission", e)
        }
    }

    private fun getInputManagerAndInjectMethod(): Pair<Any, java.lang.reflect.Method> {
        val cls = Class.forName("android.hardware.input.InputManager")
        val instance = cls.getDeclaredMethod("getInstance").apply { isAccessible = true }.invoke(null)
        val inject = cls.getDeclaredMethod("injectInputEvent", android.view.InputEvent::class.java, Int::class.java).apply { isAccessible = true }
        return Pair(instance, inject)
    }

    private fun injectMotionEvent(im: Any, inject: java.lang.reflect.Method, action: Int, x: Float, y: Float, downTime: Long, eventTime: Long) {
        val e = MotionEvent.obtain(downTime, eventTime, action, x, y, 0).also { it.source = InputDevice.SOURCE_TOUCHSCREEN }
        inject.invoke(im, e, 0); e.recycle()
    }

    private fun triggerHomeIntent(context: android.app.Application): String {
        val intentClass = Class.forName("android.content.Intent")
        val intent = intentClass.getConstructor(String::class.java).newInstance("android.intent.action.MAIN")
        intentClass.getDeclaredMethod("addCategory", String::class.java).invoke(intent, "android.intent.category.HOME")
        intentClass.getDeclaredMethod("setFlags", Int::class.java).invoke(intent, 0x10000000)
        context.javaClass.getMethod("startActivity", intentClass).invoke(context, intent)
        return "Success: Navigated to Home Screen"
    }

    private fun triggerNativeScreenshot(context: android.app.Application): String {
        return try {
            val wmClass = Class.forName("android.view.WindowManagerGlobal")
            val wmInstance = wmClass.getDeclaredMethod("getInstance").apply { isAccessible = true }.invoke(null)
            @Suppress("UNCHECKED_CAST")
            val views = wmClass.getDeclaredField("mViews").apply { isAccessible = true }.get(wmInstance) as? ArrayList<android.view.View>
            if (views.isNullOrEmpty()) return "Error: No root views found"
            val view = views.last()
            if (view.width == 0 || view.height == 0) return "Error: View has no dimensions"
            var result = "Error: Screenshot timed out"
            val latch = CountDownLatch(1)
            Handler(Looper.getMainLooper()).post {
                try {
                    val bitmap = Bitmap.createBitmap(view.width, view.height, Bitmap.Config.ARGB_8888)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        val surface = getSurface(view)
                        if (surface != null && surface.isValid) {
                            android.view.PixelCopy.request(surface, android.graphics.Rect(0, 0, view.width, view.height), bitmap, { cr ->
                                result = if (cr == android.view.PixelCopy.SUCCESS) saveBitmap(context, bitmap) else "Error: PixelCopy failed ($cr)"
                                latch.countDown()
                            }, Handler(Looper.getMainLooper()))
                            return@post
                        }
                    }
                    view.draw(Canvas(bitmap)); result = saveBitmap(context, bitmap); latch.countDown()
                } catch (e: Exception) { result = "Screenshot Error: ${e.message}"; latch.countDown() }
            }
            latch.await(10, TimeUnit.SECONDS); result
        } catch (e: Exception) { "Screenshot Error: ${e.message}" }
    }

    private fun getSurface(view: android.view.View): android.view.Surface? {
        return try {
            val ai = android.view.View::class.java.getDeclaredField("mAttachInfo").apply { isAccessible = true }.get(view) ?: return null
            val vri = ai.javaClass.getDeclaredField("mViewRootImpl").apply { isAccessible = true }.get(ai) ?: return null
            vri.javaClass.getDeclaredField("mSurface").apply { isAccessible = true }.get(vri) as? android.view.Surface
        } catch (_: Exception) { null }
    }

    private fun saveBitmap(context: android.app.Application, bitmap: Bitmap): String {
        val fileName = "screenshot_${System.currentTimeMillis()}.png"
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = android.content.ContentValues().apply {
                put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, fileName)
                put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(android.provider.MediaStore.Images.Media.RELATIVE_PATH, "DCIM/Screenshots")
                put(android.provider.MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = context.contentResolver.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return "Error: MediaStore insert failed"
            context.contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            values.clear(); values.put(android.provider.MediaStore.Images.Media.IS_PENDING, 0)
            context.contentResolver.update(uri, values, null, null)
            "Success: Screenshot saved to DCIM/Screenshots/$fileName"
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), "Screenshots").also { it.mkdirs() }
            val file = File(dir, fileName)
            FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            android.media.MediaScannerConnection.scanFile(context, arrayOf(file.absolutePath), arrayOf("image/png"), null)
            "Success: Screenshot saved to ${file.absolutePath}"
        }
    }

    // Tap rewritten to use dispatchGesture (same API as swipe) — the old
    // InputManager reflection path was silently failing on this device.
    // A zero-movement stroke at (x,y) with a 100 ms duration is a reliable tap.
    @Suppress("NewApi")
    private fun simulateViewTap(coordinates: String): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N)
            return "Tap Error: Requires Android 7+"
        val svc = accessibilityService ?: return "Tap Error: No accessibility service"
        return try {
            val parts = coordinates.split(",")
            if (parts.size < 2) return "Tap Error: Expected 'x,y'"
            val x = parts[0].trim().toFloat()
            val y = parts[1].trim().toFloat()
            val path   = Path().apply { moveTo(x, y); lineTo(x, y) }
            val stroke  = GestureDescription.StrokeDescription(path, 0L, 100L)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            val ok = svc.dispatchGesture(gesture, null, null)
            if (ok) "Success: Tapped at ($x, $y)" else "Tap Error: dispatchGesture returned false"
        } catch (e: Exception) { "Tap Error: ${e.message}" }
    }

    @Suppress("NewApi")
    private fun simulateViewSwipe(coordinates: String): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N)
            return "Swipe Error: Requires Android 7+"
        val svc = accessibilityService ?: return "Swipe Error: No accessibility service"
        return try {
            val parts = coordinates.split(",")
            if (parts.size < 4) return "Swipe Error: Expected 'x1,y1,x2,y2'"
            val x1  = parts[0].trim().toFloat(); val y1 = parts[1].trim().toFloat()
            val x2  = parts[2].trim().toFloat(); val y2 = parts[3].trim().toFloat()
            val dur = if (parts.size >= 5) parts[4].trim().toLong() else 300L
            val path   = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
            val stroke  = GestureDescription.StrokeDescription(path, 0L, dur)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            val ok = svc.dispatchGesture(gesture, null, null)
            if (ok) "Success: Swiped from ($x1,$y1) to ($x2,$y2)"
            else "Swipe Error: dispatchGesture returned false"
        } catch (e: Exception) { "Swipe Error: ${e.message}" }
    }

    // Reads DCIM/Screenshots/adbmulti.txt, parses [[x,y],[x,y],...] and taps
    // each coordinate in order. Each tap waits for the gesture callback before
    // the next is dispatched — no added delay between taps beyond gesture completion.
    @Suppress("NewApi")
    private fun simulateMultiTap(): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N)
            return "Multi Error: Requires Android 7+"
        val svc = accessibilityService ?: return "Multi Error: No accessibility service"
        return try {
            val file = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
                "Screenshots/adbmulti.txt"
            )
            if (!file.exists()) return "Multi Error: adbmulti.txt not found"
            val raw = file.readText().trim()
            val coords = parseMultiTapCoords(raw)
            if (coords.isEmpty()) return "Multi Error: No valid coordinates in adbmulti.txt"

            android.util.Log.i("HomeScriptRunner", "Multi-tap: ${coords.size} points — $coords")

            for ((x, y) in coords) {
                val latch = CountDownLatch(1)
                val path    = Path().apply { moveTo(x, y); lineTo(x, y) }
                val stroke  = GestureDescription.StrokeDescription(path, 0L, 100L)
                val gesture = GestureDescription.Builder().addStroke(stroke).build()
                val dispatched = svc.dispatchGesture(
                    gesture,
                    object : AccessibilityService.GestureResultCallback() {
                        override fun onCompleted(gestureDescription: GestureDescription?) { latch.countDown() }
                        override fun onCancelled(gestureDescription: GestureDescription?) { latch.countDown() }
                    },
                    null
                )
                if (!dispatched) {
                    android.util.Log.w("HomeScriptRunner", "Multi-tap: dispatchGesture returned false at ($x,$y)")
                }
                // Wait for this gesture to finish before sending the next one.
                // Timeout of 2 s per tap so a stuck callback never hangs the whole sequence.
                latch.await(2, TimeUnit.SECONDS)
            }
            "Success: Multi-tapped ${coords.size} points"
        } catch (e: Exception) { "Multi Error: ${e.message}" }
    }

    // Parses [[x,y],[x,y],...] — tolerates spaces and single/double bracket variants.
    // Each pair must have at least two comma-separated numeric values.
    private fun parseMultiTapCoords(raw: String): List<Pair<Float, Float>> {
        // Strip the outer brackets so we get "x,y],[x,y" or "x,y" etc.
        val stripped = raw.trim().removePrefix("[").removeSuffix("]")
        if (stripped.isBlank()) return emptyList()
        // Split on "],[" to separate pairs; each item may still have leading/trailing brackets.
        return stripped.split("],[").mapNotNull { item ->
            val clean = item.trim('[', ']', ' ')
            val parts = clean.split(",")
            val x = parts.getOrNull(0)?.trim()?.toFloatOrNull()
            val y = parts.getOrNull(1)?.trim()?.toFloatOrNull()
            if (x != null && y != null) Pair(x, y) else null
        }
    }

    // Reads text from DCIM/Screenshots/adbclip.txt into the system clipboard.
    private fun readAdbClipAndSetClipboard(context: android.content.Context): String {
        return try {
            val dcimDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM)
            val clipFile = File(dcimDir, "Screenshots/adbclip.txt")
            if (!clipFile.exists()) {
                return "Error: adbclip.txt not found at ${clipFile.absolutePath}"
            }

            val textToCopy = clipFile.readText().trim()
            if (textToCopy.isEmpty()) {
                return "Warning: adbclip.txt is empty. Clipboard not updated."
            }

            val clipboard = context.getSystemService(
                android.content.Context.CLIPBOARD_SERVICE
            ) as android.content.ClipboardManager
            clipboard.setPrimaryClip(
                android.content.ClipData.newPlainText("AlbatrossOneClip", textToCopy)
            )
            "Success: Copied text content to system clipboard"
        } catch (e: Exception) {
            "Error: Clipboard pipeline failed (${e.message})"
        }
    }
}
