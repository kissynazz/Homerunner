package com.albatrossone

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File

class MainActivity : Activity() {

    companion object {
        const val EXTRA_REQUEST_SCREEN_CAPTURE = "request_screen_capture"
        const val EXTRA_SCREEN_CAPTURE_ACTION = "screen_capture_action"
        const val EXTRA_REQUEST_AUDIO_PERMISSION = "request_audio_permission"
    }

    private val REQUEST_STORAGE = 1001
    private val REQUEST_BT      = 1002
    private val REQUEST_SCREEN_CAPTURE = 1003
    private val REQUEST_AUDIO = 1004

    private var pendingBtAction: (() -> Unit)? = null
    private var screenCaptureRequested = false
    private var pendingScreenCaptureAction: String? = null

    private fun ensureBtPermissions(statusText: TextView, onGranted: () -> Unit) {
        if (android.os.Build.VERSION.SDK_INT < 31) { onGranted(); return }
        val needed = arrayOf(
            "android.permission.BLUETOOTH_CONNECT",
            "android.permission.BLUETOOTH_ADVERTISE",
            "android.permission.BLUETOOTH_SCAN"
        )
        val missing = needed.filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) { onGranted(); return }
        statusText.text = "Requesting Bluetooth permissions...\n(${missing.size} needed)"
        pendingBtAction = onGranted
        requestPermissions(missing.toTypedArray(), REQUEST_BT)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        requestAllFilesAccessIfNeeded()

        val statusText    = findViewById<TextView>(R.id.status_text)
        val enableBtn     = findViewById<Button>(R.id.btn_enable)
        val testBtn       = findViewById<Button>(R.id.btn_test)
        val filesBtn      = findViewById<Button>(R.id.btn_files)
        val btStatusBtn   = findViewById<Button>(R.id.btn_bt_status)

        val btBackBtn     = findViewById<Button>(R.id.btn_bt_back)
        val btCentralBtn  = findViewById<Button>(R.id.btn_bt_central)
        val btPeriphBtn   = findViewById<Button>(R.id.btn_bt_peripheral)
        val btGamepadBtn  = findViewById<Button>(R.id.btn_bt_gamepad)

        val btCentralRestartBtn  = findViewById<Button>(R.id.btn_bt_central_restart)
        val btPeriphRestartBtn   = findViewById<Button>(R.id.btn_bt_peripheral_restart)
        val btGamepadRestartBtn  = findViewById<Button>(R.id.btn_bt_gamepad_restart)

        val rowCentral   = findViewById<LinearLayout>(R.id.row_bt_central)
        val rowPeriph    = findViewById<LinearLayout>(R.id.row_bt_peripheral)
        val rowGamepad   = findViewById<LinearLayout>(R.id.row_bt_gamepad)

        val mainButtons = listOf(enableBtn, testBtn, filesBtn, btStatusBtn)
        val btRows      = listOf(btBackBtn, rowCentral, rowPeriph, rowGamepad)

        updateStatus(statusText)
        if (intent.getBooleanExtra(EXTRA_REQUEST_AUDIO_PERMISSION, false) &&
            android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M &&
            checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) !=
                PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(
                arrayOf(android.Manifest.permission.RECORD_AUDIO),
                REQUEST_AUDIO
            )
        }
        if (intent.getBooleanExtra(EXTRA_REQUEST_SCREEN_CAPTURE, false)) {
            pendingScreenCaptureAction = intent.getStringExtra(EXTRA_SCREEN_CAPTURE_ACTION)
            window.decorView.postDelayed({ requestScreenCaptureIfNeeded() }, 300L)
        }

        enableBtn.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        testBtn.setOnClickListener {
            readAndShowAdbcomFile(statusText)
        }

        filesBtn.setOnClickListener {
            showFilesDialog()
        }

        btStatusBtn.setOnClickListener {
            mainButtons.forEach { it.visibility = View.GONE }
            btRows.forEach     { it.visibility = View.VISIBLE }
            statusText.text = "Tap a button to check or restart a BT role."
        }

        btBackBtn.setOnClickListener {
            btRows.forEach     { it.visibility = View.GONE }
            mainButtons.forEach { it.visibility = View.VISIBLE }
            updateStatus(statusText)
        }

        btCentralBtn.setOnClickListener  { statusText.text = BtCentral.status() }
        btPeriphBtn.setOnClickListener   { statusText.text = BtPeripheral.status() }
        btGamepadBtn.setOnClickListener  { statusText.text = BtGamepad.status() }

        btCentralRestartBtn.setOnClickListener {
            ensureBtPermissions(statusText) {
                Thread {
                    BtCentral.restart()
                    runOnUiThread { statusText.text = "Central reset.\n\n${BtCentral.status()}" }
                }.start()
            }
        }

        btPeriphRestartBtn.setOnClickListener {
            ensureBtPermissions(statusText) {
                statusText.text = "Stopping Peripheral..."
                Thread {
                    BtPeripheral.stop(this)
                    Thread.sleep(400)
                    BtPeripheral.start(this) { msg -> runOnUiThread { statusText.text = msg } }
                }.start()
            }
        }

        btGamepadRestartBtn.setOnClickListener {
            ensureBtPermissions(statusText) {
                statusText.text = "Stopping Gamepad..."
                Thread {
                    BtGamepad.stop(this)
                    Thread.sleep(400)
                    if (BtGamepad.onCommandReceived == null) {
                        BtGamepad.onCommandReceived = { text ->
                            android.util.Log.i("MainActivity", "← iPad command (restart path): \"$text\"")
                            Thread {
                                val idx    = text.indexOf('|')
                                val action = if (idx >= 0) text.substring(0, idx).trim() else text.trim()
                                val data   = if (idx >= 0) text.substring(idx + 1).trim() else ""
                                HomeScriptRunner.executeAction(action, data)
                            }.start()
                        }
                    }
                    BtGamepad.start(this) { msg -> runOnUiThread { statusText.text = msg } }
                }.start()
            }
        }
    }

    private fun requestAllFilesAccessIfNeeded() {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.R ||
            Environment.isExternalStorageManager()
        ) {
            return
        }

        AlertDialog.Builder(this)
            .setTitle("Storage access required")
            .setMessage("AlbatrossOne needs All files access to save manual screen frames to Download/ManualScreen.")
            .setPositiveButton("Open Settings") { _, _ ->
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                intent.data = Uri.parse("package:$packageName")
                startActivity(intent)
            }
            .setNegativeButton("Later", null)
            .show()
    }

    private fun requestScreenCaptureIfNeeded() {
        if (screenCaptureRequested ||
            ManualScreenCapture.hasProjection() ||
            !isServiceEnabled() ||
            android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.LOLLIPOP ||
            (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R &&
                !Environment.isExternalStorageManager())
        ) {
            return
        }

        val manager = getSystemService(android.content.Context.MEDIA_PROJECTION_SERVICE)
            as? android.media.projection.MediaProjectionManager ?: return
        screenCaptureRequested = true
        try {
            startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_SCREEN_CAPTURE)
        } catch (e: Exception) {
            screenCaptureRequested = false
            android.util.Log.e("MainActivity", "Failed to request recording framework token flow initialization", e)
        }
    }
    private fun readAndShowAdbcomFile(statusText: TextView) {
        if (checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            statusText.text = "Requesting storage permission..."
            requestPermissions(
                arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE),
                REQUEST_STORAGE
            )
            return
        }

        statusText.text = "Reading adbcom.txt..."
        Thread {
            val dir  = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM)
            val file = File(dir, "Screenshots/adbcom.txt")
            val result = if (!file.exists()) {
                "adbcom.txt not found.\n\nExpected location:\n${file.absolutePath}\n\nRun adbcom.py on the PC so it writes output there."
            } else {
                try {
                    val lines = file.readLines()
                    if (lines.isEmpty()) {
                        "adbcom.txt exists but is empty.\n\nPath: ${file.absolutePath}"
                    } else {
                        "adbcom.txt — ${lines.size} line(s):\n\n" + lines.joinToString("\n")
                    }
                } catch (e: Exception) {
                    "Error reading adbcom.txt:\n${e.message}"
                }
            }
            runOnUiThread { statusText.text = result }
        }.start()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val statusText = findViewById<TextView>(R.id.status_text)
        when (requestCode) {
            REQUEST_STORAGE -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    readAndShowAdbcomFile(statusText)
                } else {
                    statusText.text = "Storage permission denied.\n\nGrant 'Files and media' permission in Settings, then try again."
                }
            }
            REQUEST_BT -> {
                val allGranted = grantResults.isNotEmpty() &&
                    grantResults.all { it == PackageManager.PERMISSION_GRANTED }
                if (allGranted) {
                    statusText.text = "Bluetooth permissions granted — proceeding..."
                    pendingBtAction?.invoke()
                } else {
                    val denied = permissions.zip(grantResults.toList())
                        .filter { it.second != PackageManager.PERMISSION_GRANTED }
                        .joinToString("\n") { "  • ${it.first.removePrefix("android.permission.")}" }
                    statusText.text = "Bluetooth permissions denied:\n$denied\n\nGo to Settings → Apps → AlbatrossOne\n→ Permissions → Nearby devices → Allow"
                }
                pendingBtAction = null
            }
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_SCREEN_CAPTURE) return

        screenCaptureRequested = false
        val statusText = findViewById<TextView>(R.id.status_text)
        if (resultCode == RESULT_OK && data != null) {
            val result = ManualScreenCapture.startProjection(this, resultCode, data)
            statusText.text = "Fast capture engine initialized!\n$result\n\n${statusText.text}"
            val pendingAction = pendingScreenCaptureAction
            pendingScreenCaptureAction = null
            if (pendingAction != null && ManualScreenCapture.hasProjection()) {
                Thread {
                    val actionResult = HomeScriptRunner.executeAction(pendingAction)
                    runOnUiThread {
                        statusText.text = "$actionResult\n\n${statusText.text}"
                    }
                }.start()
            }
        } else {
            pendingScreenCaptureAction = null
            statusText.text = "Screen capture permission was declined.\n\nbitscreen and stream will remain unavailable until it is allowed."
        }
    }

    override fun onResume() {
        super.onResume()
        val statusText = findViewById<TextView>(R.id.status_text)
        updateStatus(statusText)
        requestScreenCaptureIfNeeded()
    }

    private fun updateStatus(tv: TextView) {
        val enabled = isServiceEnabled()
        tv.text = if (enabled) {
            "✓ Service is ACTIVE\n" +
            "✓ Projection Active: ${ManualScreenCapture.hasProjection()}\n\n" +
            "Copy clipboard commands from any app:\n\n" +
            "  '7 1'  → screenshot\n" +
            "  'bitscreen 2'  → one frame to Download/ManualScreen/amanualscreenFin.jpeg\n" +
            "  'stream 3'  → start/stop updating Download/ManualScreen/amanualscreenFin.jpeg\n" +
            "  '3 2'  → home\n" +
            "  'tap 540 1000 3'  → tap\n\n" +
            "The last number must increase each time.\n" +
            "You can now close this app — the service runs in the background."
        } else {
            "⚠️ Service is NOT enabled\n\n" +
            "Tap 'Open Accessibility Settings' below,\n" +
            "find 'AlbatrossOne' under Installed Apps,\n" +
            "and turn it ON.\n\n" +
            "Then come back here — the status will update."
        }
    }

    private fun isServiceEnabled(): Boolean {
        // 🚀 FIX: Removed the incorrect shorthand dot modifier matching syntax pattern
        val name = "${packageName}/com.albatrossone.MyAutomationService"
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.split(":").any { it.equals(name, ignoreCase = true) }
    }

    private fun showFilesDialog() {
        try {
            val intent = Intent(this, FileBrowserActivity::class.java)
            startActivity(intent)
        } catch (e: Exception) {
            android.widget.Toast.makeText(this, "Could not open browser: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
        }
    }
}
