package com.albatrossone

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Path
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.InputDevice
import android.view.MotionEvent
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

object HomeScriptRunner {

    @Volatile var accessibilityService: AccessibilityService? = null

    @Suppress("DEPRECATION")
    @UseExperimental(kotlin.ExperimentalStdlibApi::class)
    fun executeAction(actionType: String, data: String = ""): String {
        return try {
            when (actionType.trim().lowercase()) {
                "home", "3"       -> triggerHome()
                "screenshot", "7" -> triggerScreenshot()
                "bitscreen"       -> {
                    if (!ManualScreenCapture.hasProjection()) {
                        openMainActivityForScreenCapture("bitscreen")
                        "Screen capture permission requested in MainActivity"
                    } else {
                        ManualScreenCapture.captureOne(accessibilityService
                            ?: return "Error: No accessibility service")
                    }
                }
                "stream"          -> {
                    if (!ManualScreenCapture.hasProjection()) {
                        openMainActivityForScreenCapture("stream")
                        "Screen capture permission requested in MainActivity"
                    } else {
                        ManualScreenCapture.toggleStream(accessibilityService
                            ?: return "Error: No accessibility service")
                    }
                }
                "tap"             -> simulateViewTap(data)
                "swipe"           -> simulateViewSwipe(data)
                "multi"           -> simulateMultiTap()
                "record"           -> FloatingOverlay.toggleCommandRecord(
                    accessibilityService ?: return "Error: No accessibility service",
                    false
                )
                "recordsnip"       -> FloatingOverlay.toggleCommandRecord(
                    accessibilityService ?: return "Error: No accessibility service",
                    true
                )
                "liverec"          -> FloatingOverlay.toggleLiveRec(
                    accessibilityService ?: return "Error: No accessibility service"
                )
                "adbkotlin", "kotlin" -> runAdbKotlinScript()
                "ismainscreen", "checkmainscreen" -> checkMainScreen()
                "checkspot" -> checkSpot(data)
                "awhile" -> runAwhileLoop()
                "clip"             -> {
                    val svc = accessibilityService
                    if (svc != null) {
                        readAdbClipAndSetClipboard(svc)
                    } else {
                        "Error: Accessibility Service disconnected"
                    }
                }
                "hide"             -> {
                    FloatingOverlay.toggleHidden()
                    "Success: Overlay visibility toggled"
                }
                else              -> "Error: Action '$actionType' not supported"
            }
        } catch (e: Exception) { "Action Error: ${e.message}" }
    }

    private fun runAdbKotlinScript(): String {
        val directory = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
            "Screenshots"
        ).also { it.mkdirs() }
        val scriptFile = File(directory, "adbkotlin.kt")
        val errorFile = File(directory, "adberror.txt")

        return try {
            if (!scriptFile.exists()) {
                val message = "adbkotlin.kt not found at ${scriptFile.absolutePath}"
                errorFile.writeText(message, Charsets.UTF_8)
                return "Kotlin Error: $message"
            }

            val errors = mutableListOf<String>()
            errorFile.writeText("", Charsets.UTF_8)
            val lines = scriptFile.readLines()

            var stoppedBySpeech = false
            var kotlinFunctionDepth = 0
            scriptLoop@ for ((index, sourceLine) in lines.withIndex()) {
                val line = sourceLine.trim()
                if (kotlinFunctionDepth > 0) {
                    kotlinFunctionDepth += line.count { it == '{' }
                    kotlinFunctionDepth -= line.count { it == '}' }
                    continue
                }
                if (line.isEmpty() || line.startsWith("//") || line.startsWith("#")) continue
                if (line.startsWith("import ") || line.startsWith("package ")) continue
                if (line.startsWith("fun ") || line.startsWith("private fun ")) {
                    kotlinFunctionDepth = line.count { it == '{' } - line.count { it == '}' }
                    continue
                }
                // Large Kotlin data declarations can be pasted into the
                // command file for scripts that use them conceptually. The
                // command runner does not evaluate arbitrary Kotlin values.
                if (line.startsWith("val s2compare") ||
                    line.startsWith("val s2Compare") ||
                    line.startsWith("val ismainscreen") ||
                    line.startsWith("val im3")
                ) {
                    continue
                }
                if (isSpeechStopRequested(directory)) {
                    stoppedBySpeech = true
                    break@scriptLoop
                }

                try {
                    val match = Regex("""^([A-Za-z][A-Za-z0-9_]*)\s*\((.*)\)\s*$""").matchEntire(line)
                        ?: throw IllegalArgumentException("Expected command(args), got: $line")
                    val command = match.groupValues[1].toLowerCase()
                    val args = splitScriptArguments(match.groupValues[2])

                    if (command == "stopifspeech" || command == "checkstop") {
                        if (isSpeechStopRequested(directory)) {
                            stoppedBySpeech = true
                            break@scriptLoop
                        }
                    } else if (command == "sleep" || command == "delay") {
                        val millis = args.singleOrNull()?.toLongOrNull()
                            ?: throw IllegalArgumentException("sleep expects one millisecond value")
                        Thread.sleep(millis.coerceIn(0L, 60_000L))
                    } else {
                        val data = when (command) {
                            "tap" -> {
                                if (args.size != 2) throw IllegalArgumentException("tap expects x,y")
                                "${args[0]},${args[1]}"
                            }
                            "swipe" -> {
                                if (args.size !in 4..5) {
                                    throw IllegalArgumentException("swipe expects x1,y1,x2,y2[,duration]")
                                }
                                args.joinToString(",")
                            }
                            "checkspot" -> {
                                if (args.size !in 3..4) {
                                    throw IllegalArgumentException(
                                        "checkSpot expects x,y,referenceImage[,currentImage]"
                                    )
                                }
                                args.joinToString(",")
                            }
                            else -> if (args.isNotEmpty()) {
                                throw IllegalArgumentException("$command does not accept arguments")
                            } else ""
                        }

                        val result = executeAction(
                            if (command == "screenshot") "screenshot" else command,
                            data
                        )
                        if (result.startsWith("Error", ignoreCase = true) ||
                            result.startsWith("Action Error", ignoreCase = true)
                        ) {
                            throw IllegalStateException(result)
                        }
                    }
                } catch (e: Exception) {
                    errors += "Line ${index + 1}: ${e.message ?: e.javaClass.simpleName}"
                }
            }

            if (stoppedBySpeech) {
                "Kotlin script stopped by adbspeech.txt"
            } else if (errors.isNotEmpty()) {
                errorFile.writeText(errors.joinToString("\n") + "\n", Charsets.UTF_8)
                "Kotlin script completed with ${errors.size} error(s)"
            } else {
                "Kotlin script completed successfully"
            }
        } catch (e: Exception) {
            val message = "Script error: ${e.message ?: e.javaClass.simpleName}"
            try {
                errorFile.writeText(message, Charsets.UTF_8)
            } catch (_: Exception) {}
            "Kotlin Error: $message"
        }
    }

    private fun splitScriptArguments(raw: String): List<String> {
        if (raw.trim().isEmpty()) return emptyList()
        return raw.split(",").map { it.trim().trim('"', '\'') }
    }

    private fun isSpeechStopRequested(directory: File): Boolean {
        return try {
            File(directory, "adbspeech.txt").readText().trim() == "stop"
        } catch (_: Exception) {
            false
        }
    }

    private fun checkMainScreen(): String {
        val directory = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
            "Screenshots"
        )
        return try {
            val arrayFile = File(directory, "abruhscreen.kt")
            val currentFile = sequenceOf(
                File(directory, "amanualscreenFin.jpeg"),
                File(directory, "screenToAppear22.png")
            ).firstOrNull { it.exists() }
                ?: return "Error: No current screenshot found"
            val referenceFile = File(
                directory,
                "Screenshot_20260821_194254_Solitaire Verse.jpg"
            )
            if (!arrayFile.exists()) return "Error: abruhscreen.kt not found"
            if (!referenceFile.exists()) return "Error: Main-screen reference image not found"

            val pointsText = arrayFile.readText()
                .substringAfter("val ismainscreen", "")
                .substringBefore("stopIfSpeech()")
            val pointRegex = Regex("""listOf\(\s*(-?\d+)\s*,\s*(-?\d+)\s*\)""")
            val points = pointRegex.findAll(pointsText)
                .map { it.groupValues[1].toInt() to it.groupValues[2].toInt() }
                .toList()
            if (points.isEmpty()) return "Error: No ismainscreen coordinates found"

            val current = BitmapFactory.decodeFile(currentFile.absolutePath)
                ?: return "Error: Cannot read current screenshot"
            val reference = BitmapFactory.decodeFile(referenceFile.absolutePath)
                ?: return "Error: Cannot read reference screenshot"

            var compared = 0
            var matching = 0
            points.forEach { (x, y) ->
                if (x in 0 until current.width && y in 0 until current.height &&
                    x in 0 until reference.width && y in 0 until reference.height
                ) {
                    compared++
                    if (current.getPixel(x, y) == reference.getPixel(x, y)) matching++
                }
            }
            current.recycle()
            reference.recycle()
            if (compared == 0) return "Error: No coordinates fit the screenshot dimensions"

            val percentage = matching * 100.0 / compared
            if (percentage > 75.0) {
                "Success: Main screen match ${"%.2f".format(java.util.Locale.US, percentage)}% ($matching/$compared)"
            } else {
                "Warning: Main screen match ${"%.2f".format(java.util.Locale.US, percentage)}% ($matching/$compared)"
            }
        } catch (e: Exception) {
            "Error: Main-screen comparison failed: ${e.message}"
        }
    }

    private fun checkSpot(data: String): String {
        val directory = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
            "Screenshots"
        )
        return try {
            val args = splitScriptArguments(data)
            if (args.size !in 3..4) {
                return "Error: checkSpot expects x,y,referenceImage[,currentImage]"
            }
            val x = args[0].toIntOrNull()
                ?: return "Error: checkSpot x is not an integer"
            val y = args[1].toIntOrNull()
                ?: return "Error: checkSpot y is not an integer"
            val referenceFile = File(directory, args[2])
            val currentFile = if (args.size == 4 && args[3] != "im3") {
                File(directory, args[3])
            } else {
                File(directory, "amanualscreenFin.jpeg")
            }
            if (!referenceFile.exists()) {
                return "Error: checkSpot reference image not found: ${referenceFile.name}"
            }
            if (!currentFile.exists()) {
                return "Error: checkSpot current image not found: ${currentFile.name}"
            }

            val reference = BitmapFactory.decodeFile(referenceFile.absolutePath)
                ?: return "Error: Cannot read checkSpot reference image"
            val current = BitmapFactory.decodeFile(currentFile.absolutePath)
                ?: return "Error: Cannot read checkSpot current image"

            var compared = 0
            var matching = 0
            for (row in y - 30 until y + 30) {
                for (column in x - 30 until x + 30) {
                    if (column in 0 until reference.width &&
                        row in 0 until reference.height &&
                        column in 0 until current.width &&
                        row in 0 until current.height
                    ) {
                        compared++
                        if (reference.getPixel(column, row) == current.getPixel(column, row)) {
                            matching++
                        }
                    }
                }
            }
            reference.recycle()
            current.recycle()
            if (compared == 0) return "Error: checkSpot window is outside image bounds"

            val percentage = matching * 100.0 / compared
            "Success: checkSpot ($x,$y) match ${"%.2f".format(java.util.Locale.US, percentage)}% ($matching/$compared)"
        } catch (e: Exception) {
            "Error: checkSpot failed: ${e.message}"
        }
    }

    private fun runAwhileLoop(): String {
        val directory = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
            "Screenshots"
        )
        val referenceChecks = listOf(
            "Screenshot_20260822_122608_Solitaire Verse.jpg" to Pair(997, 190),
            "Screenshot_20260823_141708_JustPlay.jpg" to Pair(960, 380),
            "Screenshot_20260822_121758_Solitaire Verse.jpg" to Pair(1010, 170),
            "Screenshot_20260822_121741_Solitaire Verse.jpg" to Pair(600, 1900),
            "Screenshot_20260822_121647_Solitaire Verse.jpg" to Pair(600, 1900),
            "Screenshot_20260822_121043_Google Play Store.jpg" to Pair(600, 1900),
            "Screenshot_20260822_121637_Solitaire Verse.jpg" to Pair(997, 220),
            "Screenshot_20260822_121129_Solitaire Verse.jpg" to Pair(1010, 150),
            "Screenshot_20260822_121043_Google Play Store.jpg" to Pair(1010, 150)
        )
        val xiyi = listOf(Pair(30, 566), Pair(200, 565), Pair(360, 565),
            Pair(520, 565), Pair(690, 565), Pair(820, 565), Pair(970, 565))
        val xiyiUpper = listOf(Pair(655, 300), Pair(725, 300), Pair(725, 300))
        val totalRush = listOf(xiyi, xiyiUpper)
        var h = readSequence(directory)
        var somei = -1
        var firsti = 0
        var someinc = 0
        var gameCount = 0

        return try {
            while (true) {
                if (isSpeechStopRequested(directory)) {
                    return "Awhile stopped by adbspeech.txt"
                }
                val currentFile = sequenceOf(
                    File(directory, "amanualscreenFin.jpeg"),
                    File(directory, "screenToAppear22.png")
                ).firstOrNull { it.exists() }
                if (currentFile == null) {
                    Thread.sleep(1000)
                    continue
                }

                val mainMatch = percentageFromResult(checkMainScreen())
                val spotMatches = referenceChecks.map { (name, point) ->
                    percentageFromResult(
                        checkSpot("${point.first},${point.second},$name,im3")
                    )
                }
                val centerMatch = percentageFromResult(
                    checkSpot("100,1400,dolphin15.jpeg,im3")
                )

                if (mainMatch < 70.0) {
                    val bestIndex = spotMatches.indices.maxByOrNull { spotMatches[it] } ?: -1
                    if (bestIndex >= 0) {
                        val best = spotMatches[bestIndex]
                        if (best >= 0.0) {
                            val point = referenceChecks[bestIndex].second
                            if (bestIndex == 5 || bestIndex == 8) {
                                h = writeAwhileCommand(directory, h, "3")
                                Thread.sleep(2000)
                                h = writeAwhileCommand(directory, h, "tap 100 500")
                                Thread.sleep(10000)
                            } else {
                                h = writeAwhileCommand(directory, h, "tap ${point.first} ${point.second}")
                            }
                        }
                    }
                }

                if (centerMatch < 73.0) {
                    h = writeAwhileCommand(directory, h, "3")
                    Thread.sleep(2000)
                    h = writeAwhileCommand(directory, h, "tap 100 500")
                    Thread.sleep(10000)
                }

                if (mainMatch > 73.0) {
                    if (gameCount == 15) return "Awhile completed 15 games"
                    somei++
                    if (somei >= totalRush[firsti].size) {
                        somei = 0
                        gameCount++
                        someinc += 10
                        h = writeAwhileCommand(directory, h, "tap 970 300")
                        repeat(4) {
                            val point = totalRush[firsti][2]
                            h = writeAwhileCommand(
                                directory,
                                h,
                                "tap ${point.first} ${point.second + someinc}"
                            )
                        }
                        if (someinc == 1000) someinc = 0
                        if (firsti >= totalRush.size) firsti = 0
                    }
                    Thread.sleep(2000)
                    val point = totalRush[firsti][somei]
                    h = writeAwhileCommand(
                        directory,
                        h,
                        "tap ${point.first} ${point.second + someinc}"
                    )
                }
                Thread.sleep(2000)
            }
            "Awhile loop ended"
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
            "Awhile interrupted"
        } catch (e: Exception) {
            "Error: Awhile loop failed: ${e.message}"
        }
    }

    private fun readSequence(directory: File): Int {
        return File(directory, "lastseq.txt").readText().trim().toIntOrNull() ?: 0
    }

    private fun writeAwhileCommand(directory: File, current: Int, command: String): Int {
        val next = current + 1
        File(directory, "adbcom.txt").writeText("$command $next")
        File(directory, "lastseq.txt").writeText(next.toString())
        return next
    }

    private fun percentageFromResult(result: String): Double {
        return Regex("""match\s+([0-9]+(?:\.[0-9]+)?)%""")
            .find(result)?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0
    }

    private fun triggerHome(): String {
        val svc = accessibilityService
        return if (svc != null) {
            val ok = svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            if (ok) "Success: Navigated to Home Screen" else "Error: performGlobalAction(HOME) returned false"
        } else {
            val ctx = getContext() ?: return "Error: No context"
            triggerHomeIntent(ctx)
        }
    }

    private fun triggerScreenshot(): String {
        val svc = accessibilityService
        return if (svc != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val ok = svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
            if (ok) "Success: Screenshot taken" else "Error: performGlobalAction(SCREENSHOT) returned false"
        } else {
            val ctx = getContext() ?: return "Error: No context"
            triggerNativeScreenshot(ctx)
        }
    }

    private fun getContext(): android.app.Application? = try {
        val at = Class.forName("android.app.ActivityThread")
        val cur = at.getDeclaredMethod("currentActivityThread").apply { isAccessible = true }.invoke(null)
        at.getDeclaredMethod("getApplication").apply { isAccessible = true }.invoke(cur) as android.app.Application
    } catch (_: Exception) { null }

    /**
     * MediaProjection permission must be requested by an Activity. If a
     * command arrives while the app UI is closed, bring MainActivity forward
     * so its existing permission flow can show the system approval dialog.
     */
    private fun openMainActivityForScreenCapture(action: String) {
        try {
            val context = getContext() ?: return
            val intent = android.content.Intent(context, MainActivity::class.java).apply {
                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                putExtra(MainActivity.EXTRA_REQUEST_SCREEN_CAPTURE, true)
                putExtra(MainActivity.EXTRA_SCREEN_CAPTURE_ACTION, action)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            android.util.Log.e("HomeScriptRunner", "Unable to open MainActivity for capture permission", e)
        }
    }

    private fun getInputManagerAndInjectMethod(): Pair<Any, java.lang.reflect.Method> {
        val cls = Class.forName("android.hardware.input.InputManager")
        val instance = cls.getDeclaredMethod("getInstance").apply { isAccessible = true }.invoke(null)
        val inject = cls.getDeclaredMethod("injectInputEvent", android.view.InputEvent::class.java, Int::class.java).apply { isAccessible = true }
        return Pair(instance, inject)
    }

    private fun injectMotionEvent(im: Any, inject: java.lang.reflect.Method, action: Int, x: Float, y: Float, downTime: Long, eventTime: Long) {
        val e = MotionEvent.obtain(downTime, eventTime, action, x, y, 0).also { it.source = InputDevice.SOURCE_TOUCHSCREEN }
        inject.invoke(im, e, 0); e.recycle()
    }

    private fun triggerHomeIntent(context: android.app.Application): String {
        val intentClass = Class.forName("android.content.Intent")
        val intent = intentClass.getConstructor(String::class.java).newInstance("android.intent.action.MAIN")
        intentClass.getDeclaredMethod("addCategory", String::class.java).invoke(intent, "android.intent.category.HOME")
        intentClass.getDeclaredMethod("setFlags", Int::class.java).invoke(intent, 0x10000000)
        context.javaClass.getMethod("startActivity", intentClass).invoke(context, intent)
        return "Success: Navigated to Home Screen"
    }

    private fun triggerNativeScreenshot(context: android.app.Application): String {
        return try {
            val wmClass = Class.forName("android.view.WindowManagerGlobal")
            val wmInstance = wmClass.getDeclaredMethod("getInstance").apply { isAccessible = true }.invoke(null)
            @Suppress("UNCHECKED_CAST")
            val views = wmClass.getDeclaredField("mViews").apply { isAccessible = true }.get(wmInstance) as? ArrayList<android.view.View>
            if (views.isNullOrEmpty()) return "Error: No root views found"
            val view = views.last()
            if (view.width == 0 || view.height == 0) return "Error: View has no dimensions"
            var result = "Error: Screenshot timed out"
            val latch = CountDownLatch(1)
            Handler(Looper.getMainLooper()).post {
                try {
                    val bitmap = Bitmap.createBitmap(view.width, view.height, Bitmap.Config.ARGB_8888)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        val surface = getSurface(view)
                        if (surface != null && surface.isValid) {
                            android.view.PixelCopy.request(surface, android.graphics.Rect(0, 0, view.width, view.height), bitmap, { cr ->
                                result = if (cr == android.view.PixelCopy.SUCCESS) saveBitmap(context, bitmap) else "Error: PixelCopy failed ($cr)"
                                latch.countDown()
                            }, Handler(Looper.getMainLooper()))
                            return@post
                        }
                    }
                    view.draw(Canvas(bitmap)); result = saveBitmap(context, bitmap); latch.countDown()
                } catch (e: Exception) { result = "Screenshot Error: ${e.message}"; latch.countDown() }
            }
            latch.await(10, TimeUnit.SECONDS); result
        } catch (e: Exception) { "Screenshot Error: ${e.message}" }
    }

    private fun getSurface(view: android.view.View): android.view.Surface? {
        return try {
            val ai = android.view.View::class.java.getDeclaredField("mAttachInfo").apply { isAccessible = true }.get(view) ?: return null
            val vri = ai.javaClass.getDeclaredField("mViewRootImpl").apply { isAccessible = true }.get(ai) ?: return null
            vri.javaClass.getDeclaredField("mSurface").apply { isAccessible = true }.get(vri) as? android.view.Surface
        } catch (_: Exception) { null }
    }

    private fun saveBitmap(context: android.app.Application, bitmap: Bitmap): String {
        val fileName = "screenshot_${System.currentTimeMillis()}.png"
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = android.content.ContentValues().apply {
                put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, fileName)
                put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(android.provider.MediaStore.Images.Media.RELATIVE_PATH, "DCIM/Screenshots")
                put(android.provider.MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = context.contentResolver.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return "Error: MediaStore insert failed"
            context.contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            values.clear(); values.put(android.provider.MediaStore.Images.Media.IS_PENDING, 0)
            context.contentResolver.update(uri, values, null, null)
            "Success: Screenshot saved to DCIM/Screenshots/$fileName"
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), "Screenshots").also { it.mkdirs() }
            val file = File(dir, fileName)
            FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            android.media.MediaScannerConnection.scanFile(context, arrayOf(file.absolutePath), arrayOf("image/png"), null)
            "Success: Screenshot saved to ${file.absolutePath}"
        }
    }

    // Tap rewritten to use dispatchGesture (same API as swipe) — the old
    // InputManager reflection path was silently failing on this device.
    // A zero-movement stroke at (x,y) with a 100 ms duration is a reliable tap.
    @Suppress("NewApi")
    private fun simulateViewTap(coordinates: String): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N)
            return "Tap Error: Requires Android 7+"
        val svc = accessibilityService ?: return "Tap Error: No accessibility service"
        return try {
            val parts = coordinates.split(",")
            if (parts.size < 2) return "Tap Error: Expected 'x,y'"
            val x = parts[0].trim().toFloat()
            val y = parts[1].trim().toFloat()
            val path   = Path().apply { moveTo(x, y); lineTo(x, y) }
            val stroke  = GestureDescription.StrokeDescription(path, 0L, 100L)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            val ok = svc.dispatchGesture(gesture, null, null)
            if (ok) "Success: Tapped at ($x, $y)" else "Tap Error: dispatchGesture returned false"
        } catch (e: Exception) { "Tap Error: ${e.message}" }
    }

    @Suppress("NewApi")
    private fun simulateViewSwipe(coordinates: String): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N)
            return "Swipe Error: Requires Android 7+"
        val svc = accessibilityService ?: return "Swipe Error: No accessibility service"
        return try {
            val parts = coordinates.split(",")
            if (parts.size < 4) return "Swipe Error: Expected 'x1,y1,x2,y2'"
            val x1  = parts[0].trim().toFloat(); val y1 = parts[1].trim().toFloat()
            val x2  = parts[2].trim().toFloat(); val y2 = parts[3].trim().toFloat()
            val dur = if (parts.size >= 5) parts[4].trim().toLong() else 300L
            val path   = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
            val stroke  = GestureDescription.StrokeDescription(path, 0L, dur)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            val ok = svc.dispatchGesture(gesture, null, null)
            if (ok) "Success: Swiped from ($x1,$y1) to ($x2,$y2)"
            else "Swipe Error: dispatchGesture returned false"
        } catch (e: Exception) { "Swipe Error: ${e.message}" }
    }

    // Reads DCIM/Screenshots/adbmulti.txt, parses [[x,y],[x,y],...] and taps
    // each coordinate in order. Each tap waits for the gesture callback before
    // the next is dispatched — no added delay between taps beyond gesture completion.
    @Suppress("NewApi")
    private fun simulateMultiTap(): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N)
            return "Multi Error: Requires Android 7+"
        val svc = accessibilityService ?: return "Multi Error: No accessibility service"
        return try {
            val file = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
                "Screenshots/adbmulti.txt"
            )
            if (!file.exists()) return "Multi Error: adbmulti.txt not found"
            val raw = file.readText().trim()
            val coords = parseMultiTapCoords(raw)
            if (coords.isEmpty()) return "Multi Error: No valid coordinates in adbmulti.txt"

            android.util.Log.i("HomeScriptRunner", "Multi-tap: ${coords.size} points — $coords")

            for ((x, y) in coords) {
                val latch = CountDownLatch(1)
                val path    = Path().apply { moveTo(x, y); lineTo(x, y) }
                val stroke  = GestureDescription.StrokeDescription(path, 0L, 100L)
                val gesture = GestureDescription.Builder().addStroke(stroke).build()
                val dispatched = svc.dispatchGesture(
                    gesture,
                    object : AccessibilityService.GestureResultCallback() {
                        override fun onCompleted(gestureDescription: GestureDescription?) { latch.countDown() }
                        override fun onCancelled(gestureDescription: GestureDescription?) { latch.countDown() }
                    },
                    null
                )
                if (!dispatched) {
                    android.util.Log.w("HomeScriptRunner", "Multi-tap: dispatchGesture returned false at ($x,$y)")
                }
                // Wait for this gesture to finish before sending the next one.
                // Timeout of 2 s per tap so a stuck callback never hangs the whole sequence.
                latch.await(2, TimeUnit.SECONDS)
            }
            "Success: Multi-tapped ${coords.size} points"
        } catch (e: Exception) { "Multi Error: ${e.message}" }
    }

    // Parses [[x,y],[x,y],...] — tolerates spaces and single/double bracket variants.
    // Each pair must have at least two comma-separated numeric values.
    private fun parseMultiTapCoords(raw: String): List<Pair<Float, Float>> {
        // Strip the outer brackets so we get "x,y],[x,y" or "x,y" etc.
        val stripped = raw.trim().removePrefix("[").removeSuffix("]")
        if (stripped.isBlank()) return emptyList()
        // Split on "],[" to separate pairs; each item may still have leading/trailing brackets.
        return stripped.split("],[").mapNotNull { item ->
            val clean = item.trim('[', ']', ' ')
            val parts = clean.split(",")
            val x = parts.getOrNull(0)?.trim()?.toFloatOrNull()
            val y = parts.getOrNull(1)?.trim()?.toFloatOrNull()
            if (x != null && y != null) Pair(x, y) else null
        }
    }

    // Reads text from DCIM/Screenshots/adbclip.txt into the system clipboard.
    private fun readAdbClipAndSetClipboard(context: android.content.Context): String {
        return try {
            val dcimDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM)
            val clipFile = File(dcimDir, "Screenshots/adbclip.txt")
            if (!clipFile.exists()) {
                return "Error: adbclip.txt not found at ${clipFile.absolutePath}"
            }

            val textToCopy = clipFile.readText().trim()
            if (textToCopy.isEmpty()) {
                return "Warning: adbclip.txt is empty. Clipboard not updated."
            }

            val clipboard = context.getSystemService(
                android.content.Context.CLIPBOARD_SERVICE
            ) as android.content.ClipboardManager
            clipboard.setPrimaryClip(
                android.content.ClipData.newPlainText("AlbatrossOneClip", textToCopy)
            )
            "Success: Copied text content to system clipboard"
        } catch (e: Exception) {
            "Error: Clipboard pipeline failed (${e.message})"
        }
    }
}
