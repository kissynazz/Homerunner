package com.albatrossone

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.system.Os
import android.view.Display
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Captures the current display through AccessibilityService.takeScreenshot().
 *
 * The capture is converted from the ScreenshotResult hardware buffer to a
 * software bitmap and written as a JPEG.  Writes go through a temporary file
 * and an atomic rename so a reader never sees a partially-written frame.
 *
 * Output:
 *   /storage/emulated/0/Download/ManualScreen/amanualScreen.jpeg  (write-in-progress)
 *   /storage/emulated/0/Download/ManualScreen/amanualscreenFin.jpeg (ready to read)
 *
 * JPEG is used instead of PNG because stream mode rewrites this file frequently
 * and JPEG is substantially smaller and faster to write.
 */
object ManualScreenCapture {

    private const val TAG = "ManualScreenCapture"
    private const val TEMP_FILE_NAME = "amanualScreen.jpeg"
    private const val READY_FILE_NAME = "amanualscreenFin.jpeg"
    private const val FRAME_INTERVAL_MS = 250L
    private const val SINGLE_CAPTURE_TIMEOUT_SECONDS = 10L

    private val captureThread = HandlerThread("ManualScreenCapture").apply { start() }
    private val captureHandler = Handler(captureThread.looper)
    private val callbackExecutor = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "ManualScreenCallback").apply { isDaemon = true }
    }

    private val stateLock = Any()
    @Volatile private var streaming = false
    @Volatile private var service: AccessibilityService? = null

    private val streamRunnable = object : Runnable {
        override fun run() {
            val currentService = service
            if (!streaming || currentService == null) return

            requestScreenshot(currentService,
                onSuccess = { bitmap ->
                    if (streaming) {
                        saveBitmap(currentService, bitmap)
                    }
                    bitmap.recycle()
                    if (streaming) captureHandler.postDelayed(this, FRAME_INTERVAL_MS)
                },
                onFailure = { errorCode ->
                    android.util.Log.w(TAG, "Stream screenshot failed: $errorCode")
                    if (streaming) captureHandler.postDelayed(this, FRAME_INTERVAL_MS)
                }
            )
        }
    }

    /**
     * Capture exactly one frame.  Any active stream is stopped first.
     * This method is synchronous because command callers log the result.
     */
    fun captureOne(accessibilityService: AccessibilityService): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            return "Error: Manual screen capture requires Android 11+"
        }

        stopStream()
        service = accessibilityService

        val latch = CountDownLatch(1)
        var result = "Error: Screenshot timed out"
        requestScreenshot(accessibilityService,
            onSuccess = { bitmap ->
                result = saveBitmap(accessibilityService, bitmap)
                bitmap.recycle()
                latch.countDown()
            },
            onFailure = { errorCode ->
                result = "Error: Screenshot failed ($errorCode)"
                latch.countDown()
            }
        )

        try {
            latch.await(SINGLE_CAPTURE_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
            return "Error: Screenshot interrupted"
        }
        return result
    }

    /**
     * Start updating the fixed output file until stopStream() is called.
     */
    fun startStream(accessibilityService: AccessibilityService): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            return "Error: Manual screen capture requires Android 11+"
        }

        synchronized(stateLock) {
            service = accessibilityService
            if (streaming) return "Success: Manual screen stream already running"
            streaming = true
            captureHandler.removeCallbacks(streamRunnable)
            captureHandler.post(streamRunnable)
        }
        return "Success: Manual screen stream started"
    }

    fun stopStream() {
        synchronized(stateLock) {
            streaming = false
            captureHandler.removeCallbacks(streamRunnable)
        }
    }

    fun isStreaming(): Boolean = streaming

    @Suppress("NewApi")
    private fun requestScreenshot(
        accessibilityService: AccessibilityService,
        onSuccess: (Bitmap) -> Unit,
        onFailure: (Int) -> Unit
    ) {
        try {
            accessibilityService.takeScreenshot(
                Display.DEFAULT_DISPLAY,
                callbackExecutor,
                object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(
                        screenshotResult: AccessibilityService.ScreenshotResult
                    ) {
                        val hardwareBuffer = screenshotResult.hardwareBuffer
                        try {
                            val hardwareBitmap = Bitmap.wrapHardwareBuffer(
                                hardwareBuffer,
                                screenshotResult.colorSpace
                            )
                            val bitmap = hardwareBitmap?.copy(Bitmap.Config.ARGB_8888, false)
                            hardwareBitmap?.recycle()
                            if (bitmap == null) {
                                onFailure(-1)
                            } else {
                                onSuccess(bitmap)
                            }
                        } catch (e: Exception) {
                            android.util.Log.e(TAG, "Could not convert screenshot buffer", e)
                            onFailure(-1)
                        } finally {
                            hardwareBuffer.close()
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        onFailure(errorCode)
                    }
                }
            )
        } catch (e: Exception) {
            android.util.Log.e(TAG, "Could not request screenshot", e)
            onFailure(-1)
        }
    }

    @Suppress("DEPRECATION")
    private fun outputDirectory(): File {
        val directory = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "ManualScreen"
        )
        if (!directory.exists()) directory.mkdirs()
        return directory
    }

    private fun saveBitmap(
        accessibilityService: AccessibilityService,
        bitmap: Bitmap
    ): String {
        val directory = outputDirectory()
        val temporary = File(directory, TEMP_FILE_NAME)
        val ready = File(directory, READY_FILE_NAME)
        return try {
            // Only this file is written while compression is in progress.
            val compressed = FileOutputStream(temporary).use { output ->
                val ok = bitmap.compress(Bitmap.CompressFormat.JPEG, 100, output)
                output.flush()
                output.fd.sync()
                ok
            }
            if (!compressed) {
                temporary.delete()
                "Error: JPEG compression failed"
            } else {
                // Same-directory rename replaces the previous ready file atomically.
                // The reader therefore sees either the old complete JPEG or the new
                // complete JPEG, never a partially-written file.
                Os.rename(temporary.absolutePath, ready.absolutePath)

                android.media.MediaScannerConnection.scanFile(
                    accessibilityService,
                    arrayOf(ready.absolutePath),
                    arrayOf("image/jpeg"),
                    null
                )
                "Success: Manual screen saved to ${ready.absolutePath}"
            }
        } catch (e: Exception) {
            temporary.delete()
            android.util.Log.e(TAG, "Could not save manual screen", e)
            "Error: Could not save manual screen (${e.message})"
        }
    }
}