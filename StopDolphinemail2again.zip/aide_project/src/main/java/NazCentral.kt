package com.albatrossone

import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.ParcelUuid
import java.util.UUID

/**
 * Persistent BLE *central* that connects to the iPad's "nazcontrollerTwo" peripheral
 * (CBPeripheralManager running inside BTCONTROLLA.csx / NazServer).
 *
 * Lifecycle:
 *  1. start() → scan for the NazTwo service UUID
 *  2. Found → connect GATT, discover services
 *  3. Found NazTwoChar → enable notifications (write CCCD)
 *  4. Stay connected — each notification fires onCommand(jsonString)
 *  5. Disconnect for any reason → auto-reconnect after RECONNECT_DELAY_MS
 *  6. stop() → cancel scan, close GATT, cancel any pending reconnect
 *
 * The onCommand callback receives the raw UTF-8 string from the iPad;
 * MyAutomationService routes it through dispatchBlueCommand.
 */
object NazCentral {

    // ── UUIDs — must match Cfg.NazTwoService / Cfg.NazTwoChar in BTCONTROLLA.csx ──
    private val NAZ_TWO_SERVICE = UUID.fromString("A000B000-C000-D000-E000-F00000000005")
    private val NAZ_TWO_CHAR    = UUID.fromString("A000B000-C000-D000-E000-F00000000006")
    private const val TARGET_NAME = "nazcontrollerTwo"

    // Standard BLE Client Characteristic Configuration Descriptor — enables notifications.
    private val CCCD_UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

    private const val SCAN_TIMEOUT_MS    = 20_000L
    private const val RECONNECT_DELAY_MS = 5_000L
    private const val TAG                = "NazCentral"

    // ── State (only touched on main thread or inside synchronized blocks) ─────
    @Volatile private var running      = false
    private var appContext: Context?   = null
    private var onCommand: ((String) -> Unit)? = null

    private var scanner:      BluetoothLeScanner? = null
    private var scanCallback: ScanCallback?       = null
    @Volatile private var gatt: BluetoothGatt?   = null

    private val mainHandler = Handler(Looper.getMainLooper())
    private val reconnectRunnable = Runnable { beginScan() }

    // ── Public API ────────────────────────────────────────────────────────────

    /** Start scanning and maintain a connection for the lifetime of the service. */
    fun start(context: Context, onCommand: (String) -> Unit) {
        if (running) return
        running          = true
        appContext       = context.applicationContext
        this.onCommand   = onCommand
        android.util.Log.i(TAG, "start() — will scan for \"nazcontrollerTwo\"")
        beginScan()
    }

    /** Stop everything — called when MyAutomationService is destroyed. */
    fun stop() {
        running = false
        mainHandler.removeCallbacks(reconnectRunnable)
        mainHandler.post {
            stopScan()
            gatt?.disconnect()
            gatt?.close()
            gatt = null
        }
        android.util.Log.i(TAG, "stop() — NazCentral shut down")
    }

    fun isConnected(): Boolean = gatt != null

    // ── Internal: scan ────────────────────────────────────────────────────────

    private fun beginScan() {
        if (!running) return
        val ctx = appContext ?: return
        val adapter = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)
            ?.adapter
        if (adapter == null || !adapter.isEnabled) {
            android.util.Log.w(TAG, "Bluetooth not ready — retry in ${RECONNECT_DELAY_MS}ms")
            scheduleReconnect(); return
        }
        scanner = adapter.bluetoothLeScanner
        if (scanner == null) { scheduleReconnect(); return }

        // Scan with NO filter — iOS CBPeripheralManager with a 128-bit service UUID
        // does not reliably include the UUID in the advertisement packet, so a
        // service-UUID filter produces zero results.  Instead we scan for everything
        // and match on the advertised local name "nazcontrollerTwo".
        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()

        scanCallback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val name = result.device.name
                    ?: result.scanRecord?.deviceName
                    ?: return
                android.util.Log.d(TAG, "BLE device seen: $name (${result.device.address})")
                if (name != TARGET_NAME) return
                android.util.Log.i(TAG, "Found nazcontrollerTwo! Connecting...")
                stopScan()
                connectGatt(result.device)
            }
            override fun onScanFailed(errorCode: Int) {
                android.util.Log.e(TAG, "Scan failed: $errorCode")
                scanCallback = null
                scheduleReconnect()
            }
        }

        android.util.Log.i(TAG, "Scanning (no filter) for \"$TARGET_NAME\"...")
        try {
            scanner?.startScan(null, settings, scanCallback!!)
        } catch (e: Exception) {
            // SecurityException if BLUETOOTH_SCAN permission is missing, or other errors.
            // Log and back off — do NOT propagate; callers (e.g. onServiceConnected) must
            // finish their own setup regardless of whether NazCentral is available.
            android.util.Log.e(TAG, "startScan failed: ${e.message} — retrying later")
            scanCallback = null; scheduleReconnect(); return
        }

        // Safety timeout — stop scan and retry if iPad isn't found quickly.
        mainHandler.postDelayed({
            if (scanCallback != null) {
                android.util.Log.w(TAG, "Scan timed out — retrying")
                stopScan(); scheduleReconnect()
            }
        }, SCAN_TIMEOUT_MS)
    }

    private fun stopScan() {
        try { scanCallback?.let { scanner?.stopScan(it) } } catch (_: Exception) {}
        scanCallback = null
    }

    // ── Internal: GATT connection ─────────────────────────────────────────────

    private fun connectGatt(device: BluetoothDevice) {
        if (!running) return
        val ctx = appContext ?: return
        android.util.Log.i(TAG, "Connecting GATT to ${device.address}...")
        gatt = device.connectGatt(ctx, /*autoConnect=*/false, gattCallback, BluetoothDevice.TRANSPORT_LE)
    }

    private val gattCallback = object : BluetoothGattCallback() {

        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            // Guard against stale callbacks from a superseded connection object.
            if (g !== gatt && newState != BluetoothProfile.STATE_DISCONNECTED) return
            when (newState) {
                BluetoothProfile.STATE_CONNECTED -> {
                    android.util.Log.i(TAG, "Connected — discovering services")
                    g.discoverServices()
                }
                BluetoothProfile.STATE_DISCONNECTED -> {
                    android.util.Log.w(TAG, "Disconnected (status=$status)")
                    // Only tear down state if this is still the current gatt object.
                    if (g === gatt) { gatt = null }
                    g.close()
                    if (running) scheduleReconnect()
                }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            if (g !== gatt) return   // stale callback
            if (status != BluetoothGatt.GATT_SUCCESS) {
                android.util.Log.e(TAG, "Service discovery failed ($status) — retrying")
                g.disconnect(); return
            }
            val svc  = g.getService(NAZ_TWO_SERVICE)
            val char = svc?.getCharacteristic(NAZ_TWO_CHAR)
            if (char == null) {
                android.util.Log.e(TAG, "NazTwoChar not found — retrying")
                g.disconnect(); return
            }
            // Enable local notifications on Android side.
            g.setCharacteristicNotification(char, true)
            // Write CCCD to tell the iPad we want notifications.
            val desc = char.getDescriptor(CCCD_UUID)
            if (desc != null) {
                desc.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                val wrote = g.writeDescriptor(desc)
                android.util.Log.i(TAG, "CCCD write queued: $wrote")
            } else {
                // CCCD missing — rely on local setCharacteristicNotification only.
                android.util.Log.w(TAG, "CCCD descriptor not found; relying on local notification enable")
            }
        }

        override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, status: Int) {
            if (g !== gatt) return   // stale callback
            if (descriptor.uuid == CCCD_UUID) {
                if (status == BluetoothGatt.GATT_SUCCESS) {
                    android.util.Log.i(TAG, "✓ Subscribed to NazTwoChar — gamepad link ready")
                } else {
                    android.util.Log.w(TAG, "CCCD write failed ($status) — will still try to receive")
                }
            }
        }

        override fun onCharacteristicChanged(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic
        ) {
            if (g !== gatt) return   // stale callback
            if (characteristic.uuid != NAZ_TWO_CHAR) return
            val text = characteristic.value?.toString(Charsets.UTF_8) ?: return
            onCommand?.invoke(text)
        }

    }

    // ── Internal: reconnect ────────────────────────────────────────────────────

    private fun scheduleReconnect() {
        if (!running) return
        android.util.Log.i(TAG, "Reconnecting in ${RECONNECT_DELAY_MS}ms...")
        mainHandler.removeCallbacks(reconnectRunnable)
        mainHandler.postDelayed(reconnectRunnable, RECONNECT_DELAY_MS)
    }
}
