package com.albatrossone

import android.content.Context
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.ToneGenerator
import java.lang.ref.WeakReference

/**
 * Plays sounds for automation events.
 *
 * playCommandFired() — picks a random MP3 from assets/jsounds/ and plays it.
 *   If a jsound is already playing, the call blocks until it finishes before
 *   starting the next one (so sounds are never overlapping and never skipped).
 *   Falls back to the original ToneGenerator beep if no MP3s are found or
 *   if the context has not been initialised yet.
 *
 * playFileChanged() — unchanged short beep via ToneGenerator.
 *
 * Call init(context) once (e.g. in MyAutomationService.onServiceConnected)
 * before playCommandFired() is used.
 */
object SoundPlayer {

    private var contextRef: WeakReference<Context>? = null

    // Java Object used as a monitor so we can call .wait() / .notifyAll().
    private val soundLock = java.lang.Object()

    @Volatile private var isPlaying = false
    private var currentPlayer: MediaPlayer? = null

    /** Must be called before playCommandFired() can use MP3s. */
    fun init(context: Context) {
        contextRef = WeakReference(context.applicationContext)
    }

    /**
     * Plays a random MP3 from assets/jsounds/.
     * Blocks until any currently playing sound finishes, then plays the next one.
     * Runs on the calling thread — wrap in Thread { } at the call site if needed.
     */
    fun playCommandFired() {
        Thread {
            try {
                val ctx = contextRef?.get()
                synchronized(soundLock) {
                    // Wait for any in-progress sound to finish.
                    while (isPlaying) {
                        @Suppress("PLATFORM_CLASS_MAPPED_TO_KOTLIN")
                        (soundLock as java.lang.Object).wait(500)
                    }
                    if (ctx != null) {
                        playRandomJSound(ctx)
                    } else {
                        // Context not yet set — use tone fallback (runs inside lock, blocking).
                        playCommandFiredFallback()
                    }
                }
            } catch (e: InterruptedException) {
                Thread.currentThread().interrupt()
            } catch (e: Exception) {
                android.util.Log.e("SoundPlayer", "playCommandFired error: ${e.message}")
            }
        }.apply { name = "SoundPlayer-cmdFired"; isDaemon = true; start() }
    }

    /**
     * Called while holding soundLock. Picks a random MP3, starts MediaPlayer,
     * and sets isPlaying = true. The OnCompletionListener releases the lock via notifyAll.
     */
    private fun playRandomJSound(ctx: Context) {
        try {
            val assetMgr = ctx.assets
            val sounds = assetMgr.list("jsounds")
                ?.filter { it.endsWith(".mp3", ignoreCase = true) }
            if (sounds.isNullOrEmpty()) {
                android.util.Log.w("SoundPlayer", "No MP3s in assets/jsounds/ — using fallback")
                playCommandFiredFallback()
                return
            }

            val picked = sounds.random()
            android.util.Log.i("SoundPlayer", "Playing jsound: $picked")

            val afd = assetMgr.openFd("jsounds/$picked")
            val player = MediaPlayer()

            @Suppress("DEPRECATION")
            player.setAudioStreamType(AudioManager.STREAM_NOTIFICATION)
            player.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            afd.close()

            val completionAction: (MediaPlayer) -> Unit = { mp ->
                synchronized(soundLock) {
                    isPlaying = false
                    currentPlayer = null
                    mp.release()
                    @Suppress("PLATFORM_CLASS_MAPPED_TO_KOTLIN")
                    (soundLock as java.lang.Object).notifyAll()
                }
            }

            player.setOnCompletionListener { mp -> completionAction(mp) }
            player.setOnErrorListener { mp, what, extra ->
                android.util.Log.e("SoundPlayer", "MediaPlayer error what=$what extra=$extra")
                completionAction(mp)
                true
            }

            player.prepare()   // synchronous for local assets — safe on background thread
            isPlaying = true
            currentPlayer = player
            player.start()

        } catch (e: Exception) {
            android.util.Log.e("SoundPlayer", "playRandomJSound error: ${e.message}")
            isPlaying = false
            @Suppress("PLATFORM_CLASS_MAPPED_TO_KOTLIN")
            (soundLock as java.lang.Object).notifyAll()
            playCommandFiredFallback()
        }
    }

    /** Original ToneGenerator beep — used as fallback when no MP3s are available. */
    private fun playCommandFiredFallback() {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 90)
            tg.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 150)
            Thread.sleep(200)
            tg.startTone(ToneGenerator.TONE_PROP_ACK, 150)
            Thread.sleep(300)
            tg.release()
        } catch (e: Exception) {
            android.util.Log.e("SoundPlayer", "playCommandFiredFallback error: ${e.message}")
        }
    }

    /** Short beep for file-change / BLE events — unchanged. */
    fun playFileChanged() {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 70)
            tg.startTone(ToneGenerator.TONE_PROP_BEEP, 200)
            Thread.sleep(350)
            tg.release()
        } catch (e: Exception) {
            android.util.Log.e("SoundPlayer", "playFileChanged error: ${e.message}")
        }
    }
}
