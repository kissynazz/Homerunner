package com.albatrossone

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Point
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.system.Os
import android.view.WindowManager
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

object ManualScreenCapture {

    private const val TAG = "ManualScreenCapture"
    private const val TEMP_FILE_NAME = "amanualScreen.jpeg"
    private const val READY_FILE_NAME = "amanualscreenFin.jpeg"
    private const val FRAME_INTERVAL_MS = 250L
    private const val SINGLE_CAPTURE_TIMEOUT_SECONDS = 5L

    private val captureThread = HandlerThread("ManualScreenCapture").apply { start() }
    private val captureHandler = Handler(captureThread.looper)
    private val saveExecutor = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "ManualScreenSave").apply { isDaemon = true }
    }

    private val stateLock = Any()
    private val frameLock = Any()
    private val streamSaveInFlight = AtomicBoolean(false)

    @Volatile private var streaming = false
    @Volatile private var lastStreamSaveAt = 0L

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var projectionContext: Context? = null

    private var latestFrame: Bitmap? = null
    private var oneShotLatch: CountDownLatch? = null
    private var oneShotFrame: Bitmap? = null

    // ─── FILE TRACER FOR CAPTURING PIPELINE LOGS IN DCIM ───
    private fun logToFile(message: String) {
        try {
            val dcimDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), "Screenshots")
            if (!dcimDir.exists()) dcimDir.mkdirs()
            val logFile = File(dcimDir, "theoutput.txt")
            val timeStamp = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date())
            logFile.appendText("[$timeStamp] [MediaProjection] $message\n")
        } catch (_: Exception) {}
    }

    fun startProjection(context: Context, resultCode: Int, data: Intent): String {
        logToFile("startProjection() initialized. Handshaking tokens...")
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            val err = "Error: Requires Android 5+"
            logToFile(err)
            return err
        }

        return try {
            synchronized(stateLock) {
                stopProjectionLocked()

                val manager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as? MediaProjectionManager
                    ?: return "Error: MediaProjectionManager missing".also { logToFile(it) }
                val newProjection = manager.getMediaProjection(resultCode, data)
                    ?: return "Error: Token generation failed".also { logToFile(it) }

                val appContext = context.applicationContext
                val displaySize = getDisplaySize(appContext)
                val reader = ImageReader.newInstance(displaySize.x, displaySize.y, PixelFormat.RGBA_8888, 2)

                newProjection.registerCallback(projectionCallback, captureHandler)
                reader.setOnImageAvailableListener({ availableReader -> onImageAvailable(availableReader) }, captureHandler)

                val display = newProjection.createVirtualDisplay(
                    "AlbatrossOneManualScreen", displaySize.x, displaySize.y,
                    appContext.resources.configuration.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    reader.surface, null, captureHandler
                )

                if (display == null) {
                    reader.close()
                    newProjection.stop()
                    val err = "Error: VirtualDisplay binding failed"
                    logToFile(err)
                    return err
                }

                projection = newProjection
                virtualDisplay = display
                imageReader = reader
                projectionContext = appContext
                logToFile("Success: Virtual video pipeline mapped securely! Ready for commands.")
                "Success: Screen capture permission ready"
            }
        } catch (e: Exception) {
            logToFile("Projection launch crashed: ${e.message}")
            "Error: ${e.message}"
        }
    }

    fun hasProjection(): Boolean = projection != null && imageReader != null

    fun captureOne(accessibilityService: android.accessibilityservice.AccessibilityService): String {
        logToFile("bitscreen command registered.")
        if (!hasProjection()) {
            val err = "Error: Approve screen capture permission window inside MainActivity first!"
            logToFile(err)
            return err
        }
        if (!hasStorageAccess()) {
            val err = "Error: All Files Access setting missing."
            logToFile(err)
            return err
        }

        stopStream()

        synchronized(frameLock) {
            val cached = latestFrame
            if (cached != null && !cached.isRecycled) {
                logToFile("RAM contains an active frame buffer. Mirroring to disk instantly.")
                val copy = cached.copy(cached.config, false)
                return saveBitmap(projectionContext ?: accessibilityService, copy)
            }
        }

        logToFile("RAM buffer clear. Synchronizing latch loop for next hardware frame...")
        val latch = CountDownLatch(1)
        synchronized(frameLock) {
            oneShotFrame?.recycle()
            oneShotFrame = null
            oneShotLatch = latch
        }

        try {
            if (!latch.await(SINGLE_CAPTURE_TIMEOUT_SECONDS, TimeUnit.SECONDS)) {
                synchronized(frameLock) {
                    if (oneShotLatch === latch) oneShotLatch = null
                }
                logToFile("CRITICAL FAILURE: Pipeline timed out waiting for ImageReader frame arrival.")
                return "Error: Timed out waiting for screen frame"
            }

            val frame = synchronized(frameLock) {
                val result = oneShotFrame
                oneShotFrame = null
                result
            } ?: return "Error: Frame empty"

            return try {
                saveBitmap(projectionContext ?: accessibilityService, frame)
            } finally {
                frame.recycle()
            }
        } catch (e: Exception) {
            logToFile("Capture processing thread exception: ${e.message}")
            return "Error: ${e.message}"
        }
    }

    fun toggleStream(accessibilityService: android.accessibilityservice.AccessibilityService): String {
        synchronized(stateLock) {
            if (streaming) {
                streaming = false
                logToFile("Stream loop toggle switched OFF.")
                return "Success: Manual screen stream stopped"
            }
        }
        return startStream(accessibilityService)
    }

    private fun startStream(accessibilityService: android.accessibilityservice.AccessibilityService): String {
        if (!hasProjection()) return "Error: No projection configuration active".also { logToFile(it) }
        if (!hasStorageAccess()) return "Error: Storage permissions missing".also { logToFile(it) }

        synchronized(stateLock) {
            if (streaming) return "Success: Already streaming"
            streaming = true
            lastStreamSaveAt = 0L
            logToFile("Stream loop toggle switched ON.")
        }
        return "Success: Manual screen stream started"
    }

    fun stopStream() {
        synchronized(stateLock) { streaming = false }
    }

    fun stopProjection() {
        synchronized(stateLock) { stopProjectionLocked() }
    }

    private fun stopProjectionLocked() {
        logToFile("stopProjectionLocked() triggered. Tearing down video hardware pipeline mappings.")
        streaming = false
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        projection?.stop()
        projection = null
        projectionContext = null
        synchronized(frameLock) {
            latestFrame?.recycle()
            latestFrame = null
            oneShotFrame?.recycle()
            oneShotFrame = null
            oneShotLatch = null
        }
    }

    private fun onImageAvailable(reader: ImageReader) {
        val image = try {
            reader.acquireLatestImage()
        } catch (e: Exception) {
            logToFile("onImageAvailable failed to acquire frame: ${e.message}")
            null
        } ?: return

        val bitmap = try {
            imageToBitmap(image)
        } catch (e: Exception) {
            logToFile("onImageAvailable failed during imageToBitmap conversion: ${e.message}")
            null
        } finally {
            image.close()
        } ?: return

        synchronized(frameLock) {
            latestFrame?.recycle()
            latestFrame = bitmap

            oneShotLatch?.let { latch ->
                logToFile("Active bitscreen latch detected. Dispatching hardware bits instantly.")
                oneShotFrame?.recycle()
                oneShotFrame = bitmap.copy(Bitmap.Config.ARGB_8888, false)
                oneShotLatch = null
                latch.countDown()
            }
        }

        val now = System.currentTimeMillis()
        if (!streaming || now - lastStreamSaveAt < FRAME_INTERVAL_MS) return
        if (!streamSaveInFlight.compareAndSet(false, true)) return

        lastStreamSaveAt = now
        val frameForDisk = bitmap.copy(Bitmap.Config.ARGB_8888, false)
        saveExecutor.execute {
            try {
                saveBitmap(projectionContext, frameForDisk)
            } finally {
                frameForDisk.recycle()
                streamSaveInFlight.set(false)
            }
        }
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val paddedWidth = image.width + rowPadding / pixelStride
        val paddedBitmap = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
        paddedBitmap.copyPixelsFromBuffer(plane.buffer)

        if (paddedWidth == image.width) return paddedBitmap
        val cropped = Bitmap.createBitmap(paddedBitmap, 0, 0, image.width, image.height)
        paddedBitmap.recycle()
        return cropped
    }

    private fun getDisplaySize(context: Context): Point {
        val display = (context.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay
        val point = Point()
        display.getRealSize(point)
        return point
    }

    private fun hasStorageAccess(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.R || Environment.isExternalStorageManager()

    private fun outputDirectory(): File {
        if (!hasStorageAccess()) throw IllegalStateException("All files access permission required.")
        val directory = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "ManualScreen")
        if (!directory.exists() && !directory.mkdirs()) throw IllegalStateException("Directory creation failed")
        return directory
    }

    private fun saveBitmap(context: Context?, bitmap: Bitmap): String {
        val directory = try { outputDirectory() } catch (e: Exception) { 
            logToFile("outputDirectory lookup exception: ${e.message}")
            return "Error: ${e.message}" 
        }
        val temporary = File(directory, TEMP_FILE_NAME)
        val ready = File(directory, READY_FILE_NAME)

        return try {
            val compressed = FileOutputStream(temporary).use { output ->
                val ok = bitmap.compress(Bitmap.CompressFormat.JPEG, 100, output)
                output.flush()
                try { output.fd.sync() } catch (_: Exception) {}
                ok
            }

            if (!compressed) {
                temporary.delete()
                logToFile("JPEG compression routine outputted false flag.")
                "Error: Compression failed"
            } else {
                if (ready.exists()) ready.delete()
                Os.rename(temporary.absolutePath, ready.absolutePath)
                context?.let {
                    android.media.MediaScannerConnection.scanFile(it, arrayOf(ready.absolutePath), arrayOf("image/jpeg"), null)
                }
                logToFile("SUCCESS: Frame written out atomically to ${ready.absolutePath}!")
                "Success: Manual screen saved to ${ready.absolutePath}"
            }
        } catch (e: Exception) {
            temporary.delete()
            logToFile("Disk write engine failed: ${e.message}")
            "Error: ${e.message}"
        }
    }

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            logToFile("MediaProjection callback caught system onStop event wrapper.")
            synchronized(stateLock) { stopProjectionLocked() }
        }
    }
}
