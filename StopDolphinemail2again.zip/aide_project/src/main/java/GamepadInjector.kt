package com.albatrossone

import android.os.SystemClock
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent

/**
 * Injects a 9-byte PS4-format HID gamepad report as Android input events
 * so apps like Dolphin running on the same device can bind to them.
 *
 * Report layout (from SharpBlue/blueblew.csx GamepadState.BuildReport):
 *   [LX, LY, RX, RY, L2, R2, hat&0xF, btnLo, btnHi]
 *
 * Hat values: 0=N 1=NE 2=E 3=SE 4=S 5=SW 6=W 7=NW 8=neutral
 * btnLo bits 0-7  → buttons 0-7   (□ ✕ ○ △ L1 R1 L2▼ R2▼)
 * btnHi bits 0-5  → buttons 8-13  (Share Options L3 R3 PS Touchpad)
 */
object GamepadInjector {

    // Button index → Android KeyEvent keycode
    private val BUTTON_KEYCODES = intArrayOf(
        KeyEvent.KEYCODE_BUTTON_X,       // 0  □  Square
        KeyEvent.KEYCODE_BUTTON_A,       // 1  ✕  Cross
        KeyEvent.KEYCODE_BUTTON_B,       // 2  ○  Circle
        KeyEvent.KEYCODE_BUTTON_Y,       // 3  △  Triangle
        KeyEvent.KEYCODE_BUTTON_L1,      // 4  L1
        KeyEvent.KEYCODE_BUTTON_R1,      // 5  R1
        KeyEvent.KEYCODE_BUTTON_L2,      // 6  L2 (digital)
        KeyEvent.KEYCODE_BUTTON_R2,      // 7  R2 (digital)
        KeyEvent.KEYCODE_BUTTON_SELECT,  // 8  Share
        KeyEvent.KEYCODE_BUTTON_START,   // 9  Options
        KeyEvent.KEYCODE_BUTTON_THUMBL,  // 10 L3
        KeyEvent.KEYCODE_BUTTON_THUMBR,  // 11 R3
        KeyEvent.KEYCODE_BUTTON_MODE,    // 12 PS
        KeyEvent.KEYCODE_UNKNOWN,        // 13 Touchpad (no standard mapping)
    )

    // D-pad hat value → (AXIS_HAT_X, AXIS_HAT_Y)
    private val HAT = arrayOf(
         0f to -1f,  // 0  N
         1f to -1f,  // 1  NE
         1f to  0f,  // 2  E
         1f to  1f,  // 3  SE
         0f to  1f,  // 4  S
        -1f to  1f,  // 5  SW
        -1f to  0f,  // 6  W
        -1f to -1f,  // 7  NW
         0f to  0f,  // 8  neutral
    )

    // Track previous button state so we fire DOWN/UP transitions correctly
    private var prevBtnLo = 0
    private var prevBtnHi = 0

    private var im: Any? = null
    private var injectMethod: java.lang.reflect.Method? = null

    private fun ensureInjector() {
        if (im != null) return
        try {
            val cls = Class.forName("android.hardware.input.InputManager")
            im = cls.getDeclaredMethod("getInstance")
                .apply { isAccessible = true }.invoke(null)
            injectMethod = cls.getDeclaredMethod(
                "injectInputEvent",
                android.view.InputEvent::class.java,
                Int::class.java
            ).apply { isAccessible = true }
            android.util.Log.i("GamepadInjector", "InputManager injector ready")
        } catch (e: Exception) {
            android.util.Log.e("GamepadInjector", "Failed to get InputManager: ${e.message}")
        }
    }

    fun inject(report: ByteArray) {
        if (report.size < 9) return
        ensureInjector()
        val im     = im     ?: return
        val inject = injectMethod ?: return

        val now = SystemClock.uptimeMillis()
        val src = InputDevice.SOURCE_JOYSTICK or InputDevice.SOURCE_GAMEPAD

        // ── Axes (joysticks + triggers + d-pad hat) ───────────────────────────
        // 0-255 byte → -1..1 float for sticks; 0..1 float for triggers
        fun norm(b: Int)  = ((b and 0xFF) - 128) / 128f
        fun trig(b: Int)  = (b and 0xFF) / 255f

        val hat = (report[6].toInt() and 0xFF).coerceIn(0, 8)
        val (hatX, hatY) = HAT[hat]

        val props  = arrayOf(MotionEvent.PointerProperties().also {
            it.id = 0; it.toolType = MotionEvent.TOOL_TYPE_UNKNOWN
        })
        val coords = arrayOf(MotionEvent.PointerCoords().also { c ->
            c.setAxisValue(MotionEvent.AXIS_X,         norm(report[0].toInt()))
            c.setAxisValue(MotionEvent.AXIS_Y,         norm(report[1].toInt()))
            c.setAxisValue(MotionEvent.AXIS_Z,         norm(report[2].toInt()))
            c.setAxisValue(MotionEvent.AXIS_RZ,        norm(report[3].toInt()))
            c.setAxisValue(MotionEvent.AXIS_LTRIGGER,  trig(report[4].toInt()))
            c.setAxisValue(MotionEvent.AXIS_RTRIGGER,  trig(report[5].toInt()))
            c.setAxisValue(MotionEvent.AXIS_HAT_X,     hatX)
            c.setAxisValue(MotionEvent.AXIS_HAT_Y,     hatY)
        })

        val motion = MotionEvent.obtain(
            now, now, MotionEvent.ACTION_MOVE, 1, props, coords,
            0, 0, 1f, 1f, 0, 0, src, 0
        )
        try { inject.invoke(im, motion, 0) } catch (e: Exception) {
            android.util.Log.w("GamepadInjector", "Axis inject failed: ${e.message}")
        }
        motion.recycle()

        // ── Buttons ───────────────────────────────────────────────────────────
        val btnLo = report[7].toInt() and 0xFF
        val btnHi = report[8].toInt() and 0xFF

        // Buttons 0-7 are in btnLo; bit index == button index
        for (i in 0..7) injectButtonChange(im, inject, now, src, i, prevBtnLo, btnLo, shift = i)
        // Buttons 8-13 are in btnHi bits 0-5
        for (i in 0..5) injectButtonChange(im, inject, now, src, i + 8, prevBtnHi, btnHi, shift = i)

        prevBtnLo = btnLo
        prevBtnHi = btnHi
    }

    private fun injectButtonChange(
        im: Any, inject: java.lang.reflect.Method,
        now: Long, src: Int,
        btnIndex: Int, prev: Int, curr: Int, shift: Int
    ) {
        val mask    = 1 shl shift
        val wasDown = (prev and mask) != 0
        val isDown  = (curr and mask) != 0
        if (wasDown == isDown) return

        val kc = BUTTON_KEYCODES.getOrNull(btnIndex) ?: return
        if (kc == KeyEvent.KEYCODE_UNKNOWN) return

        val action = if (isDown) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP
        val ev = KeyEvent(now, now, action, kc, 0, 0, -1, 0, 0, src)
        try { inject.invoke(im, ev, 0) } catch (e: Exception) {
            android.util.Log.w("GamepadInjector", "Button inject failed (btn$btnIndex): ${e.message}")
        }
    }
}
