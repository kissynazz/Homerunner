package com.albatrossone

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import java.io.File

class FileEditorActivity : Activity() {

    companion object {
        const val EXTRA_FILE_PATH = "file_path"
    }

    private lateinit var editContent: EditText
    private lateinit var file: File
    private var originalContent: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_file_editor)

        val path = intent.getStringExtra(EXTRA_FILE_PATH)
        if (path == null) { finish(); return }

        file = File(path)
        editContent = findViewById(R.id.edit_content)
        findViewById<TextView>(R.id.tv_filename).text = file.absolutePath

        // Load file content
        originalContent = try {
            if (file.exists()) file.readText() else ""
        } catch (e: Exception) {
            Toast.makeText(this, "Error reading file: ${e.message}", Toast.LENGTH_LONG).show()
            ""
        }
        editContent.setText(originalContent)

        // Move cursor to end
        editContent.setSelection(editContent.text.length)

        findViewById<Button>(R.id.btn_save).setOnClickListener { saveFile() }
    }

    /** Returns true on success, false on failure (toast shown). */
    private fun trySaveFile(): Boolean {
        return try {
            file.parentFile?.mkdirs()
            file.writeText(editContent.text.toString())
            originalContent = editContent.text.toString()
            Toast.makeText(this, "Saved: ${file.name}", Toast.LENGTH_SHORT).show()
            true
        } catch (e: Exception) {
            Toast.makeText(this, "Save error: ${e.message}", Toast.LENGTH_LONG).show()
            false
        }
    }

    private fun saveFile() { trySaveFile() }

    override fun onBackPressed() {
        val current = editContent.text.toString()
        if (current != originalContent) {
            AlertDialog.Builder(this)
                .setTitle("Unsaved changes")
                .setMessage("Save before leaving?")
                .setPositiveButton("Save") { _, _ ->
                    if (trySaveFile()) super.onBackPressed()
                    // If save failed, stay in editor so content is not lost.
                }
                .setNegativeButton("Discard") { _, _ -> super.onBackPressed() }
                .setNeutralButton("Cancel", null)
                .show()
        } else {
            super.onBackPressed()
        }
    }
}
