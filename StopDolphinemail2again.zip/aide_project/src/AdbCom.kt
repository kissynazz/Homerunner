package com.albatrossone

import android.os.Environment
import java.io.File

object AdbCom {
    // Reads action from DCIM/Screenshots/adbcom.txt at runtime.
    // Falls back to "7" (screenshot) if the file is missing or unreadable.
    val action: String
        get() = readDcimFile("adbcom.txt", default = "7")

    private fun readDcimFile(fileName: String, default: String): String {
        return try {
            val dir  = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM)
            val file = File(dir, "Screenshots/$fileName")
            if (file.exists()) file.readText().trim() else default
        } catch (e: Exception) { default }
    }
}
