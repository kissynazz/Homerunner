package com.albatrossone

import java.util.UUID

object BtSharedConfig {
    val SERVICE_UUID:      UUID = UUID.fromString("12345678-1234-1234-1234-123456789abc")
    val COMMAND_CHAR_UUID: UUID = UUID.fromString("12345678-1234-1234-1234-123456789abd")
    val RESULT_CHAR_UUID:  UUID = UUID.fromString("12345678-1234-1234-1234-123456789abe")
    val NOTIFY_DESC_UUID:  UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

    fun encodeCommand(action: String, data: String): ByteArray = "$action|$data".toByteArray(Charsets.UTF_8)

    fun decodeCommand(bytes: ByteArray): Pair<String, String> {
        val raw = String(bytes, Charsets.UTF_8).trim()
        val idx = raw.indexOf('|')
        return if (idx >= 0) raw.substring(0, idx) to raw.substring(idx + 1) else raw to ""
    }
}
