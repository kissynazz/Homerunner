package com.albatrossone

import android.os.Environment
import java.io.File

object AdbComSafeWatcher {

    private val safeFile: File
        get() = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), "Screenshots/adbcomsafe.txt")

    private val lock = Any()
    @Volatile private var thread: Thread? = null
    @Volatile private var lastLineCount = 0
    private var pollCount = 0

    fun start(onNewLine: () -> Unit, onChanged: () -> Unit) {
        synchronized(lock) {
            if (thread?.isAlive == true) return
            lastLineCount = readLineCount(safeFile)
            val t = Thread {
                pollCount = 0
                while (!Thread.currentThread().isInterrupted) {
                    try {
                        pollCount++
                        if (pollCount % 10 == 0) android.util.Log.i("AdbComSafeWatcher", "ALIVE — poll #$pollCount lines=${readLineCount(safeFile)}")
                        val count = readLineCount(safeFile)
                        if (count != lastLineCount) {
                            onChanged()
                            if (count > lastLineCount) onNewLine()
                            lastLineCount = count
                        }
                        Thread.sleep(500)
                    } catch (_: InterruptedException) { break
                    } catch (e: Exception) { android.util.Log.e("AdbComSafeWatcher", "Poll error: ${e.message}"); try { Thread.sleep(1000) } catch (_: InterruptedException) { break } }
                }
            }
            t.name = "AdbComSafeWatcher"; t.isDaemon = true; t.start(); thread = t
        }
    }

    fun stop() { synchronized(lock) { thread?.interrupt(); thread = null } }
    fun currentLineCount(): Int = readLineCount(safeFile)
    private fun readLineCount(file: File): Int = try { if (file.exists()) file.readLines().count { it.isNotBlank() } else 0 } catch (_: Exception) { 0 }
}
