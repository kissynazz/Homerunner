package com.albatrossone

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val statusText = findViewById<TextView>(R.id.status_text)
        val enableBtn  = findViewById<Button>(R.id.btn_enable)
        val testBtn    = findViewById<Button>(R.id.btn_test)

        // Check if accessibility service is enabled
        updateStatus(statusText)

        // Open Accessibility Settings so user can enable the service
        enableBtn.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        // Run a one-shot clipboard test and show the result
        testBtn.setOnClickListener {
            statusText.text = "Reading clipboard…"
            Thread {
                val ctx = applicationContext
                val cm  = ctx.getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                val raw = cm.primaryClip?.getItemAt(0)?.coerceToText(ctx)?.toString()?.trim()

                val result = if (raw.isNullOrEmpty()) {
                    "Clipboard is empty.\nCopy a command like '7 1' or '3 2' from any app."
                } else {
                    val tokens = raw.split("\\s+".toRegex()).filter { it.isNotEmpty() }
                    val seq    = tokens.lastOrNull()?.toIntOrNull()
                    if (tokens.size < 2 || seq == null) {
                        "Clipboard: '$raw'\nNot a command — need action + seq number.\nExample: '7 1'"
                    } else {
                        val withoutSeq = tokens.dropLast(1)
                        val cmdTokens  = if (withoutSeq.firstOrNull()?.endsWith(".txt") == true)
                            withoutSeq.drop(1) else withoutSeq
                        val action = cmdTokens[0]
                        val data   = cmdTokens.drop(1).joinToString(",")
                        "Clipboard parsed OK!\naction='$action'  data='${data.ifEmpty{"<none>"}}'  seq=$seq\n\nFiring action…\n" +
                        HomeScriptRunner.executeAction(action, data)
                    }
                }

                runOnUiThread { statusText.text = result }
            }.start()
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatus(findViewById(R.id.status_text))
    }

    private fun updateStatus(tv: TextView) {
        val enabled = isServiceEnabled()
        tv.text = if (enabled) {
            "✓ Service is ACTIVE\n\nCopy clipboard commands from any app:\n\n" +
            "  '7 1'  → screenshot\n" +
            "  '3 2'  → home\n" +
            "  'tap 540 1000 3'  → tap\n\n" +
            "The last number must increase each time.\n" +
            "You can now close this app — the service runs in the background."
        } else {
            "⚠ Service is NOT enabled\n\n" +
            "Tap 'Open Accessibility Settings' below,\n" +
            "find 'AlbatrossOne' under Installed Apps,\n" +
            "and turn it ON.\n\n" +
            "Then come back here — the status will update."
        }
    }

    private fun isServiceEnabled(): Boolean {
        val name = "${packageName}/.MyAutomationService"
        val enabled = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.split(":").any { it.equals(name, ignoreCase = true) }
    }
}
