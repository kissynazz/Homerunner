package com.albatrossone

import android.content.ClipboardManager
import android.content.Context
import android.os.Handler
import android.os.Looper

object ClipboardWatcher {

    private const val TAG = "ClipboardWatcher"

    @Volatile private var lastSeq   = -1
    @Volatile private var running   = false
    private var pollThread: Thread? = null
    private var clipManager: ClipboardManager? = null
    private var listener: ClipboardManager.OnPrimaryClipChangedListener? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    fun start(context: Context, onCommand: (action: String, data: String) -> Unit) {
        stop()
        running = true
        val ctx = context.applicationContext
        val cm  = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipManager = cm

        android.util.Log.i(TAG, "=== ClipboardWatcher STARTING (lastSeq reset to -1) ===")

        val l = ClipboardManager.OnPrimaryClipChangedListener {
            android.util.Log.d(TAG, "Listener fired on main looper")
            checkClipboard(ctx, cm, onCommand)
        }
        listener = l
        mainHandler.post { cm.addPrimaryClipChangedListener(l) }

        pollThread = Thread {
            android.util.Log.i(TAG, "Poll thread started")
            var poll = 0
            while (running) {
                poll++
                if (poll % 20 == 0) android.util.Log.d(TAG, "Heartbeat poll #$poll lastSeq=$lastSeq")
                checkClipboard(ctx, cm, onCommand)
                try { Thread.sleep(500) } catch (_: InterruptedException) { break }
            }
            android.util.Log.i(TAG, "Poll thread stopped")
        }.apply { name = "ClipboardPoll"; isDaemon = true; start() }
    }

    fun stop() {
        running = false
        pollThread?.interrupt()
        pollThread = null
        listener?.let { l -> mainHandler.post { clipManager?.removePrimaryClipChangedListener(l) } }
        listener    = null
        clipManager = null
        lastSeq     = -1
    }

    private fun checkClipboard(context: Context, cm: ClipboardManager, onCommand: (String, String) -> Unit) {
        try {
            val clip = cm.primaryClip
            if (clip == null) {
                android.util.Log.v(TAG, "getPrimaryClip() null (Android 10+ background restriction?)")
                return
            }
            val raw = clip.getItemAt(0)?.coerceToText(context)?.toString()?.trim()
            if (raw.isNullOrEmpty()) return

            val tokens = raw.split("\\s+".toRegex()).filter { it.isNotEmpty() }
            if (tokens.size < 2) return

            val seq = tokens.last().toIntOrNull() ?: return
            if (seq <= lastSeq) return
            lastSeq = seq
            android.util.Log.i(TAG, "New command seq=$seq raw='$raw'")

            val withoutSeq = tokens.dropLast(1)
            val cmdTokens  = if (withoutSeq.firstOrNull()?.endsWith(".txt") == true) withoutSeq.drop(1) else withoutSeq
            if (cmdTokens.isEmpty()) return

            val action = cmdTokens[0]
            val data   = cmdTokens.drop(1).joinToString(",")
            android.util.Log.i(TAG, "Dispatching action='$action' data='$data'")
            onCommand(action, data)
        } catch (e: Exception) {
            android.util.Log.e(TAG, "checkClipboard error: ${e.message}")
        }
    }
}
