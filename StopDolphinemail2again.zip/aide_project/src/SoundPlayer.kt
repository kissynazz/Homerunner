package com.albatrossone

import android.media.AudioManager
import android.media.ToneGenerator

object SoundPlayer {

    fun playCommandFired() {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 90)
            tg.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 150)
            Thread.sleep(200)
            tg.startTone(ToneGenerator.TONE_PROP_ACK, 150)
            Thread.sleep(300)
            tg.release()
        } catch (e: Exception) {
            android.util.Log.e("SoundPlayer", "playCommandFired error: ${e.message}")
        }
    }

    fun playFileChanged() {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 70)
            tg.startTone(ToneGenerator.TONE_PROP_BEEP, 200)
            Thread.sleep(350)
            tg.release()
        } catch (e: Exception) {
            android.util.Log.e("SoundPlayer", "playFileChanged error: ${e.message}")
        }
    }
}
