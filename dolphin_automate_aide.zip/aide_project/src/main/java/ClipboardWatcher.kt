package com.home.automation

import android.content.ClipboardManager
import android.content.Context
import android.os.Handler
import android.os.Looper

object ClipboardWatcher {

    private const val TAG = "ClipboardWatcher"

    // seqLock guards the lastSeq compare-and-update so concurrent calls from
    // the poll thread, the listener, and the retry posts cannot fire the same
    // command more than once.
    private val seqLock = Any()

    @Volatile private var lastSeq   = -1
    @Volatile private var running   = false
    private var pollThread: Thread? = null
    private var clipManager: ClipboardManager? = null
    private var listener: ClipboardManager.OnPrimaryClipChangedListener? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    fun start(context: Context, onCommand: (action: String, data: String) -> Unit) {
        stop()
        running = true
        val ctx = context.applicationContext
        val cm  = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipManager = cm

        android.util.Log.i(TAG, "=== ClipboardWatcher STARTING (lastSeq reset to -1) ===")

        val l = ClipboardManager.OnPrimaryClipChangedListener {
            android.util.Log.d(TAG, "Listener fired on main looper")
            // Android 10+ may return null for getPrimaryClip() when the app is
            // in background.  Schedule a few rapid retries so the command fires
            // as soon as the system lets us read the clipboard.
            checkClipboard(ctx, cm, onCommand)
            val delays = longArrayOf(150, 400, 800, 1500, 2500)
            for (delay in delays) {
                mainHandler.postDelayed({
                    if (running) checkClipboard(ctx, cm, onCommand)
                }, delay)
            }
        }
        listener = l
        mainHandler.post { cm.addPrimaryClipChangedListener(l) }

        pollThread = Thread {
            android.util.Log.i(TAG, "Poll thread started")
            var poll = 0
            while (running) {
                poll++
                if (poll % 20 == 0) android.util.Log.d(TAG, "Heartbeat poll #$poll lastSeq=$lastSeq")
                checkClipboard(ctx, cm, onCommand)
                try { Thread.sleep(500) } catch (_: InterruptedException) { break }
            }
            android.util.Log.i(TAG, "Poll thread stopped")
        }.apply { name = "ClipboardPoll"; isDaemon = true; start() }
    }

    fun stop() {
        running = false
        pollThread?.interrupt()
        pollThread = null

        // Capture locals before nulling fields so the posted removal still
        // has valid references even after this method returns.
        val l  = listener
        val cm = clipManager
        if (l != null && cm != null) {
            mainHandler.post { cm.removePrimaryClipChangedListener(l) }
        }
        listener    = null
        clipManager = null
        // Do NOT reset lastSeq here — same reason as AdbComWatcher: the dying
        // poll thread can fire one last checkClipboard() after the reset and
        // replay an old command (e.g. "3 X" → home) when the app re-opens and
        // clipboard access is restored. Keeping lastSeq intact prevents replay.
    }

    private fun checkClipboard(context: Context, cm: ClipboardManager, onCommand: (String, String) -> Unit) {
        try {
            val clip = cm.primaryClip
            if (clip == null) {
                android.util.Log.v(TAG, "getPrimaryClip() null (Android 10+ background restriction?)")
                return
            }
            val raw = clip.getItemAt(0)?.coerceToText(context)?.toString()?.trim()
            if (raw.isNullOrEmpty()) return

            val tokens = raw.split("\\s+".toRegex()).filter { it.isNotEmpty() }
            if (tokens.size < 2) return

            val seq = tokens.last().toIntOrNull() ?: return

            // Atomic compare-and-update: only one concurrent caller wins per seq.
            val shouldDispatch = synchronized(seqLock) {
                if (seq <= lastSeq) false else { lastSeq = seq; true }
            }
            if (!shouldDispatch) return

            android.util.Log.i(TAG, "New command seq=$seq raw='$raw'")

            val withoutSeq = tokens.dropLast(1)
            val cmdTokens  = if (withoutSeq.firstOrNull()?.endsWith(".txt") == true) withoutSeq.drop(1) else withoutSeq
            if (cmdTokens.isEmpty()) return

            val action = cmdTokens[0]
            val data   = cmdTokens.drop(1).joinToString(",")
            android.util.Log.i(TAG, "Dispatching action='$action' data='$data'")
            onCommand(action, data)
        } catch (e: Exception) {
            android.util.Log.e(TAG, "checkClipboard error: ${e.message}")
        }
    }
}
