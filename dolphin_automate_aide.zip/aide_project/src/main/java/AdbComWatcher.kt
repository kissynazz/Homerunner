package com.home.automation

import android.os.Environment
import java.io.File

/**
 * Polls DCIM/Screenshots/adbcom.txt every 500 ms for new lines.
 * Each new line is parsed as a command in the same format as clipboard commands:
 *   "7 1"              → screenshot (seq=1)
 *   "3 2"              → home (seq=2)
 *   "tap 540 1000 3"   → tap at (540,1000) (seq=3)
 * The seq number must increase to fire — duplicate/old lines are ignored.
 * This runs entirely in background via a daemon thread, unaffected by
 * Android 10+ clipboard restrictions.
 */
object AdbComWatcher {

    private val file: File
        get() = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
            "Screenshots/adbcom.txt"
        )

    private val lock = Any()
    private val seqLock = Any()
    @Volatile private var thread: Thread? = null
    @Volatile private var lastSeq = -1

    fun start(onCommand: (action: String, data: String) -> Unit) {
        synchronized(lock) {
            if (thread?.isAlive == true) return
            // Seed lastSeq from whatever is already in the file so we don't
            // replay old commands on startup.
            lastSeq = currentSeq()
            android.util.Log.i("AdbComWatcher", "=== STARTING — seeded lastSeq=$lastSeq ===")
            val t = Thread {
                var poll = 0
                while (!Thread.currentThread().isInterrupted) {
                    try {
                        poll++
                        if (poll % 20 == 0) android.util.Log.d("AdbComWatcher", "Heartbeat poll #$poll lastSeq=$lastSeq")
                        checkFile(onCommand)
                        Thread.sleep(500)
                    } catch (_: InterruptedException) {
                        break
                    } catch (e: Exception) {
                        android.util.Log.e("AdbComWatcher", "Poll error: ${e.message}")
                        try { Thread.sleep(1000) } catch (_: InterruptedException) { break }
                    }
                }
                android.util.Log.i("AdbComWatcher", "Stopped")
            }
            t.name = "AdbComWatcher"; t.isDaemon = true; t.start(); thread = t
        }
    }

    fun stop() {
        synchronized(lock) {
            thread?.interrupt()
            thread = null
            // Do NOT reset lastSeq here — if we reset to -1 the dying thread
            // can fire one last checkFile() and replay an old command, bumping
            // lastSeq back up so the next real command looks like a duplicate.
            // Keeping lastSeq intact means start() seeds correctly on restart.
        }
    }

    private fun checkFile(onCommand: (String, String) -> Unit) {
        val f = file
        if (!f.exists()) return
        val lines = try { f.readLines().filter { it.isNotBlank() } } catch (_: Exception) { return }
        // Walk all lines so we catch every new command even if multiple arrive
        // between polls.
        for (raw in lines) {
            val tokens = raw.trim().split("\\s+".toRegex()).filter { it.isNotEmpty() }
            if (tokens.size < 2) continue
            val seq = tokens.last().toIntOrNull() ?: continue
            val shouldDispatch = synchronized(seqLock) {
                if (seq <= lastSeq) false else { lastSeq = seq; true }
            }
            if (!shouldDispatch) continue
            android.util.Log.i("AdbComWatcher", "New command seq=$seq raw='$raw'")
            val withoutSeq = tokens.dropLast(1)
            val cmdTokens  = if (withoutSeq.firstOrNull()?.endsWith(".txt") == true) withoutSeq.drop(1) else withoutSeq
            if (cmdTokens.isEmpty()) continue
            val action = cmdTokens[0]
            val data   = cmdTokens.drop(1).joinToString(",")
            android.util.Log.i("AdbComWatcher", "Dispatching action='$action' data='$data'")
            onCommand(action, data)
        }
    }

    private fun currentSeq(): Int {
        val f = file
        if (!f.exists()) return -1
        return try {
            f.readLines()
                .filter { it.isNotBlank() }
                .mapNotNull { line ->
                    line.trim().split("\\s+".toRegex()).lastOrNull()?.toIntOrNull()
                }
                .maxOrNull() ?: -1
        } catch (_: Exception) { -1 }
    }
}
