package com.home.automation

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class FileBrowserActivity : Activity() {

    companion object {
        const val EXTRA_START_PATH = "start_path"
        private const val REQUEST_ALL_FILES = 2001
    }

    private lateinit var tvPath: TextView
    private lateinit var listFiles: ListView
    private lateinit var currentDir: File
    private var entries: List<File> = emptyList()
    private var pendingStartPath: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_file_browser)

        tvPath    = findViewById(R.id.tv_path)
        listFiles = findViewById(R.id.list_files)

        val startPath = intent.getStringExtra(EXTRA_START_PATH)
            ?: Environment.getExternalStorageDirectory().absolutePath

        // On Android 11+ we need MANAGE_EXTERNAL_STORAGE for broad file access.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager()) {
            pendingStartPath = startPath
            AlertDialog.Builder(this)
                .setTitle("All-files access required")
                .setMessage(
                    "The file manager needs 'All files access' to browse and edit project files.\n\n" +
                    "Tap OK to open Settings, enable it for this app, then come back."
                )
                .setPositiveButton("Open Settings") { _, _ ->
                    val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                    intent.data = Uri.parse("package:$packageName")
                    startActivityForResult(intent, REQUEST_ALL_FILES)
                }
                .setNegativeButton("Cancel") { _, _ -> finish() }
                .setCancelable(false)
                .show()
            return
        }

        currentDir = File(startPath).let { if (it.exists() && it.canRead()) it else Environment.getExternalStorageDirectory() }
        setupListeners()
        loadDir(currentDir)
    }

    private fun setupListeners() {
        listFiles.setOnItemClickListener { _, _, pos, _ ->
            val file = entries[pos]
            if (file.isDirectory) loadDir(file) else openEditor(file)
        }
        findViewById<Button>(R.id.btn_up).setOnClickListener {
            val parent = currentDir.parentFile
            if (parent != null && parent.canRead()) loadDir(parent)
            else Toast.makeText(this, "Already at root", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btn_new_file).setOnClickListener { showNewFileDialog() }
        findViewById<Button>(R.id.btn_zip).setOnClickListener { zipCurrentDir() }
    }

    private fun loadDir(dir: File) {
        currentDir = dir
        tvPath.text = dir.absolutePath

        val raw = dir.listFiles()?.toList() ?: emptyList()
        entries = raw.sortedWith(compareBy({ !it.isDirectory }, { it.name.toLowerCase(java.util.Locale.ROOT) }))

        val labels = entries.map { f ->
            if (f.isDirectory) "📁  ${f.name}/" else "📄  ${f.name}"
        }
        listFiles.adapter = ArrayAdapter(this, R.layout.list_item_file, labels).also {
            it.setNotifyOnChange(true)
        }
    }

    private fun openEditor(file: File) {
        val intent = Intent(this, FileEditorActivity::class.java)
        intent.putExtra(FileEditorActivity.EXTRA_FILE_PATH, file.absolutePath)
        startActivity(intent)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_ALL_FILES) {
            val startPath = pendingStartPath ?: Environment.getExternalStorageDirectory().absolutePath
            pendingStartPath = null
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && Environment.isExternalStorageManager()) {
                currentDir = File(startPath).let { if (it.exists() && it.canRead()) it else Environment.getExternalStorageDirectory() }
                setupListeners()
                loadDir(currentDir)
            } else {
                Toast.makeText(this, "All-files access not granted — file manager may not work.", Toast.LENGTH_LONG).show()
                currentDir = Environment.getExternalStorageDirectory()
                setupListeners()
                loadDir(currentDir)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Only refresh if currentDir has been initialized (permission gate may delay init).
        if (::currentDir.isInitialized) loadDir(currentDir)
    }

    private fun showNewFileDialog() {
        val input = android.widget.EditText(this)
        input.hint = "filename.kt"
        input.setPadding(32, 16, 32, 16)
        AlertDialog.Builder(this)
            .setTitle("New file in\n${currentDir.name}/")
            .setView(input)
            .setPositiveButton("Create") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isEmpty()) {
                    Toast.makeText(this, "Name cannot be empty", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val newFile = File(currentDir, name)
                try {
                    if (newFile.createNewFile()) {
                        openEditor(newFile)
                    } else {
                        Toast.makeText(this, "File already exists", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun zipCurrentDir() {
        Thread {
            try {
                val screenshotsDir = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
                    "Screenshots"
                ).also { it.mkdirs() }

                val timestamp = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US)
                    .format(java.util.Date())
                val zipName = "${currentDir.name}_$timestamp.zip"
                val zipFile = File(screenshotsDir, zipName)

                ZipOutputStream(FileOutputStream(zipFile)).use { zos ->
                    addDirToZip(zos, currentDir, currentDir.name)
                }

                runOnUiThread {
                    Toast.makeText(
                        this,
                        "Zipped → DCIM/Screenshots/$zipName",
                        Toast.LENGTH_LONG
                    ).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "Zip error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun addDirToZip(zos: ZipOutputStream, dir: File, baseName: String) {
        val files = dir.listFiles()
        if (files == null || files.isEmpty()) {
            // Preserve empty directories as an explicit entry with trailing slash.
            zos.putNextEntry(ZipEntry("$baseName/"))
            zos.closeEntry()
            return
        }
        for (file in files) {
            val entryName = "$baseName/${file.name}"
            if (file.isDirectory) {
                addDirToZip(zos, file, entryName)
            } else {
                zos.putNextEntry(ZipEntry(entryName))
                file.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
    }
}
