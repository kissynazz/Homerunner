package com.home.automation;

import android.content.Context;
import android.os.Environment;
import android.util.Log;

import com.sun.mail.imap.IMAPFolder;

import javax.mail.BodyPart;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.UIDFolder;
import javax.mail.internet.MimeMultipart;
import javax.mail.search.FromStringTerm;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * EmailWatcher — Android background thread.
 *
 * Started from MyAutomationService.onServiceConnected().
 * Polls Gmail (IMAP) every 6 seconds for new emails sent from the configured
 * address to itself. When a NEW email arrives (tracked by IMAP UID), it:
 *   1. Extracts the payload between '$' and '@' in the body  (mha)
 *   2. Trims mha at the first '#'                           (mh2)
 *   3. Parses the ugly=[...] command string
 *   4. Writes the appropriate line to DCIM/Screenshots/adbcom.txt
 *      with an incrementing seq number that AdbComWatcher picks up.
 *
 * Key fix vs. Python original:
 *   Python had `uglystop==0` (a comparison, not assignment) inside the
 *   parsing loop, so it always re-processed the last email's command.
 *   Here, lastProcessedUid tracks what we already handled — we only
 *   act when the newest email's UID changes (genuinely new email).
 *
 * Compatible with compileSdkVersion 30 / minSdkVersion 21.
 * No Java 8 lambdas — uses plain Runnable / anonymous classes throughout.
 * Requires: aide_project/libs/android-mail-1.6.5.jar
 *            aide_project/libs/android-activation-1.6.5.jar
 */
public class EmailWatcher {

    private static final String TAG = "EmailWatcher";

    // ── Gmail credentials ─────────────────────────────────────────────────────
    private static final String USER      = "nazzyburpee0@gmail.com";
    private static final String PASSWORD  = "qntc kxxr wybp bdng";
    private static final String IMAP_HOST = "imap.gmail.com";

    private static final long POLL_MS = 6000L;

    // ── Runtime state ─────────────────────────────────────────────────────────
    private static volatile long    lastProcessedUid = -1L;
    private static volatile int     seq              = 0;
    private static volatile boolean running          = false;
    private static          Thread  watcherThread    = null;

    // ── Android file paths (resolved in start()) ──────────────────────────────
    private static String adbcomPath  = null;
    private static String lastseqPath = null;

    // ═════════════════════════════════════════════════════════════════════════
    //  Lifecycle
    // ═════════════════════════════════════════════════════════════════════════

    public static synchronized void start(Context context) {
        if (running) {
            Log.i(TAG, "Already running — ignoring duplicate start()");
            return;
        }

        // Resolve DCIM/Screenshots path — same folder AdbComWatcher watches
        File screenshots = new File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
                "Screenshots");
        screenshots.mkdirs();
        adbcomPath  = new File(screenshots, "adbcom.txt").getAbsolutePath();
        lastseqPath = new File(screenshots, "lastseq.txt").getAbsolutePath();

        seq = readSeq();
        Log.i(TAG, "=== STARTING — seq=" + seq + "  adbcom=" + adbcomPath + " ===");

        running = true;

        // No lambdas — plain Runnable for SDK 30 / Java 7 compatibility
        watcherThread = new Thread(new Runnable() {
            public void run() {
                while (running && !Thread.currentThread().isInterrupted()) {
                    try {
                        poll();
                    } catch (Exception e) {
                        Log.e(TAG, "poll error: " + e.getMessage());
                    }
                    try {
                        Thread.sleep(POLL_MS);
                    } catch (InterruptedException ex) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
                Log.i(TAG, "Stopped.");
            }
        }, "EmailWatcher");
        watcherThread.setDaemon(true);
        watcherThread.start();
    }

    public static synchronized void stop() {
        running = false;
        if (watcherThread != null) {
            watcherThread.interrupt();
            watcherThread = null;
        }
        Log.i(TAG, "stop() called.");
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  Core poll
    // ═════════════════════════════════════════════════════════════════════════

    private static void poll() throws Exception {
        Properties props = new Properties();
        props.put("mail.imaps.host", IMAP_HOST);
        props.put("mail.imaps.port", "993");
        props.put("mail.imaps.ssl.enable", "true");
        props.put("mail.imaps.connectiontimeout", "12000");
        props.put("mail.imaps.timeout", "12000");

        Session session = Session.getInstance(props);
        Store  store = null;
        Folder inbox = null;

        try {
            store = session.getStore("imaps");
            store.connect(IMAP_HOST, USER, PASSWORD);

            inbox = store.getFolder("INBOX");
            inbox.open(Folder.READ_ONLY);

            // Search for emails from our own address (mirrors Python FROM search)
            Message[] msgs = inbox.search(new FromStringTerm(USER));
            if (msgs == null || msgs.length == 0) {
                Log.d(TAG, "No messages from self found.");
                return;
            }

            // Newest message is last
            Message latest = msgs[msgs.length - 1];

            // ── New-email gate (the core fix) ────────────────────────────────
            // Only process when the IMAP UID changes — genuinely new email.
            // This replaces the broken `uglystop==0` comparison in the Python.
            long uid = ((UIDFolder) inbox).getUID(latest);
            if (uid == lastProcessedUid) {
                Log.d(TAG, "No new email (UID " + uid + " already processed).");
                return;
            }

            Log.i(TAG, "New email! UID=" + uid + " (previous=" + lastProcessedUid + ")");
            lastProcessedUid = uid;   // mark before processing so crash doesn't replay

            String rawBody = extractBody(latest);

            // Mirror Python: collect mha between first '$' and '@' or '/'
            String mha = extractMha(rawBody);
            Log.i(TAG, "mha=[" + mha + "]");
            if (mha.isEmpty()) {
                Log.w(TAG, "No '$...' payload found in email body.");
                return;
            }

            // Mirror Python: mh2 = mha up to first '#'
            String mh2 = extractMh2(mha);
            Log.i(TAG, "mh2=[" + mh2 + "]");

            processUgly(mh2);
            writeSeq(seq);

        } finally {
            try { if (inbox != null) inbox.close(false); } catch (Exception ignored) {}
            try { if (store != null) store.close();      } catch (Exception ignored) {}
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  Email body extraction
    // ═════════════════════════════════════════════════════════════════════════

    private static String extractBody(Part part) throws Exception {
        Object content = part.getContent();
        if (content instanceof String) {
            return (String) content;
        }
        if (content instanceof MimeMultipart) {
            MimeMultipart mp = (MimeMultipart) content;
            String htmlFallback = null;
            for (int i = 0; i < mp.getCount(); i++) {
                BodyPart bp = mp.getBodyPart(i);
                String ct = bp.getContentType().toLowerCase();
                if (ct.startsWith("text/plain")) return extractBody(bp);
                if (ct.startsWith("text/html"))  htmlFallback = extractBody(bp);
            }
            if (htmlFallback != null) return htmlFallback;
        }
        if (content instanceof InputStream) {
            // No readAllBytes() — manual loop for SDK 30 / Java 7 compat
            InputStream is = (InputStream) content;
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = is.read(buf)) != -1) baos.write(buf, 0, n);
            return baos.toString("UTF-8");
        }
        return content.toString();
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  mha extraction — mirrors Python startadd loop exactly
    // ═════════════════════════════════════════════════════════════════════════

    /**
     * Python:
     *   indexstart = data.find("ltr")
     *   data2 = data[indexstart + 5:]      # skip past ltr">
     *   indexend = data2.find("</div>")
     *   data2 = data2[0:indexend]
     *   startadd = 0; mha = ''
     *   for mh in data2:
     *       if mh == '$': startadd=1; continue
     *       if startadd==1:
     *           if mh=='@' or mh=='/': break
     *           if mh != ' ': mha += mh
     *
     * Gmail wraps self-sent plain-text emails in <div dir="ltr">...</div>,
     * so "ltr" is reliably present when fetched via IMAP.
     * Falls through to searching the raw body if not found.
     */
    private static String extractMha(String data) {
        String data2;
        int ltrIdx = data.indexOf("ltr");
        if (ltrIdx >= 0) {
            int start = Math.min(ltrIdx + 5, data.length());
            data2 = data.substring(start);
            int divEnd = data2.indexOf("</div>");
            if (divEnd >= 0) data2 = data2.substring(0, divEnd);
        } else {
            data2 = data;  // plain-text fallback
        }

        int startAdd = 0;
        StringBuffer mha = new StringBuffer();  // StringBuffer not StringBuilder for Java 7 compat
        for (int i = 0; i < data2.length(); i++) {
            char c = data2.charAt(i);
            if (c == '$') {
                startAdd = 1;
                continue;
            }
            if (startAdd == 1) {
                if (c == '@' || c == '/') break;
                if (c != ' ')            mha.append(c);
            }
        }
        return mha.toString();
    }

    // ── mh2: mha up to the first '#' ─────────────────────────────────────────

    private static String extractMh2(String mha) {
        int hashIdx = mha.indexOf('#');
        return (hashIdx >= 0) ? mha.substring(0, hashIdx) : mha;
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  Command dispatcher — replaces Python's exec(mh2) + if ugly[0]==... chain
    // ═════════════════════════════════════════════════════════════════════════

    private static void processUgly(String mh2) throws Exception {
        String cmd = parseUglyCommand(mh2);
        Log.i(TAG, "ugly command='" + cmd + "'");

        if (cmd == null) {
            Log.w(TAG, "Could not identify command in: [" + mh2 + "]");
            return;
        }

        // Plain if/else instead of switch(String) — Java 7 safe
        if ("home".equals(cmd)) {
            Thread.sleep(2000);
            seq++;
            writeAdbcom("3 " + seq);

        } else if ("screen".equals(cmd)) {
            Thread.sleep(2000);
            seq++;
            writeAdbcom("7 " + seq);

        } else if ("didstart".equals(cmd)) {
            seq++;
            writeAdbcom("3" + seq);        // mirrors Python (no space, matches original)
            Thread.sleep(2000);
            seq++;
            writeAdbcom("tap 100 500 " + seq);

        } else if ("click".equals(cmd)) {
            int[] xy = parseClickCoords(mh2);
            if (xy != null) {
                Thread.sleep(2000);
                seq++;
                writeAdbcom("tap " + xy[0] + " " + xy[1] + " " + seq);
            } else {
                Log.w(TAG, "click: could not parse coords from: " + mh2);
            }

        } else if ("sol".equals(cmd) || "checkscreen".equals(cmd)
                || "verse".equals(cmd) || "multi".equals(cmd)) {
            Log.i(TAG, "'" + cmd + "' — no adbcom action defined.");

        } else {
            Log.w(TAG, "Unhandled command: " + cmd);
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  Parsing helpers
    // ═════════════════════════════════════════════════════════════════════════

    /** Finds the command name in a string like ugly=['home'] */
    private static String parseUglyCommand(String mh2) {
        String[] known = { "home", "screen", "click", "didstart",
                           "sol", "verse", "checkscreen", "multi" };
        String lower = mh2.toLowerCase();
        for (int i = 0; i < known.length; i++) {
            if (lower.contains("'" + known[i] + "'")
                    || lower.contains("\"" + known[i] + "\"")) {
                return known[i];
            }
        }
        return null;
    }

    /** Extracts [x, y] from ugly=['click',[540,1000]] */
    private static int[] parseClickCoords(String mh2) {
        int clickPos = mh2.toLowerCase().indexOf("click");
        if (clickPos < 0) return null;
        int open  = mh2.indexOf('[', clickPos);
        if (open  < 0) return null;
        int close = mh2.indexOf(']', open);
        if (close < 0) return null;
        String[] parts = mh2.substring(open + 1, close).trim().split(",");
        if (parts.length < 2) return null;
        try {
            return new int[]{
                Integer.parseInt(parts[0].trim()),
                Integer.parseInt(parts[1].trim())
            };
        } catch (NumberFormatException e) {
            return null;
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  File helpers — all paths point to DCIM/Screenshots/
    // ═════════════════════════════════════════════════════════════════════════

    private static void writeAdbcom(String line) throws IOException {
        FileWriter fw = null;
        try {
            fw = new FileWriter(adbcomPath);
            fw.write(line);
        } finally {
            if (fw != null) try { fw.close(); } catch (IOException ignored) {}
        }
        Log.i(TAG, "adbcom.txt <- \"" + line + "\"");
    }

    private static int readSeq() {
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(lastseqPath));
            return Integer.parseInt(br.readLine().trim());
        } catch (Exception e) {
            return 0;
        } finally {
            if (br != null) try { br.close(); } catch (IOException ignored) {}
        }
    }

    private static void writeSeq(int s) throws IOException {
        FileWriter fw = null;
        try {
            fw = new FileWriter(lastseqPath);
            fw.write(String.valueOf(s));
        } finally {
            if (fw != null) try { fw.close(); } catch (IOException ignored) {}
        }
    }
}
