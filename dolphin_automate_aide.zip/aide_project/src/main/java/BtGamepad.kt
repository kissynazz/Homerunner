package com.home.automation

import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.os.ParcelUuid
import java.util.UUID

object BtGamepad {

    private val SVC_HID        = uuid("1812");  private val CHR_HID_INFO   = uuid("2A4A")
    private val CHR_HID_CTRL   = uuid("2A4C");  private val CHR_REPORT_MAP = uuid("2A4B")
    private val CHR_REPORT     = uuid("2A4D");  private val CHR_PROTO_MODE = uuid("2A4E")
    private val DSC_REPORT_REF = uuid("2908");  private val DSC_CCCD       = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    private val SVC_BATT       = uuid("180F");  private val CHR_BATT_LEVEL = uuid("2A19")
    private val SVC_DEVINFO    = uuid("180A");  private val CHR_MANUF      = uuid("2A29");  private val CHR_MODEL = uuid("2A24")
    private val SVC_MOUSE      = UUID.fromString("A000B000-C000-D000-E000-F00000000001")
    private val CHR_MOUSE      = UUID.fromString("A000B000-C000-D000-E000-F00000000002")
    // Custom notify service — iPad (SharpBlue) writes here to send commands to phone
    private val SVC_NOTIFY     = UUID.fromString("A000B000-C000-D000-E000-F00000000003")
    private val CHR_NOTIFY_IN  = UUID.fromString("A000B000-C000-D000-E000-F00000000004")

    private val HID_DESCRIPTOR = byteArrayOf(
        // ── Gamepad (Report ID 1) ─────────────────────────────────────────────
        0x05,0x01,0x09,0x05,0xA1.toByte(),0x01,0x85.toByte(),0x01,
        0x09,0x30,0x09,0x31,0x09,0x32,0x09,0x35,0x15,0x00,0x26,0xFF.toByte(),0x00,0x75,0x08,0x95.toByte(),0x04,0x81.toByte(),0x02,
        0x09,0x33,0x09,0x34,0x15,0x00,0x26,0xFF.toByte(),0x00,0x75,0x08,0x95.toByte(),0x02,0x81.toByte(),0x02,
        0x09,0x39,0x15,0x00,0x25,0x07,0x35,0x00,0x46,0x3B,0x01,0x65,0x14,0x75,0x04,0x95.toByte(),0x01,0x81.toByte(),0x42,
        0x75,0x04,0x95.toByte(),0x01,0x81.toByte(),0x03,
        0x05,0x09,0x19,0x01,0x29,0x0E,0x15,0x00,0x25,0x01,0x75,0x01,0x95.toByte(),0x0E,0x81.toByte(),0x02,
        0x75,0x02,0x95.toByte(),0x01,0x81.toByte(),0x03,0xC0.toByte(),
        // ── Keyboard (Report ID 2) ────────────────────────────────────────────
        // Report: [modifier(1), reserved(1), keycode×6] = 8 bytes
        0x05,0x01,                          // Usage Page (Generic Desktop)
        0x09,0x06,                          // Usage (Keyboard)
        0xA1.toByte(),0x01,                 // Collection (Application)
        0x85.toByte(),0x02,                 // Report ID 2
        // Modifier keys (8 bits: LCtrl LShift LAlt LGUI RCtrl RShift RAlt RGUI)
        0x05,0x07,                          // Usage Page (Key Codes)
        0x19,0xE0.toByte(),                 // Usage Min (Left Ctrl)
        0x29,0xE7.toByte(),                 // Usage Max (Right GUI)
        0x15,0x00,                          // Logical Min (0)
        0x25,0x01,                          // Logical Max (1)
        0x75,0x01,                          // Report Size (1 bit)
        0x95.toByte(),0x08,                 // Report Count (8)
        0x81.toByte(),0x02,                 // Input (Data, Var, Abs)
        // Reserved byte
        0x75,0x08,                          // Report Size (8 bits)
        0x95.toByte(),0x01,                 // Report Count (1)
        0x81.toByte(),0x03,                 // Input (Const)
        // Keycodes (6 simultaneous keys)
        0x05,0x07,                          // Usage Page (Key Codes)
        0x19,0x00,                          // Usage Min (0)
        0x29,0x65,                          // Usage Max (101)
        0x15,0x00,                          // Logical Min (0)
        0x25,0x65,                          // Logical Max (101)
        0x75,0x08,                          // Report Size (8 bits)
        0x95.toByte(),0x06,                 // Report Count (6)
        0x81.toByte(),0x00,                 // Input (Data, Array, Abs)
        0xC0.toByte()                       // End Collection
    )

    private var gattServer: BluetoothGattServer? = null
    private var advertiseCallback: AdvertiseCallback? = null
    private var reportChar: BluetoothGattCharacteristic? = null
    private var mouseChar: BluetoothGattCharacteristic? = null
    private var keyboardReportChar: BluetoothGattCharacteristic? = null
    private val connectedDevices = mutableListOf<BluetoothDevice>()

    // BluetoothGattServer.addService() is asynchronous — calling it multiple times
    // in a row without waiting for onServiceAdded causes later services to fail
    // silently. Queue them and add one at a time.
    private val serviceQueue = java.util.LinkedList<BluetoothGattService>()
    private var pendingAdvertise: (() -> Unit)? = null

    /**
     * Called whenever the iPad (via SharpBlue) writes to the notify characteristic.
     * The value is decoded as UTF-8 — expected format is "action|data" (same as BtPeripheral),
     * though SharpBlue's Hello button sends plain "Hello, World!" as a connectivity test.
     * Set this in MyAutomationService.onServiceConnected() before BtGamepad.start().
     */
    var onCommandReceived: ((String) -> Unit)? = null

    fun start(context: Context, onStatus: ((String) -> Unit)? = null) {
        try {
            val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
            val adapter = manager.adapter ?: run {
                val msg = "ERROR: Bluetooth adapter not available"
                android.util.Log.e("BtGamepad", msg); onStatus?.invoke(msg); return
            }
            if (!adapter.isEnabled) {
                val msg = "ERROR: Bluetooth is off — enable it and try again"
                android.util.Log.e("BtGamepad", msg); onStatus?.invoke(msg); return
            }

            // Rename adapter — can throw SecurityException on some devices.
            try { adapter.name = BtSharedConfig.DEVICE_NAME }
            catch (e: Exception) { android.util.Log.w("BtGamepad", "Could not rename adapter: ${e.message}") }

            gattServer = manager.openGattServer(context, gattCallback)
            if (gattServer == null) {
                val msg = "ERROR: openGattServer returned null\n(BT permission missing or BT stack busy)"
                android.util.Log.e("BtGamepad", msg); onStatus?.invoke(msg); return
            }

            // Queue all services — they will be added one-at-a-time via onServiceAdded.
            // Advertising starts only after all services are registered so iOS sees them all.
            serviceQueue.clear()
            serviceQueue.addAll(listOf(
                buildHidService(), buildBatteryService(),
                buildDeviceInfoService(), buildMouseService(), buildNotifyService()
            ))

            // Store the advertise startup so it runs after the last service is added.
            val adapter2 = adapter
            pendingAdvertise = {
                val settings = AdvertiseSettings.Builder().setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY).setConnectable(true).setTimeout(0).build()
                val advData = AdvertiseData.Builder().addServiceUuid(ParcelUuid(SVC_HID)).setIncludeDeviceName(true).build()
                advertiseCallback = object : AdvertiseCallback() {
                    override fun onStartSuccess(s: AdvertiseSettings?) {
                        android.util.Log.i("BtGamepad", "Advertising as HID gamepad OK")
                        onStatus?.invoke("● Advertising as \"${BtSharedConfig.DEVICE_NAME}\" (HID)\n● GATT server: open\n● All services registered (HID, Battery, DevInfo, Mouse, Notify)\n\nReady — open SharpBlue on iPad and Quick Connect.")
                    }
                    override fun onStartFailure(e: Int) {
                        val reason = advertiseErrorReason(e)
                        android.util.Log.e("BtGamepad", "Advertising failed: $e $reason")
                        advertiseCallback = null
                        onStatus?.invoke("ERROR: Advertising failed\nCode $e — $reason\n\nTry: toggle BT off/on, then restart again.")
                    }
                }
                val advertiser = adapter2.bluetoothLeAdvertiser
                if (advertiser == null) {
                    val msg = "ERROR: LE advertising not supported on this device\n(phone hardware limitation)"
                    android.util.Log.e("BtGamepad", msg); advertiseCallback = null; onStatus?.invoke(msg)
                } else {
                    advertiser.startAdvertising(settings, advData, advertiseCallback!!)
                    onStatus?.invoke("Registering services… (${serviceQueue.size + 1} remaining)")
                }
            }

            // Kick off sequential service addition
            addNextService(onStatus)
        } catch (e: Exception) {
            android.util.Log.e("BtGamepad", "start() failed: ${e.message}")
            gattServer = null; advertiseCallback = null
            onStatus?.invoke("ERROR: start() threw ${e.javaClass.simpleName}\n${e.message}")
        }
    }

    private fun addNextService(onStatus: ((String) -> Unit)? = null) {
        val svc = serviceQueue.poll()
        if (svc == null) {
            // All services added — start advertising
            android.util.Log.i("BtGamepad", "All services registered — starting advertising")
            pendingAdvertise?.invoke(); pendingAdvertise = null
        } else {
            android.util.Log.i("BtGamepad", "Adding service: ${svc.uuid} (${serviceQueue.size} remaining)")
            gattServer?.addService(svc)
        }
    }

    private fun advertiseErrorReason(code: Int) = when (code) {
        1 -> "data too large"
        2 -> "too many advertisers (other apps using BLE)"
        3 -> "already started"
        4 -> "internal error (BT stack crash — toggle BT)"
        5 -> "feature unsupported"
        else -> "unknown"
    }

    fun stop(context: Context) {
        val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        advertiseCallback?.let { manager.adapter?.bluetoothLeAdvertiser?.stopAdvertising(it) }
        gattServer?.close(); gattServer = null; connectedDevices.clear()
    }

    fun status(): String {
        val sb = StringBuilder()
        sb.append("BT Gamepad (HID)\n")
        sb.append("─────────────────\n")
        if (gattServer == null && advertiseCallback == null) {
            sb.append("○ Not started\n")
        } else {
            if (advertiseCallback != null) sb.append("● Advertising as \"${BtSharedConfig.DEVICE_NAME}\" (HID)\n")
            else sb.append("○ Not advertising\n")
            if (gattServer != null) sb.append("● GATT server: open\n  Services: HID, Battery, Device Info, Mouse\n")
            val count = connectedDevices.size
            if (count == 0) {
                sb.append("  No hosts connected\n")
            } else {
                sb.append("  Connected hosts ($count):\n")
                connectedDevices.forEach { d ->
                    sb.append("  • ${d.name ?: "Unknown"}  ${d.address}\n")
                }
            }
        }
        sb.append("\nRole: phone acts as a BT HID controller.\nThe host sees it as a gamepad/mouse.")
        return sb.toString()
    }

    fun sendReport(report: ByteArray) {
        if (report.size != 9) return
        val char = reportChar ?: return
        char.value = report; connectedDevices.forEach { gattServer?.notifyCharacteristicChanged(it, char, false) }
    }

    fun sendMouseEvent(event: Int, x: Int, y: Int) {
        val char = mouseChar ?: return
        char.value = byteArrayOf(event.toByte(), 0x00, (x and 0xFF).toByte(), ((x shr 8) and 0xFF).toByte(), (y and 0xFF).toByte(), ((y shr 8) and 0xFF).toByte())
        connectedDevices.forEach { gattServer?.notifyCharacteristicChanged(it, char, false) }
    }

    /**
     * Send a keyboard HID report (Report ID 2) to all connected hosts.
     *
     * @param modifier  Bitmask of modifier keys:
     *                  0x01=LCtrl  0x02=LShift  0x04=LAlt  0x08=LGUI
     *                  0x10=RCtrl  0x20=RShift  0x40=RAlt  0x80=RGUI
     * @param keys      Up to 6 simultaneous HID keycodes (0 = no key).
     *                  Common codes: 4–29 = a–z, 30–39 = 1–9,0, 40=Enter,
     *                  41=Esc, 42=Backspace, 43=Tab, 44=Space,
     *                  79=Right, 80=Left, 81=Down, 82=Up
     *
     * Always follow a key-press call with a release call (modifier=0, keys=empty)
     * so the host does not see the key as held indefinitely.
     */
    fun sendKeyReport(modifier: Int, keys: IntArray) {
        val char = keyboardReportChar ?: return
        val report = ByteArray(8)
        report[0] = (modifier and 0xFF).toByte()
        report[1] = 0x00  // reserved
        for (i in 0 until minOf(keys.size, 6)) report[i + 2] = (keys[i] and 0xFF).toByte()
        char.value = report
        connectedDevices.forEach { gattServer?.notifyCharacteristicChanged(it, char, false) }
    }

    private val gattCallback = object : BluetoothGattServerCallback() {
        override fun onServiceAdded(status: Int, service: BluetoothGattService) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                android.util.Log.i("BtGamepad", "Service added OK: ${service.uuid}")
            } else {
                android.util.Log.e("BtGamepad", "Service add FAILED (status=$status): ${service.uuid}")
            }
            // Always continue the queue — skip failed services rather than hanging
            addNextService()
        }

        override fun onConnectionStateChange(device: BluetoothDevice, status: Int, newState: Int) {
            when (newState) {
                BluetoothProfile.STATE_CONNECTED    -> {
                    // Guard against the Android GATT stack firing STATE_CONNECTED multiple
                    // times for the same device (known race in some BT stacks). Without this
                    // check the same device accumulates duplicate entries, causing notify
                    // callbacks and relay logic to fire multiple times per event.
                    if (connectedDevices.none { it.address == device.address }) {
                        connectedDevices.add(device)
                    }
                    android.util.Log.i("BtGamepad", "Connected: ${device.name ?: "?"} — total hosts: ${connectedDevices.size}")
                }
                BluetoothProfile.STATE_DISCONNECTED -> {
                    connectedDevices.removeAll { it.address == device.address }
                    android.util.Log.i("BtGamepad", "Disconnected: ${device.name ?: "?"} — total hosts: ${connectedDevices.size}")
                }
            }
        }
        override fun onCharacteristicReadRequest(device: BluetoothDevice, requestId: Int, offset: Int, characteristic: BluetoothGattCharacteristic) {
            val v = characteristic.value ?: byteArrayOf()
            gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, offset, if (offset < v.size) v.copyOfRange(offset, v.size) else byteArrayOf())
        }
        override fun onCharacteristicWriteRequest(device: BluetoothDevice, requestId: Int, characteristic: BluetoothGattCharacteristic, preparedWrite: Boolean, responseNeeded: Boolean, offset: Int, value: ByteArray) {
            if (responseNeeded) gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, 0, null)
            when {
                // ── HID relay: SharpBlue pushed a report → echo to every other connected device
                // (the iPad HID host). The writer is excluded so there is no echo back to SharpBlue.
                characteristic === reportChar -> {
                    android.util.Log.d("BtGamepad", "← relay gamepad report (${value.size}B) to ${connectedDevices.size - 1} host(s)")
                    characteristic.value = value
                    connectedDevices.filter { it != device }
                        .forEach { gattServer?.notifyCharacteristicChanged(it, characteristic, false) }
                }
                characteristic === keyboardReportChar -> {
                    android.util.Log.d("BtGamepad", "← relay keyboard report (${value.size}B) to ${connectedDevices.size - 1} host(s)")
                    characteristic.value = value
                    connectedDevices.filter { it != device }
                        .forEach { gattServer?.notifyCharacteristicChanged(it, characteristic, false) }
                }
                characteristic === mouseChar -> {
                    android.util.Log.d("BtGamepad", "← relay mouse report (${value.size}B) to ${connectedDevices.size - 1} host(s)")
                    characteristic.value = value
                    connectedDevices.filter { it != device }
                        .forEach { gattServer?.notifyCharacteristicChanged(it, characteristic, false) }
                }
                // ── Notify channel: iPad sends a HomeScriptRunner command to the phone
                characteristic.uuid == CHR_NOTIFY_IN -> {
                    val text = String(value, Charsets.UTF_8).trim()
                    android.util.Log.i("BtGamepad", "← iPad wrote: \"$text\"")
                    val handler = onCommandReceived
                    if (handler != null) handler.invoke(text)
                    else android.util.Log.w("BtGamepad", "← iPad write received but onCommandReceived is null — set it before calling start()")
                }
            }
        }
        override fun onDescriptorReadRequest(device: BluetoothDevice, requestId: Int, offset: Int, descriptor: BluetoothGattDescriptor) {
            gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, offset, descriptor.value ?: byteArrayOf())
        }
        override fun onDescriptorWriteRequest(device: BluetoothDevice, requestId: Int, descriptor: BluetoothGattDescriptor, preparedWrite: Boolean, responseNeeded: Boolean, offset: Int, value: ByteArray) {
            descriptor.value = value; if (responseNeeded) gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, 0, null)
        }
    }

    private fun buildHidService(): BluetoothGattService {
        val svc = BluetoothGattService(SVC_HID, BluetoothGattService.SERVICE_TYPE_PRIMARY)
        svc.addCharacteristic(readChar(CHR_HID_INFO, byteArrayOf(0x01, 0x01, 0x00, 0x02)))
        svc.addCharacteristic(writeNoRespChar(CHR_HID_CTRL))
        svc.addCharacteristic(readChar(CHR_REPORT_MAP, HID_DESCRIPTOR))
        svc.addCharacteristic(BluetoothGattCharacteristic(CHR_PROTO_MODE, BluetoothGattCharacteristic.PROPERTY_READ or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE, BluetoothGattCharacteristic.PERMISSION_READ or BluetoothGattCharacteristic.PERMISSION_WRITE).also { it.value = byteArrayOf(0x01) })
        // Gamepad report (Report ID 1) — 9 bytes
        // WRITE_NO_RESPONSE added so SharpBlue can push reports in; phone relays them to iPad HID host.
        val rpt = BluetoothGattCharacteristic(CHR_REPORT,
            BluetoothGattCharacteristic.PROPERTY_READ or BluetoothGattCharacteristic.PROPERTY_NOTIFY or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE,
            BluetoothGattCharacteristic.PERMISSION_READ or BluetoothGattCharacteristic.PERMISSION_WRITE)
            .also { it.value = ByteArray(9) { i -> (if (i == 6) 8 else if (i < 4) 128 else 0).toByte() } }
        rpt.addDescriptor(BluetoothGattDescriptor(DSC_CCCD, BluetoothGattDescriptor.PERMISSION_READ or BluetoothGattDescriptor.PERMISSION_WRITE).also { it.value = BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE })
        rpt.addDescriptor(BluetoothGattDescriptor(DSC_REPORT_REF, BluetoothGattDescriptor.PERMISSION_READ).also { it.value = byteArrayOf(0x01, 0x01) })
        svc.addCharacteristic(rpt); reportChar = rpt

        // Keyboard report (Report ID 2) — 8 bytes: modifier + reserved + 6 keycodes
        // WRITE_NO_RESPONSE added so SharpBlue can push keyboard reports in; phone relays them to iPad HID host.
        val kbd = BluetoothGattCharacteristic(CHR_REPORT,
            BluetoothGattCharacteristic.PROPERTY_READ or BluetoothGattCharacteristic.PROPERTY_NOTIFY or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE,
            BluetoothGattCharacteristic.PERMISSION_READ or BluetoothGattCharacteristic.PERMISSION_WRITE)
            .also { it.value = ByteArray(8) }
        kbd.addDescriptor(BluetoothGattDescriptor(DSC_CCCD, BluetoothGattDescriptor.PERMISSION_READ or BluetoothGattDescriptor.PERMISSION_WRITE).also { it.value = BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE })
        kbd.addDescriptor(BluetoothGattDescriptor(DSC_REPORT_REF, BluetoothGattDescriptor.PERMISSION_READ).also { it.value = byteArrayOf(0x02, 0x01) })
        svc.addCharacteristic(kbd); keyboardReportChar = kbd

        return svc
    }

    private fun buildBatteryService(): BluetoothGattService {
        val svc = BluetoothGattService(SVC_BATT, BluetoothGattService.SERVICE_TYPE_PRIMARY)
        val batt = BluetoothGattCharacteristic(CHR_BATT_LEVEL, BluetoothGattCharacteristic.PROPERTY_READ or BluetoothGattCharacteristic.PROPERTY_NOTIFY, BluetoothGattCharacteristic.PERMISSION_READ).also { it.value = byteArrayOf(0x64) }
        batt.addDescriptor(BluetoothGattDescriptor(DSC_CCCD, BluetoothGattDescriptor.PERMISSION_READ or BluetoothGattDescriptor.PERMISSION_WRITE).also { it.value = BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE })
        svc.addCharacteristic(batt); return svc
    }

    private fun buildDeviceInfoService(): BluetoothGattService {
        val svc = BluetoothGattService(SVC_DEVINFO, BluetoothGattService.SERVICE_TYPE_PRIMARY)
        svc.addCharacteristic(readChar(CHR_MANUF, BtSharedConfig.DEVICE_NAME.toByteArray()))
        svc.addCharacteristic(readChar(CHR_MODEL, "nazcontroller 1.0".toByteArray())); return svc
    }

    private fun buildNotifyService(): BluetoothGattService {
        val svc = BluetoothGattService(SVC_NOTIFY, BluetoothGattService.SERVICE_TYPE_PRIMARY)
        // Write-only characteristic — iPad writes commands here, phone receives them
        val chr = BluetoothGattCharacteristic(
            CHR_NOTIFY_IN,
            BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE,
            BluetoothGattCharacteristic.PERMISSION_WRITE
        )
        svc.addCharacteristic(chr)
        return svc
    }

    private fun buildMouseService(): BluetoothGattService {
        val svc = BluetoothGattService(SVC_MOUSE, BluetoothGattService.SERVICE_TYPE_PRIMARY)
        val mouse = BluetoothGattCharacteristic(CHR_MOUSE, BluetoothGattCharacteristic.PROPERTY_READ or BluetoothGattCharacteristic.PROPERTY_NOTIFY or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE, BluetoothGattCharacteristic.PERMISSION_READ or BluetoothGattCharacteristic.PERMISSION_WRITE).also { it.value = ByteArray(6) }
        mouse.addDescriptor(BluetoothGattDescriptor(DSC_CCCD, BluetoothGattDescriptor.PERMISSION_READ or BluetoothGattDescriptor.PERMISSION_WRITE).also { it.value = BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE })
        svc.addCharacteristic(mouse); mouseChar = mouse; return svc
    }

    private fun readChar(uuid: UUID, value: ByteArray) = BluetoothGattCharacteristic(uuid, BluetoothGattCharacteristic.PROPERTY_READ, BluetoothGattCharacteristic.PERMISSION_READ).also { it.value = value }
    private fun writeNoRespChar(uuid: UUID) = BluetoothGattCharacteristic(uuid, BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE, BluetoothGattCharacteristic.PERMISSION_WRITE)
    private fun uuid(s: String): UUID = if (s.length == 4) UUID.fromString("0000$s-0000-1000-8000-00805f9b34fb") else UUID.fromString(s)
}
