package com.home.automation

import android.os.Environment
import java.io.File

object AdbComBlueWatcher {

    private val blueFile: File
        get() = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), "Screenshots/adbcomblue.txt")

    private val lock = Any()
    @Volatile private var thread: Thread? = null
    @Volatile private var processedCount = 0

    fun start(onNewLine: (command: String) -> Unit) {
        synchronized(lock) {
            if (thread?.isAlive == true) return
            processedCount = nonBlankLines().size
            val t = Thread {
                while (!Thread.currentThread().isInterrupted) {
                    try {
                        val lines = nonBlankLines()
                        if (lines.size > processedCount) {
                            for (i in processedCount until lines.size) {
                                val cmd = lines[i].trim()
                                if (cmd.isNotEmpty()) { android.util.Log.d("AdbComBlueWatcher", "New BLE command: $cmd"); onNewLine(cmd) }
                            }
                            processedCount = lines.size
                        } else if (lines.size < processedCount) {
                            processedCount = lines.size
                        }
                        Thread.sleep(500)
                    } catch (_: InterruptedException) { break
                    } catch (e: Exception) { android.util.Log.e("AdbComBlueWatcher", "Poll error: ${e.message}"); try { Thread.sleep(1000) } catch (_: InterruptedException) { break } }
                }
            }
            t.name = "AdbComBlueWatcher"; t.isDaemon = true; t.start(); thread = t
        }
    }

    fun stop() { synchronized(lock) { thread?.interrupt(); thread = null } }

    private fun nonBlankLines(): List<String> = try {
        if (blueFile.exists()) blueFile.readLines().filter { it.isNotBlank() } else emptyList()
    } catch (_: Exception) { emptyList() }
}
