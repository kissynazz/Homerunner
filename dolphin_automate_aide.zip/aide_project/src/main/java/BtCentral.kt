package com.home.automation

import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.ParcelUuid
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.atomic.AtomicBoolean

object BtCentral {

    private data class PendingCommand(val context: Context, val action: String, val data: String, val rawBytes: ByteArray? = null)

    private val queue = LinkedBlockingQueue<PendingCommand>()
    private val busy  = AtomicBoolean(false)
    private var scanner: BluetoothLeScanner? = null
    private var scanCallback: ScanCallback? = null
    private var gatt: BluetoothGatt? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private const val SCAN_TIMEOUT_MS = 15_000L

    /** Cancel any in-progress scan/connection and clear the command queue.
     *  Central re-arms itself automatically next time a command arrives. */
    fun restart() {
        mainHandler.post {
            try { scanCallback?.let { scanner?.stopScan(it) } } catch (_: Exception) {}
            scanCallback = null
            try { gatt?.disconnect(); gatt?.close() } catch (_: Exception) {}
            gatt = null
            queue.clear()
            busy.set(false)
            android.util.Log.i("BtCentral", "restart() — state cleared, ready for next command")
        }
    }

    fun enqueueCommand(context: Context, action: String, data: String) {
        queue.put(PendingCommand(context, action, data))
        drainIfIdle()
    }

    fun enqueueRaw(context: Context, line: String) {
        queue.put(PendingCommand(context, action = line, data = "", rawBytes = line.toByteArray(Charsets.UTF_8)))
        drainIfIdle()
    }

    fun disconnect() {
        queue.clear(); stopScan()
        gatt?.disconnect(); gatt?.close(); gatt = null; busy.set(false)
    }

    fun status(): String {
        val sb = StringBuilder()
        sb.append("BT Central\n")
        sb.append("─────────────────\n")
        val device = gatt?.device
        when {
            device != null -> {
                sb.append("● Connected to: ${device.name ?: "Unknown"}\n")
                sb.append("  Address : ${device.address}\n")
                sb.append("  Type    : ${deviceTypeName(device.type)}\n")
            }
            scanCallback != null -> sb.append("◌ Scanning for peripheral…\n")
            busy.get()          -> sb.append("◌ Connecting…\n")
            else                -> sb.append("○ Idle — not connected\n")
        }
        val q = queue.size
        if (q > 0) sb.append("  Queued  : $q command(s) pending\n")
        sb.append("\nRole: scans and connects TO a peripheral,\nthen sends it a command.")
        return sb.toString()
    }

    private fun deviceTypeName(type: Int) = when (type) {
        android.bluetooth.BluetoothDevice.DEVICE_TYPE_CLASSIC -> "Classic"
        android.bluetooth.BluetoothDevice.DEVICE_TYPE_LE      -> "BLE"
        android.bluetooth.BluetoothDevice.DEVICE_TYPE_DUAL    -> "Dual"
        else -> "Unknown"
    }

    private fun drainIfIdle() {
        if (!busy.compareAndSet(false, true)) return
        val next = queue.poll() ?: run { busy.set(false); return }
        executeCommand(next)
    }

    private fun onCycleFinished() { busy.set(false); drainIfIdle() }

    private fun executeCommand(cmd: PendingCommand) {
        try {
            val manager = cmd.context.getSystemService(android.content.Context.BLUETOOTH_SERVICE) as BluetoothManager
            val adapter = manager.adapter ?: run { android.util.Log.e("BtCentral", "Bluetooth not available"); onCycleFinished(); return }
            if (!adapter.isEnabled) { android.util.Log.e("BtCentral", "Bluetooth is off"); onCycleFinished(); return }
            val commandBytes = cmd.rawBytes ?: BtSharedConfig.encodeCommand(cmd.action, cmd.data)
            scanner = adapter.bluetoothLeScanner
            if (scanner == null) { android.util.Log.e("BtCentral", "BLE scanner not available"); onCycleFinished(); return }
            val filter = ScanFilter.Builder().setServiceUuid(ParcelUuid(BtSharedConfig.SERVICE_UUID)).build()
            val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
            scanCallback = object : ScanCallback() {
                override fun onScanResult(callbackType: Int, result: ScanResult) {
                    stopScan(); connectAndSend(cmd.context, result.device, commandBytes)
                }
                override fun onScanFailed(errorCode: Int) { android.util.Log.e("BtCentral", "Scan failed: $errorCode"); onCycleFinished() }
            }
            scanner?.startScan(listOf(filter), settings, scanCallback!!)
            mainHandler.postDelayed({ if (scanCallback != null) { stopScan(); onCycleFinished() } }, SCAN_TIMEOUT_MS)
        } catch (e: Exception) {
            android.util.Log.e("BtCentral", "executeCommand failed: ${e.message}")
            scanCallback = null; onCycleFinished()
        }
    }

    private fun stopScan() { scanCallback?.let { scanner?.stopScan(it) }; scanCallback = null }

    private fun connectAndSend(context: Context, device: BluetoothDevice, commandBytes: ByteArray) {
        gatt = device.connectGatt(context, false, object : BluetoothGattCallback() {
            override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
                when (newState) {
                    BluetoothProfile.STATE_CONNECTED    -> gatt.discoverServices()
                    BluetoothProfile.STATE_DISCONNECTED -> { gatt.close(); this@BtCentral.gatt = null; onCycleFinished() }
                }
            }
            override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
                if (status != BluetoothGatt.GATT_SUCCESS) { gatt.disconnect(); return }
                val svc  = gatt.getService(BtSharedConfig.SERVICE_UUID)
                val cmd  = svc?.getCharacteristic(BtSharedConfig.COMMAND_CHAR_UUID)
                val res  = svc?.getCharacteristic(BtSharedConfig.RESULT_CHAR_UUID)
                if (cmd == null) { gatt.disconnect(); return }
                if (res != null) {
                    gatt.setCharacteristicNotification(res, true)
                    val desc = res.getDescriptor(BtSharedConfig.NOTIFY_DESC_UUID)
                    if (desc != null) { desc.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE; gatt.writeDescriptor(desc); return }
                }
                sendCommandChar(gatt, cmd, commandBytes)
            }
            override fun onDescriptorWrite(gatt: BluetoothGatt, descriptor: BluetoothGattDescriptor, status: Int) {
                val cmd = gatt.getService(BtSharedConfig.SERVICE_UUID)?.getCharacteristic(BtSharedConfig.COMMAND_CHAR_UUID)
                if (cmd != null) sendCommandChar(gatt, cmd, commandBytes) else gatt.disconnect()
            }
            override fun onCharacteristicWrite(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) {
                if (status == BluetoothGatt.GATT_SUCCESS) SoundPlayer.playCommandFired() else gatt.disconnect()
            }
            override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
                if (characteristic.uuid == BtSharedConfig.RESULT_CHAR_UUID) gatt.disconnect()
            }
        }, BluetoothDevice.TRANSPORT_LE)
    }

    private fun sendCommandChar(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, bytes: ByteArray) {
        characteristic.value = bytes; characteristic.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT; gatt.writeCharacteristic(characteristic)
    }
}
