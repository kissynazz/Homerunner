package com.home.automation

import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.os.ParcelUuid

object BtPeripheral {

    private var gattServer: BluetoothGattServer? = null
    private var advertiseCallback: AdvertiseCallback? = null
    private val connectedDevices = mutableListOf<BluetoothDevice>()

    fun start(context: Context, onStatus: ((String) -> Unit)? = null) {
        try {
            val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
            val adapter = manager.adapter ?: run {
                val msg = "ERROR: Bluetooth adapter not available"
                android.util.Log.e("BtPeripheral", msg); onStatus?.invoke(msg); return
            }
            if (!adapter.isEnabled) {
                val msg = "ERROR: Bluetooth is off — enable it and try again"
                android.util.Log.e("BtPeripheral", msg); onStatus?.invoke(msg); return
            }

            val commandChar = BluetoothGattCharacteristic(BtSharedConfig.COMMAND_CHAR_UUID,
                BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE,
                BluetoothGattCharacteristic.PERMISSION_WRITE)

            val resultChar = BluetoothGattCharacteristic(BtSharedConfig.RESULT_CHAR_UUID,
                BluetoothGattCharacteristic.PROPERTY_READ or BluetoothGattCharacteristic.PROPERTY_NOTIFY,
                BluetoothGattCharacteristic.PERMISSION_READ).also {
                it.addDescriptor(BluetoothGattDescriptor(BtSharedConfig.NOTIFY_DESC_UUID,
                    BluetoothGattDescriptor.PERMISSION_READ or BluetoothGattDescriptor.PERMISSION_WRITE))
            }

            val service = BluetoothGattService(BtSharedConfig.SERVICE_UUID, BluetoothGattService.SERVICE_TYPE_PRIMARY)
                .also { it.addCharacteristic(commandChar); it.addCharacteristic(resultChar) }

            gattServer = manager.openGattServer(context, object : BluetoothGattServerCallback() {
                override fun onConnectionStateChange(device: BluetoothDevice, status: Int, newState: Int) {
                    when (newState) {
                        BluetoothProfile.STATE_CONNECTED    -> connectedDevices.add(device)
                        BluetoothProfile.STATE_DISCONNECTED -> connectedDevices.remove(device)
                    }
                }
                override fun onCharacteristicWriteRequest(device: BluetoothDevice, requestId: Int, characteristic: BluetoothGattCharacteristic, preparedWrite: Boolean, responseNeeded: Boolean, offset: Int, value: ByteArray) {
                    if (characteristic.uuid != BtSharedConfig.COMMAND_CHAR_UUID) return
                    if (responseNeeded) gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, 0, null)
                    val (action, data) = BtSharedConfig.decodeCommand(value)
                    Thread {
                        SoundPlayer.playFileChanged()
                        val result = HomeScriptRunner.executeAction(action, data)
                        SoundPlayer.playCommandFired()
                        resultChar.value = result.toByteArray(Charsets.UTF_8)
                        connectedDevices.forEach { gattServer?.notifyCharacteristicChanged(it, resultChar, false) }
                    }.start()
                }
                override fun onDescriptorWriteRequest(device: BluetoothDevice, requestId: Int, descriptor: BluetoothGattDescriptor, preparedWrite: Boolean, responseNeeded: Boolean, offset: Int, value: ByteArray) {
                    descriptor.value = value
                    if (responseNeeded) gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, 0, null)
                }
            })
            if (gattServer == null) {
                val msg = "ERROR: openGattServer returned null\n(BT permission missing or BT stack busy)"
                android.util.Log.e("BtPeripheral", msg); onStatus?.invoke(msg); return
            }
            gattServer?.addService(service)

            // Rename adapter — catch in case it throws on some devices.
            try { adapter.name = BtSharedConfig.DEVICE_NAME }
            catch (e: Exception) { android.util.Log.w("BtPeripheral", "Could not rename adapter: ${e.message}") }

            val settings = AdvertiseSettings.Builder().setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY).setConnectable(true).setTimeout(0).build()
            val advData = AdvertiseData.Builder().addServiceUuid(ParcelUuid(BtSharedConfig.SERVICE_UUID)).setIncludeDeviceName(true).build()
            advertiseCallback = object : AdvertiseCallback() {
                override fun onStartSuccess(s: AdvertiseSettings?) {
                    android.util.Log.d("BtPeripheral", "Advertising started OK")
                    onStatus?.invoke("● Advertising as \"${BtSharedConfig.DEVICE_NAME}\"\n● GATT server: open\n\nReady — connect with LightBlue or nRF Connect.")
                }
                override fun onStartFailure(errorCode: Int) {
                    val reason = advertiseErrorReason(errorCode)
                    android.util.Log.e("BtPeripheral", "Advertising failed: $errorCode $reason")
                    advertiseCallback = null
                    onStatus?.invoke("ERROR: Advertising failed\nCode $errorCode — $reason\n\nTry: toggle BT off/on, then restart again.")
                }
            }
            val advertiser = adapter.bluetoothLeAdvertiser
            if (advertiser == null) {
                val msg = "ERROR: LE advertising not supported on this device"
                android.util.Log.e("BtPeripheral", msg); advertiseCallback = null; onStatus?.invoke(msg)
            } else {
                advertiser.startAdvertising(settings, advData, advertiseCallback)
                onStatus?.invoke("Starting advertising… waiting for result.")
            }
        } catch (e: Exception) {
            android.util.Log.e("BtPeripheral", "start() failed: ${e.message}")
            gattServer = null; advertiseCallback = null
            onStatus?.invoke("ERROR: start() threw ${e.javaClass.simpleName}\n${e.message}")
        }
    }

    private fun advertiseErrorReason(code: Int) = when (code) {
        1 -> "data too large"
        2 -> "too many advertisers (other apps using BLE)"
        3 -> "already started"
        4 -> "internal error (BT stack crash — toggle BT)"
        5 -> "feature unsupported"
        else -> "unknown"
    }

    fun status(): String {
        val sb = StringBuilder()
        sb.append("BT Peripheral\n")
        sb.append("─────────────────\n")
        if (gattServer == null && advertiseCallback == null) {
            sb.append("○ Not started\n")
        } else {
            if (advertiseCallback != null) sb.append("● Advertising as \"${BtSharedConfig.DEVICE_NAME}\"\n")
            else sb.append("○ Not advertising\n")
            if (gattServer != null) sb.append("● GATT server: open\n")
            val count = connectedDevices.size
            if (count == 0) {
                sb.append("  No devices connected\n")
            } else {
                sb.append("  Connected ($count):\n")
                connectedDevices.forEach { d ->
                    sb.append("  • ${d.name ?: "Unknown"}  ${d.address}\n")
                }
            }
        }
        sb.append("\nRole: advertises so other devices\ncan connect TO the phone.")
        return sb.toString()
    }

    fun stop(context: Context) {
        val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        advertiseCallback?.let { manager.adapter?.bluetoothLeAdvertiser?.stopAdvertising(it) }
        gattServer?.close(); gattServer = null; connectedDevices.clear()
    }
}
