import java.io.*;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;

/**
 * NazModelSaver — finds Dolphin character model files and saves copies
 * prefixed with "nazmodel_" so they survive app clears or reinstalls.
 *
 * Targets:
 *   • Skylander figure files     (.bin  in Skylanders/)
 *   • Disney Infinity figures    (.bin  in Infinity/)
 *   • Custom textures            (.png/.dds  in Load/Textures/)
 *   • Game file cache            (gameList.cache)
 *   • Shader pipeline cache      (.cache in Cache/Shaders/)
 *   • Save states                (.sav in StateSaves/)
 *
 * Usage (JVDroid / kotlinc / javac + java):
 *   java NazModelSaver
 *   java NazModelSaver /sdcard/dolphin-emu /sdcard/nazmodels
 */
public class NazModelSaver {

    // ── Dolphin user data root on Android ────────────────────────────────────
    static final String DEFAULT_DOLPHIN_DIR = "/sdcard/dolphin-emu";
    static final String DEFAULT_OUTPUT_DIR  = "/sdcard/nazmodels";

    // ── File extensions / names considered "model" data ──────────────────────
    static final Set<String> TARGET_EXTENSIONS = new HashSet<>(Arrays.asList(
        ".bin",   // Skylander / Infinity figures
        ".png",   // custom textures
        ".dds",   // DDS textures
        ".cache", // game list cache / shader cache
        ".sav",   // save states
        ".dtm"    // replay/movie files
    ));

    // Subfolders inside dolphin-emu/ that hold model-related files
    static final List<String> TARGET_SUBDIRS = Arrays.asList(
        "Skylanders",
        "Infinity",
        "Load/Textures",
        "Cache/Shaders",
        "StateSaves",
        "Cache"
    );

    // ── Counters ──────────────────────────────────────────────────────────────
    int found   = 0;
    int copied  = 0;
    int skipped = 0;
    int errors  = 0;

    // ─────────────────────────────────────────────────────────────────────────

    public static void main(String[] args) throws Exception {
        String dolphinDir = args.length > 0 ? args[0] : DEFAULT_DOLPHIN_DIR;
        String outputDir  = args.length > 1 ? args[1] : DEFAULT_OUTPUT_DIR;

        new NazModelSaver().run(dolphinDir, outputDir);
    }

    void run(String dolphinRoot, String outputRoot) {
        File root = new File(dolphinRoot);
        if (!root.exists() || !root.isDirectory()) {
            err("Dolphin directory not found: " + dolphinRoot);
            err("Make sure Dolphin is installed and has been launched at least once.");
            err("Default path: /sdcard/dolphin-emu");
            return;
        }

        File out = new File(outputRoot);
        if (!out.exists() && !out.mkdirs()) {
            err("Could not create output directory: " + outputRoot);
            return;
        }

        log("╔═══════════════════════════════════════╗");
        log("║       NazModel Saver — Dolphin        ║");
        log("╚═══════════════════════════════════════╝");
        log("  Source : " + root.getAbsolutePath());
        log("  Output : " + out.getAbsolutePath());
        log("");

        // 1. Scan targeted subdirectories
        for (String subDir : TARGET_SUBDIRS) {
            File dir = new File(root, subDir);
            if (dir.exists()) {
                log("── Scanning: " + subDir);
                scanDirectory(dir, out, subDir.replace("/", "_") + "_");
            }
        }

        // 2. Also grab the gameList.cache from the root Cache dir explicitly
        File gameListCache = new File(root, "Cache/gameList.cache");
        if (gameListCache.exists()) {
            copyFile(gameListCache, out, "gameList_");
        }

        // ── Summary ───────────────────────────────────────────────────────────
        log("");
        log("═══════════════════════════════════════");
        log("  Files found   : " + found);
        log("  Files copied  : " + copied);
        log("  Already exist : " + skipped);
        log("  Errors        : " + errors);
        log("═══════════════════════════════════════");
        if (copied > 0) {
            log("  Saved to: " + out.getAbsolutePath());
        }
    }

    // ── Recursively scan a directory for target file types ───────────────────
    void scanDirectory(File dir, File outputDir, String prefix) {
        File[] files = dir.listFiles();
        if (files == null) return;

        for (File file : files) {
            if (file.isDirectory()) {
                // recurse, extending the prefix so names stay unique
                scanDirectory(file, outputDir, prefix + file.getName() + "_");
            } else if (isTargetFile(file)) {
                found++;
                copyFile(file, outputDir, prefix);
            }
        }
    }

    // ── Copy a single file with the "nazmodel_" prefix ───────────────────────
    void copyFile(File src, File outputDir, String subPrefix) {
        String destName = "nazmodel_" + subPrefix + src.getName();
        File dest = new File(outputDir, destName);

        if (dest.exists()) {
            // Skip if identical size to avoid redundant copies
            if (dest.length() == src.length()) {
                log("  SKIP  " + destName + "  (unchanged)");
                skipped++;
                return;
            }
        }

        try {
            copyBytes(src, dest);
            log("  COPY  " + src.getName()
                + "  →  " + destName
                + "  (" + humanSize(src.length()) + ")");
            copied++;
        } catch (IOException e) {
            err("  ERROR copying " + src.getName() + ": " + e.getMessage());
            errors++;
        }
    }

    // ── File copy without NIO (compatible with JVDroid / older runtimes) ─────
    void copyBytes(File src, File dest) throws IOException {
        byte[] buffer = new byte[64 * 1024];
        try (InputStream in  = new FileInputStream(src);
             OutputStream out = new FileOutputStream(dest)) {
            int n;
            while ((n = in.read(buffer)) != -1) {
                out.write(buffer, 0, n);
            }
        }
    }

    // ── Check if file extension is in our target set ─────────────────────────
    boolean isTargetFile(File file) {
        String name = file.getName().toLowerCase();
        for (String ext : TARGET_EXTENSIONS) {
            if (name.endsWith(ext)) return true;
        }
        return false;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    static String humanSize(long bytes) {
        if (bytes < 1024)          return bytes + " B";
        if (bytes < 1024 * 1024)   return String.format("%.1f KB", bytes / 1024.0);
        return                            String.format("%.1f MB", bytes / (1024.0 * 1024));
    }

    static void log(String msg) { System.out.println(msg); }
    static void err(String msg) { System.err.println("[ERROR] " + msg); }
}
