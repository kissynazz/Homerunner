#!/usr/bin/env kotlinc -script
/**
 * Dolphin Android — Kotlin Build & Run Script
 *
 * Usage (from the dolphin-android/ directory):
 *   kotlinc -script build_run.kts              → assembleDebug (default)
 *   kotlinc -script build_run.kts release      → assembleRelease
 *   kotlinc -script build_run.kts install      → assembleDebug + adb install
 *   kotlinc -script build_run.kts clean        → clean
 *   kotlinc -script build_run.kts check        → check prerequisites only
 *
 * Requirements:
 *   - Java 17+
 *   - Android SDK (ANDROID_HOME env var must point to it)
 *   - Android NDK 29.0.14206865  (installed via SDK Manager)
 *   - Connected device / emulator for 'install' task
 */

import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

// ─── Config ──────────────────────────────────────────────────────────────────

val PROJECT_DIR   = File(System.getProperty("user.dir"))
val GRADLEW       = if (System.getProperty("os.name").contains("win", ignoreCase = true))
                        File(PROJECT_DIR, "gradlew.bat")
                    else
                        File(PROJECT_DIR, "gradlew")
val APK_DEBUG_DIR = File(PROJECT_DIR, "app/build/outputs/apk/debug")
val APK_REL_DIR   = File(PROJECT_DIR, "app/build/outputs/apk/release")

// ─── Helpers ─────────────────────────────────────────────────────────────────

fun run(cmd: List<String>, env: Map<String, String> = emptyMap(), dir: File = PROJECT_DIR): Int {
    val pb = ProcessBuilder(cmd)
        .directory(dir)
        .redirectErrorStream(true)
    pb.environment().putAll(env)
    val proc = pb.start()
    val reader = BufferedReader(InputStreamReader(proc.inputStream))
    reader.lines().forEach { println(it) }
    return proc.waitFor()
}

fun runCapture(cmd: List<String>): String = try {
    val proc = ProcessBuilder(cmd).redirectErrorStream(true).start()
    proc.inputStream.bufferedReader().readText().trim().also { proc.waitFor() }
} catch (e: Exception) { "" }

fun section(title: String) = println("\n\u001B[36m══ $title \u001B[0m")
fun ok(msg: String)   = println("\u001B[32m✔  $msg\u001B[0m")
fun warn(msg: String) = println("\u001B[33m⚠  $msg\u001B[0m")
fun err(msg: String)  = println("\u001B[31m✘  $msg\u001B[0m")
fun info(msg: String) = println("   $msg")

// ─── Prerequisite Check ───────────────────────────────────────────────────────

fun checkPrereqs(): Boolean {
    section("Checking prerequisites")
    var ok = true

    // Java
    val javaVer = runCapture(listOf("java", "-version"))
    if (javaVer.isBlank()) {
        err("Java not found — install Java 17+")
        ok = false
    } else {
        val vNum = Regex("version \"(\\d+)").find(javaVer)?.groupValues?.get(1)?.toIntOrNull() ?: 0
        if (vNum < 17) {
            err("Java $vNum found, but Java 17+ is required")
            ok = false
        } else {
            ok("Java $vNum detected")
        }
    }

    // ANDROID_HOME
    val androidHome = System.getenv("ANDROID_HOME") ?: System.getenv("ANDROID_SDK_ROOT") ?: ""
    if (androidHome.isBlank() || !File(androidHome).exists()) {
        err("ANDROID_HOME is not set or does not exist")
        err("  Set it to your Android SDK path, e.g.:")
        info("    export ANDROID_HOME=\$HOME/Android/Sdk         # Linux/macOS")
        info("    set ANDROID_HOME=C:\\Users\\<you>\\AppData\\Local\\Android\\Sdk  # Windows")
        ok = false
    } else {
        ok("ANDROID_HOME = $androidHome")

        // NDK check
        val ndkRequired = "29.0.14206865"
        val ndkDir = File(androidHome, "ndk/$ndkRequired")
        if (!ndkDir.exists()) {
            warn("NDK $ndkRequired not found at $ndkDir")
            warn("  Install it via Android Studio > SDK Manager > SDK Tools > NDK (Side by side)")
            warn("  Or run: \$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager \"ndk;$ndkRequired\"")
        } else {
            ok("NDK $ndkRequired found")
        }

        // Build tools / platform check
        val platformDir = File(androidHome, "platforms/android-36")
        if (!platformDir.exists()) {
            warn("Android SDK Platform 36 not found — Gradle will try to download it automatically")
        } else {
            ok("Android SDK Platform 36 found")
        }
    }

    // gradlew
    if (!GRADLEW.exists()) {
        err("gradlew not found — are you running from inside dolphin-android/?")
        ok = false
    } else {
        GRADLEW.setExecutable(true)
        ok("gradlew found")
    }

    return ok
}

// ─── Build Tasks ─────────────────────────────────────────────────────────────

fun assembleDebug(): Boolean {
    section("Building Dolphin — assembleDebug")
    info("This compiles C++ via CMake + NDK and packages the APK.")
    info("First run may take 10-30 minutes.\n")
    val code = run(listOf(GRADLEW.absolutePath, "assembleDebug", "--stacktrace"))
    return if (code == 0) {
        ok("Build succeeded!")
        val apks = APK_DEBUG_DIR.listFiles { f -> f.extension == "apk" } ?: emptyArray()
        apks.forEach { ok("APK → ${it.absolutePath}") }
        true
    } else {
        err("Build failed (exit $code) — see output above")
        false
    }
}

fun assembleRelease(): Boolean {
    section("Building Dolphin — assembleRelease")
    warn("Release builds require a signing keystore. Set these env vars:")
    info("  KEYSTORE_PATH, KEYSTORE_PASS, KEY_ALIAS, KEY_PASS")
    val code = run(listOf(GRADLEW.absolutePath, "assembleRelease", "--stacktrace"))
    return if (code == 0) {
        ok("Release build succeeded!")
        val apks = APK_REL_DIR.listFiles { f -> f.extension == "apk" } ?: emptyArray()
        apks.forEach { ok("APK → ${it.absolutePath}") }
        true
    } else {
        err("Release build failed (exit $code) — see output above")
        false
    }
}

fun clean() {
    section("Cleaning build outputs")
    val code = run(listOf(GRADLEW.absolutePath, "clean"))
    if (code == 0) ok("Clean complete") else err("Clean failed (exit $code)")
}

fun installOnDevice(): Boolean {
    section("Installing APK on connected device")

    // First build
    if (!assembleDebug()) return false

    // Find the APK
    val apk = APK_DEBUG_DIR.listFiles { f -> f.extension == "apk" }?.firstOrNull()
    if (apk == null) { err("No APK found in $APK_DEBUG_DIR"); return false }

    // Check for connected device
    val devices = runCapture(listOf("adb", "devices"))
    val connected = devices.lines().drop(1).filter { it.contains("\tdevice") }
    if (connected.isEmpty()) {
        err("No ADB device connected.")
        info("  Enable USB Debugging on your Android device, connect it, then re-run.")
        info("  Or start an emulator via Android Studio.")
        return false
    }
    ok("Device found: ${connected.first().trim()}")

    // Install
    section("Running: adb install -r ${apk.name}")
    val code = run(listOf("adb", "install", "-r", apk.absolutePath))
    return if (code == 0) {
        ok("Dolphin installed on device!")
        info("Launch it from your app drawer, or run:")
        info("  adb shell monkey -p org.dolphinemu.dolphinemu -c android.intent.category.LAUNCHER 1")
        true
    } else {
        err("adb install failed (exit $code)")
        false
    }
}

// ─── ADB Launch Helpers ───────────────────────────────────────────────────────

fun launchDolphin() {
    section("Launching Dolphin on device via ADB")
    val code = run(listOf("adb", "shell", "monkey",
        "-p", "org.dolphinemu.dolphinemu",
        "-c", "android.intent.category.LAUNCHER", "1"))
    if (code == 0) ok("Dolphin launched!") else err("Launch failed — is it installed?")
}

fun stopDolphin() {
    section("Stopping Dolphin")
    run(listOf("adb", "shell", "am", "force-stop", "org.dolphinemu.dolphinemu"))
    ok("Stopped")
}

fun logcat() {
    section("Streaming Dolphin logcat (Ctrl+C to stop)")
    run(listOf("adb", "logcat", "-s", "DolphinEmulator:V", "AndroidRuntime:E", "*:S"))
}

// ─── Main ─────────────────────────────────────────────────────────────────────

println("\u001B[35m╔═══════════════════════════════════════╗")
println("║   Dolphin Android — Build & Run       ║")
println("╚═══════════════════════════════════════╝\u001B[0m")

val task = args.firstOrNull() ?: "debug"

when (task.lowercase()) {
    "check"   -> checkPrereqs()
    "clean"   -> { if (checkPrereqs()) clean() }
    "debug",
    "assemble" -> { if (checkPrereqs()) assembleDebug() }
    "release" -> { if (checkPrereqs()) assembleRelease() }
    "install" -> { if (checkPrereqs()) installOnDevice() }
    "launch"  -> launchDolphin()
    "stop"    -> stopDolphin()
    "logcat"  -> logcat()
    "help", "-h", "--help" -> {
        println("""
  Commands:
    (none / debug)  — build debug APK via assembleDebug
    release         — build release APK
    install         — build debug APK + adb install to connected device
    launch          — adb launch Dolphin on connected device
    stop            — adb force-stop Dolphin
    logcat          — stream Dolphin logcat output
    clean           — clean build outputs
    check           — check prerequisites only
    help            — show this message

  Examples:
    kotlinc -script build_run.kts
    kotlinc -script build_run.kts install
    kotlinc -script build_run.kts launch
        """.trimIndent())
    }
    else -> { err("Unknown task: $task"); println("Run with 'help' for available commands.") }
}
