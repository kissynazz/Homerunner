package com.home.automation

import android.content.Context
import android.view.KeyEvent

/**
 * ImeKeyboard — singleton that maps the overlay's refKey strings and
 * joystick normalised values to Android KeyEvent keycodes, then dispatches
 * them through OverlayImeService.
 *
 * All Shizuku / Rikka / su / uinput code has been removed.  The only
 * requirement is that the user has enabled "Overlay Controller" as their
 * active IME in Android Settings.
 *
 * DEFAULT KEY MAP (configure matching bindings in Dolphin → Controller Settings
 *                 → Emulated → Keyboard → each button):
 * ─────────────────────────────────────────────────────
 *  Overlay button │ Android KeyEvent     │ Dolphin maps to
 *  ───────────────┼──────────────────────┼─────────────────
 *  BTN_A          │ KEYCODE_A            │ Button A
 *  BTN_B          │ KEYCODE_B            │ Button B
 *  BTN_X          │ KEYCODE_X            │ Button X
 *  BTN_Y          │ KEYCODE_Y            │ Button Y
 *  BTN_Z          │ KEYCODE_Z            │ Button Z
 *  BTN_L1         │ KEYCODE_Q            │ L Trigger
 *  BTN_R1         │ KEYCODE_E            │ R Trigger
 *  BTN_L2         │ KEYCODE_1            │ L2 / Alt-L
 *  BTN_R2         │ KEYCODE_2            │ R2 / Alt-R
 *  BTN_START      │ KEYCODE_ENTER        │ Start
 *  BTN_SELECT     │ KEYCODE_TAB          │ Select / Z (GC)
 *  DPAD_UP        │ KEYCODE_DPAD_UP      │ D-pad Up
 *  DPAD_DOWN      │ KEYCODE_DPAD_DOWN    │ D-pad Down
 *  DPAD_LEFT      │ KEYCODE_DPAD_LEFT    │ D-pad Left
 *  DPAD_RIGHT     │ KEYCODE_DPAD_RIGHT   │ D-pad Right
 *  Left stick ↑   │ KEYCODE_W            │ Main Stick Up
 *  Left stick ↓   │ KEYCODE_S            │ Main Stick Down
 *  Left stick ←   │ KEYCODE_A ← clash!  │  ← use KEYCODE_LEFT instead
 *  Left stick →   │ KEYCODE_D            │ Main Stick Right
 *  Right stick ↑  │ KEYCODE_I            │ C-Stick Up
 *  Right stick ↓  │ KEYCODE_K            │ C-Stick Down
 *  Right stick ←  │ KEYCODE_J            │ C-Stick Left
 *  Right stick →  │ KEYCODE_L            │ C-Stick Right
 * ─────────────────────────────────────────────────────
 * Note: KEYCODE_A is used for both BTN_A and left-stick-left.
 * Map left-stick-left to KEYCODE_LEFT (←) in Dolphin so they don't clash.
 */
object ImeKeyboard {

    // ── IME instance reference ─────────────────────────────────────────────
    @Volatile private var svc: OverlayImeService? = null

    internal fun bind(s: OverlayImeService)   { svc = s }
    internal fun unbind(s: OverlayImeService) { if (svc === s) svc = null }

    val isAvailable: Boolean get() = svc != null

    // ── Stick state — tracks which directional keys are currently held ─────
    // Avoids repeated DOWN events when the stick is held in a direction.
    private val heldKeys = mutableSetOf<Int>()

    private const val STICK_DEAD = 0.40f  // normalised deadzone radius

    // ── refKey → KeyEvent mapping ──────────────────────────────────────────

    private val refKeyMap = mapOf(
        "BTN_A"      to KeyEvent.KEYCODE_A,
        "BTN_B"      to KeyEvent.KEYCODE_B,
        "BTN_C"      to KeyEvent.KEYCODE_C,
        "BTN_X"      to KeyEvent.KEYCODE_X,
        "BTN_Y"      to KeyEvent.KEYCODE_Y,
        "BTN_Z"      to KeyEvent.KEYCODE_Z,
        "BTN_L1"     to KeyEvent.KEYCODE_Q,
        "BTN_R1"     to KeyEvent.KEYCODE_E,
        "BTN_L2"     to KeyEvent.KEYCODE_1,
        "BTN_R2"     to KeyEvent.KEYCODE_2,
        "BTN_START"  to KeyEvent.KEYCODE_ENTER,
        "BTN_SELECT" to KeyEvent.KEYCODE_TAB,
        "DPAD_UP"    to KeyEvent.KEYCODE_DPAD_UP,
        "DPAD_DOWN"  to KeyEvent.KEYCODE_DPAD_DOWN,
        "DPAD_LEFT"  to KeyEvent.KEYCODE_DPAD_LEFT,
        "DPAD_RIGHT" to KeyEvent.KEYCODE_DPAD_RIGHT
    )

    // Left stick: left = KEYCODE_LEFT to avoid clash with BTN_A = KEYCODE_A
    private val leftStickKeys = mapOf(
        "up"    to KeyEvent.KEYCODE_W,
        "down"  to KeyEvent.KEYCODE_S,
        "left"  to KeyEvent.KEYCODE_DPAD_LEFT,   // or remap to KEYCODE_LEFT in Dolphin
        "right" to KeyEvent.KEYCODE_D
    )

    private val rightStickKeys = mapOf(
        "up"    to KeyEvent.KEYCODE_I,
        "down"  to KeyEvent.KEYCODE_K,
        "left"  to KeyEvent.KEYCODE_J,
        "right" to KeyEvent.KEYCODE_L
    )

    // ── Public API — called from FloatingOverlay button listeners ──────────

    /**
     * Button press or release.  Same refKey strings used throughout
     * FloatingOverlay ("BTN_A", "DPAD_UP", "BTN_L1" …).
     */
    fun sendRefKey(refKey: String, pressed: Boolean) {
        val code = refKeyMap[refKey] ?: return
        if (pressed) pressKey(code) else releaseKey(code)
    }

    /**
     * Joystick input — normalised (-1..1) on each axis.
     * Converts to directional key presses with hysteresis at STICK_DEAD.
     * isLeft=true  → W/A/S/D  (main stick)
     * isLeft=false → I/J/K/L  (C-stick / right stick)
     */
    fun sendStick(isLeft: Boolean, nx: Float, ny: Float) {
        val keys = if (isLeft) leftStickKeys else rightStickKeys

        setStickKey(keys["right"]!!, nx >  STICK_DEAD)
        setStickKey(keys["left"]!!,  nx < -STICK_DEAD)
        setStickKey(keys["down"]!!,  ny >  STICK_DEAD)   // +Y = down on screen
        setStickKey(keys["up"]!!,    ny < -STICK_DEAD)
    }

    /** Release all stick keys (called on ACTION_UP / CANCEL). */
    fun centreStick(isLeft: Boolean) {
        val keys = if (isLeft) leftStickKeys else rightStickKeys
        keys.values.forEach { setStickKey(it, false) }
    }

    /**
     * Legacy entry point — called from MyAutomationService.
     * With the IME approach there is no process to start; we just confirm
     * the IME service is attached and toast if it isn't.
     */
    fun verifyAndStart(ctx: Context) {
        if (!isAvailable) {
            android.widget.Toast.makeText(
                ctx,
                "Overlay IME not active — go to Settings → Keyboard and enable 'Overlay Controller'",
                android.widget.Toast.LENGTH_LONG
            ).show()
        }
    }

    /** No-op — IME lifecycle is managed by Android. */
    fun stop() {}

    // ── Internal helpers ───────────────────────────────────────────────────

    private fun pressKey(code: Int) {
        if (heldKeys.add(code)) svc?.injectDown(code)
    }

    private fun releaseKey(code: Int) {
        if (heldKeys.remove(code)) svc?.injectUp(code)
    }

    private fun setStickKey(code: Int, active: Boolean) {
        if (active) pressKey(code) else releaseKey(code)
    }
}

// ── GamepadManager alias — keeps FloatingOverlay call sites unchanged ──────
// FloatingOverlay calls GamepadManager.sendRefKey / sendStick / centreStick.
// This object simply forwards every call to ImeKeyboard so no other file
// needs to be touched.
object GamepadManager {
    fun sendRefKey(refKey: String, pressed: Boolean) = ImeKeyboard.sendRefKey(refKey, pressed)
    fun sendStick(isLeft: Boolean, nx: Float, ny: Float) = ImeKeyboard.sendStick(isLeft, nx, ny)
    fun centreStick(isLeft: Boolean) = ImeKeyboard.centreStick(isLeft)
    fun verifyAndStart(ctx: Context) = ImeKeyboard.verifyAndStart(ctx)
    fun stop() = ImeKeyboard.stop()
}
