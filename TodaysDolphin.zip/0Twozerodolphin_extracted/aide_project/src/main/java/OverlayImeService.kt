package com.home.automation

import android.inputmethodservice.InputMethodService
import android.view.KeyEvent
import android.view.View

/**
 * OverlayImeService — a zero-UI Input Method that lets the floating overlay
 * buttons inject real keyboard events into whatever window is in focus
 * (including Dolphin's game surface, which maps keyboard keys to controller
 * buttons via Settings → Controllers → Keyboard).
 *
 * SETUP (one-time, user side)
 * ───────────────────────────
 * 1. Settings → General Management → Keyboard list and default
 *    (or Settings → Language & Input → On-screen keyboard) → Add keyboard.
 * 2. Enable "Overlay Controller".
 * 3. Switch to it with the keyboard-globe icon, or set it as default.
 * 4. Launch Dolphin, open controller settings, set Profile to Keyboard,
 *    and map A/B/X/Y/Start etc. to the keys listed in ImeKeyboard.
 *
 * HOW IT WORKS
 * ─────────────
 * InputMethodService gives us sendDownUpKeyEvents() which dispatches a
 * real KeyEvent ACTION_DOWN + ACTION_UP to the current input target.
 * Android routes this to the focused window — in Dolphin's case, the
 * game surface — exactly as if the user had pressed a hardware key.
 *
 * For held buttons (shoulder triggers, d-pad held direction) we send
 * ACTION_DOWN on press and ACTION_UP on release via dispatchKeyDown /
 * dispatchKeyUp so the repeat-press behaviour is correct.
 *
 * ImeKeyboard (the singleton below) keeps the static `instance` reference
 * so FloatingOverlay can call ImeKeyboard.press() / release() without
 * needing a Context or service binding.
 */
class OverlayImeService : InputMethodService() {

    override fun onCreate() {
        super.onCreate()
        ImeKeyboard.bind(this)
    }

    override fun onDestroy() {
        ImeKeyboard.unbind(this)
        super.onDestroy()
    }

    /** No on-screen keyboard view — the floating overlay IS the UI. */
    override fun onCreateInputView(): View? = null

    // ── Package-private helpers called by ImeKeyboard ─────────────────────

    internal fun injectDown(keyCode: Int) {
        val ic = currentInputConnection ?: return
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
    }

    internal fun injectUp(keyCode: Int) {
        val ic = currentInputConnection ?: return
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
    }

    /** Single tap — sends DOWN then UP in one call (for momentary presses). */
    internal fun injectTap(keyCode: Int) = sendDownUpKeyEvents(keyCode)
}
