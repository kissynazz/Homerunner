package com.albatrossone

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.system.ErrnoException
import android.system.Os
import android.system.OsConstants
import android.view.Display
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

object ManualScreenCapture {

    private const val TEMP_FILE_NAME = "amanualScreen.jpeg"
    private const val READY_FILE_NAME = "amanualscreenFin.jpeg"
    private const val FRAME_INTERVAL_MS = 250L
    private const val SINGLE_CAPTURE_TIMEOUT_SECONDS = 10L

    private val captureThread = HandlerThread("ManualScreenCapture").apply { start() }
    private val captureHandler = Handler(captureThread.looper)
    private val callbackExecutor = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "ManualScreenCallback").apply { isDaemon = true }
    }

    @Volatile private var streaming = false
    @Volatile private var service: AccessibilityService? = null

    // ─── FILE WRITER FOR REVEALING INTERNAL ERRORS IN DCIM ───
    private fun logToFile(message: String) {
        try {
            val dcimDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), "Screenshots")
            if (!dcimDir.exists()) dcimDir.mkdirs()
            val logFile = File(dcimDir, "theoutput.txt")
            val timeStamp = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date())
            logFile.appendText("[$timeStamp] $message\n")
        } catch (_: Exception) {
            // Safe fallback if the phone storage locks completely
        }
    }

    fun captureOne(accessibilityService: AccessibilityService): String {
        logToFile("captureOne() was successfully triggered by your command loop!")
        
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            val err = "Error: Requires Android 11+ (API 30). Your device is lower."
            logToFile(err)
            return err
        }

        stopStream()
        service = accessibilityService

        val latch = CountDownLatch(1)
        var result = "Error: Screenshot timed out"
        
        requestScreenshot(accessibilityService,
            onSuccess = { bitmap ->
                logToFile("Success: Android OS handed over raw memory bits to callback.")
                result = saveBitmap(accessibilityService, bitmap)
                bitmap.recycle()
                latch.countDown()
            },
            onFailure = { errorCode ->
                val reason = when(errorCode) {
                    1 -> "INTERNAL_ERROR (Android graphics system failed to generate buffer)"
                    2 -> "NO_ACCESSIBILITY_ACCESS (Your profile XML is missing flagRequestAndModifyOnscreenContent!)"
                    3 -> "INTERVAL_TIME_SHORT (Commands are pounding the API too fast)"
                    else -> "Unknown framework drop code: $errorCode"
                }
                logToFile("CRITICAL FAILURE: takeScreenshot returned error code $errorCode -> $reason")
                result = "Error: Screenshot failed ($errorCode)"
                latch.countDown()
            }
        )

        try {
            if (!latch.await(SINGLE_CAPTURE_TIMEOUT_SECONDS, TimeUnit.SECONDS)) {
                logToFile("CRITICAL FAILURE: The OS screenshot callback timed out after 10s. Service might be dead or unbonded.")
            }
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
            return "Error: Screenshot interrupted"
        }
        return result
    }

    fun startStream(accessibilityService: AccessibilityService): String {
        service = accessibilityService
        if (streaming) return "Success: Stream already running"
        streaming = true
        logToFile("startStream() command caught. Launching persistent loop background runner.")
        captureHandler.post(object : Runnable {
            override fun run() {
                val svc = service
                if (!streaming || svc == null) return
                requestScreenshot(svc,
                    onSuccess = { bitmap ->
                        saveBitmap(svc, bitmap)
                        bitmap.recycle()
                        if (streaming) captureHandler.postDelayed(this, FRAME_INTERVAL_MS)
                    },
                    onFailure = { 
                        if (streaming) captureHandler.postDelayed(this, FRAME_INTERVAL_MS)
                    }
                )
            }
        })
        return "Success: Stream started"
    }

    fun stopStream() {
        streaming = false
        logToFile("stopStream() triggered. Loop halted.")
    }

    private fun requestScreenshot(
        accessibilityService: AccessibilityService,
        onSuccess: (Bitmap) -> Unit,
        onFailure: (Int) -> Unit
    ) {
        try {
            logToFile("Dispatching takeScreenshot call directly into Android framework...")
            accessibilityService.takeScreenshot(
                Display.DEFAULT_DISPLAY,
                callbackExecutor,
                object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                        val buffer = result.hardwareBuffer
                        try {
                            val hwBitmap = Bitmap.wrapHardwareBuffer(buffer, result.colorSpace)
                            val softwareBitmap = hwBitmap?.copy(Bitmap.Config.ARGB_8888, false)
                            hwBitmap?.recycle()
                            if (softwareBitmap == null) {
                                logToFile("Bitmap allocation copy returned null pointer.")
                                onFailure(-1)
                            } else {
                                onSuccess(softwareBitmap)
                            }
                        } catch (e: Exception) {
                            logToFile("Buffer translation mapping exception: ${e.message}")
                            onFailure(-1)
                        } finally {
                            buffer.close()
                        }
                    }
                    override fun onFailure(code: Int) = onFailure(code)
                }
            )
        } catch (e: Exception) {
            logToFile("Framework command execution crashed before dispatching: ${e.message}")
            onFailure(-1)
        }
    }

    private fun outputDirectory(): File {
        val directory = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "ManualScreen"
        )
        if (!directory.exists()) {
            val created = directory.mkdirs()
            logToFile("Attempting directory creation at Download/ManualScreen. Success profile: $created")
        }
        return directory
    }

    private fun saveBitmap(accessibilityService: AccessibilityService, bitmap: Bitmap): String {
        val directory = outputDirectory()
        val temporary = File(directory, TEMP_FILE_NAME)
        val ready = File(directory, READY_FILE_NAME)
        
        return try {
            val compressed = FileOutputStream(temporary).use { output ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, output)
            }
            
            if (!compressed) {
                logToFile("JPEG Compression utility returned false.")
                "Error: Compression failed"
            } else {
                if (ready.exists()) ready.delete()
                
                try {
                    Os.rename(temporary.absolutePath, ready.absolutePath)
                    logToFile("Image written and atomically shifted to final destination file!")
                } catch (e: ErrnoException) {
                    if (e.errno == OsConstants.EXDEV) {
                        logToFile("EXDEV storage cross-link profile partition detected. Processing copy block fallback.")
                        temporary.copyTo(ready, overwrite = true)
                        temporary.delete()
                    } else {
                        throw e
                    }
                }

                android.media.MediaScannerConnection.scanFile(
                    accessibilityService, arrayOf(ready.absolutePath), arrayOf("image/jpeg"), null
                )
                "Success: Saved to ${ready.absolutePath}"
            }
        } catch (e: Exception) {
            logToFile("Disk file IO stream failed completely: ${e.message}")
            "Error: ${e.localizedMessage}"
        }
    }
}
