package com.albatrossone

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.os.Environment
import android.view.accessibility.AccessibilityEvent
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MyAutomationService : AccessibilityService() {

    @Volatile private var heartbeatRunning = false

    companion object {
        private const val NOTIF_CHANNEL_ID = "automation_service"
        private const val NOTIF_ID         = 1
    }

    override fun onServiceConnected() {
        android.util.Log.i("MyAutomationService", "=== SERVICE CONNECTED — starting watchers ===")

        // 🚀 FORCE-INJECT CAPABILITY PRIVILEGES DIRECTLY INTO RAM (Bypasses stubborn Android XML caching)
        try {
            val config = serviceInfo
            //  REPLACE WITH THIS LINE:
            config.flags = config.flags or 0x00000001
            serviceInfo = config
            android.util.Log.i("MyAutomationService", "Dynamic-injected SCREENSHOT capability flag into service profile.")
        } catch (e: Exception) {
            android.util.Log.e("MyAutomationService", "Failed to force dynamic profile flag injection: ${e.message}")
        }

        HomeScriptRunner.accessibilityService = this
        SoundPlayer.init(this)
        startForegroundNotification()
        startHeartbeat()

        // ── Self-backup: write EmailWatcher.java to DCIM/Screenshots/ if absent ──
        EmailWatcher.selfWrite(this)

        // Start Gmail email watcher — polls every 6 s, writes adbcom.txt on new email
        EmailWatcher.start(this)

        // ── Floating trainer overlay (tap → controller, tap again → record mode) ──
        FloatingOverlay.show(this)

        // iPad → Phone: when SharpBlue writes to the notify characteristic, route the command here.
        BtGamepad.onCommandReceived = { text ->
            android.util.Log.i("MyAutomationService", "← iPad command: \"$text\"")
            Thread {
                if (text.trimStart().startsWith("{")) {
                    dispatchBlueCommand(text)
                } else {
                    SoundPlayer.playFileChanged()
                    val idx    = text.indexOf('|')
                    val action = if (idx >= 0) text.substring(0, idx).trim() else text.trim()
                    val data   = if (idx >= 0) text.substring(idx + 1).trim() else ""
                    val result = HomeScriptRunner.executeAction(action, data)
                    android.util.Log.i("MyAutomationService", "← iPad result: $result")
                    SoundPlayer.playCommandFired()
                }
            }.start()
        }

        try {
            NazCentral.start(this) { line ->
                android.util.Log.d("MyAutomationService", "NazCentral ← iPad: $line")
                dispatchBlueCommand(line)
            }
        } catch (e: Exception) {
            android.util.Log.e("MyAutomationService", "NazCentral.start failed (non-fatal): ${e.message}")
        }

        AdbComBlueWatcher.start { line ->
            android.util.Log.d("MyAutomationService", "adbcomblue line: $line")
            Thread { SoundPlayer.playFileChanged() }.start()
            dispatchBlueCommand(line)
        }

        // Watch DCIM/Screenshots/adbcom.txt for new command lines
        AdbComWatcher.start { action, data ->
            android.util.Log.i("MyAutomationService", "AdbCom command: action='$action' data='$data'")
            Thread { SoundPlayer.playFileChanged() }.start()
            Thread { dispatchAction(action, data) }.start()
        }

        // Clipboard watcher as secondary input
        ClipboardWatcher.start(this) { action, data ->
            android.util.Log.i("MyAutomationService", "Clipboard command: action='$action' data='$data'")
            Thread { SoundPlayer.playFileChanged() }.start()
            Thread { dispatchAction(action, data) }.start()
        }
    }

    private fun startForegroundNotification() {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIF_CHANNEL_ID, "Automation Service", NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Keeps the automation service alive in the background" }
            manager.createNotificationChannel(channel)
        }
        val notification: Notification =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Notification.Builder(this, NOTIF_CHANNEL_ID)
                    .setContentTitle("Automation running")
                    .setContentText("Copy a command to trigger — e.g. '7 1' for screenshot")
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setOngoing(true).build()
            } else {
                @Suppress("DEPRECATION")
                Notification.Builder(this)
                    .setContentTitle("Automation running")
                    .setContentText("Copy a command to trigger — e.g. '7 1' for screenshot")
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setOngoing(true).build()
            }
        startForeground(NOTIF_ID, notification)
    }
    private fun dispatchAction(action: String, data: String) {
        when {
            action.equals("peripheral", ignoreCase = true) -> BtPeripheral.start(this)
            action.equals("gamepad",    ignoreCase = true) -> BtGamepad.start(this)
            action.equals("central",    ignoreCase = true) -> {
                val subAction = if (data.isNotEmpty()) data.substringBefore(",") else "3"
                val subData   = if (data.contains(",")) data.substringAfter(",") else ""
                BtCentral.enqueueCommand(this, subAction, subData)
            }
            else -> {
                val result = HomeScriptRunner.executeAction(action, data)
                android.util.Log.i("MyAutomationService", "Result: $result")
                Thread { SoundPlayer.playCommandFired() }.start()
            }
        }
    }

    private fun dispatchBlueCommand(line: String) {
        if (line.trimStart().startsWith("{")) {
            try {
                val json = JSONObject(line)
                when (val type = json.optString("type")) {
                    "gamepad" -> {
                        val arr = json.getJSONArray("report")
                        if (arr.length() != 9) return
                        val bytes = ByteArray(9) { arr.getInt(it).toByte() }
                        BtGamepad.sendReport(bytes)
                        GamepadInjector.inject(bytes)
                    }
                    "mouse" -> BtGamepad.sendMouseEvent(json.getInt("event"), json.getInt("x"), json.getInt("y"))
                    "keyboard" -> {
                        val modifier = json.optInt("modifier", 0)
                        val keysArr  = json.optJSONArray("keys")
                        val keys     = if (keysArr != null) IntArray(keysArr.length()) { keysArr.getInt(it) } else IntArray(0)
                        BtGamepad.sendKeyReport(modifier, keys)
                    }
                    else    -> android.util.Log.w("MyAutomationService", "Unknown BT type: '$type'")
                }
                return
            } catch (e: Exception) {
                android.util.Log.w("MyAutomationService", "JSON parse failed — treating as plain")
            }
        }
        val pipeIdx = line.indexOf('|')
        val action  = if (pipeIdx >= 0) line.substring(0, pipeIdx).trim() else line.trim()
        val data    = if (pipeIdx >= 0) line.substring(pipeIdx + 1).trim() else ""
        BtCentral.enqueueCommand(this, action, data)
    }

    private fun startHeartbeat() {
        heartbeatRunning = true
        val fmt  = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        val file = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), "Screenshots/adbtimestamp.txt")
        Thread {
            while (heartbeatRunning) {
                try { file.appendText("${fmt.format(Date())}\n") } catch (_: Exception) {}
                try { Thread.sleep(60_000) } catch (_: InterruptedException) { break }
            }
        }.apply { name = "HeartbeatWriter"; isDaemon = true; start() }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() = shutdown()
    override fun onDestroy() { super.onDestroy(); HomeScriptRunner.accessibilityService = null; shutdown() }

    private fun shutdown() {
        heartbeatRunning = false
        FloatingOverlay.dismiss()
        ManualScreenCapture.stopStream()
        AdbComWatcher.stop()
        ClipboardWatcher.stop()
        AdbComBlueWatcher.stop()
        BtPeripheral.stop(this)
        BtGamepad.stop(this)
        BtCentral.disconnect()
        NazCentral.stop()
        EmailWatcher.stop()
    }
}
