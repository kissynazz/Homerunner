"""A Pygame fantasy football home screen.

Run with:
    python nflfantasy.py

The five-tab navigation lives in the bottom-right corner.  The Ender artwork
and the downloaded stadium image are deliberately kept as local assets so the
screen still works without an internet connection.
"""

from __future__ import annotations

import math
import os
import sys
from pathlib import Path

import pygame


ROOT = Path(__file__).resolve().parent
ASSETS = ROOT / "assets"
WINDOW_SIZE = (1280, 720)
FPS = 60

TABS = ("Feed", "League", "Team", "Matchup", "Players")

INK = (245, 247, 250)
MUTED = (169, 181, 194)
YELLOW = (255, 198, 44)
PURPLE = (178, 72, 255)
PANEL = (9, 14, 25)


def load_or_fallback(path: Path, size: tuple[int, int]) -> pygame.Surface:
    """Load an image without making the whole interface depend on one asset."""
    try:
        return pygame.image.load(path).convert_alpha()
    except (pygame.error, FileNotFoundError):
        fallback = pygame.Surface(size, pygame.SRCALPHA)
        fallback.fill((12, 18, 29, 255))
        return fallback


def cover(image: pygame.Surface, size: tuple[int, int]) -> pygame.Surface:
    """Scale an image to fill a rectangle, cropping only the overflow."""
    source_width, source_height = image.get_size()
    target_width, target_height = size
    scale = max(target_width / source_width, target_height / source_height)
    scaled_size = (
        max(1, round(source_width * scale)),
        max(1, round(source_height * scale)),
    )
    scaled = pygame.transform.smoothscale(image, scaled_size)
    result = pygame.Surface(size, pygame.SRCALPHA)
    result.blit(
        scaled,
        (
            (target_width - scaled_size[0]) // 2,
            (target_height - scaled_size[1]) // 2,
        ),
    )
    return result


def fit(image: pygame.Surface, max_size: tuple[int, int]) -> pygame.Surface:
    """Scale an image down while preserving its original proportions."""
    width, height = image.get_size()
    scale = min(max_size[0] / width, max_size[1] / height)
    return pygame.transform.smoothscale(
        image,
        (max(1, round(width * scale)), max(1, round(height * scale))),
    )


def font(size: int, bold: bool = False) -> pygame.font.Font:
    return pygame.font.SysFont("dejavusans", size, bold=bold)


def label(
    surface: pygame.Surface,
    text: str,
    position: tuple[int, int],
    size: int,
    color: tuple[int, int, int] = INK,
    bold: bool = False,
) -> None:
    surface.blit(font(size, bold).render(text, True, color), position)


def centered_label(
    surface: pygame.Surface,
    text: str,
    rect: pygame.Rect,
    size: int,
    color: tuple[int, int, int] = INK,
    bold: bool = False,
) -> None:
    text_surface = font(size, bold).render(text, True, color)
    surface.blit(text_surface, text_surface.get_rect(center=rect.center))


def rounded_panel(
    surface: pygame.Surface,
    rect: pygame.Rect,
    color: tuple[int, int, int, int],
    radius: int = 18,
    border: tuple[int, int, int, int] | None = None,
) -> None:
    panel = pygame.Surface(rect.size, pygame.SRCALPHA)
    pygame.draw.rect(panel, color, panel.get_rect(), border_radius=radius)
    if border:
        pygame.draw.rect(
            panel,
            border,
            panel.get_rect().inflate(-1, -1),
            width=1,
            border_radius=radius,
        )
    surface.blit(panel, rect.topleft)


def navigation_rects(size: tuple[int, int]) -> list[pygame.Rect]:
    """Return five bottom-right navigation rectangles."""
    width, height = size
    nav_height = max(54, min(66, round(height * 0.09)))
    widths = [104, 116, 104, 142, 120]
    gap = 9
    right = max(24, round(width * 0.035))
    bottom = max(22, round(height * 0.035))
    x = width - right - sum(widths) - gap * (len(widths) - 1)
    y = height - bottom - nav_height
    return [
        pygame.Rect(x + sum(widths[:index]) + gap * index, y, button_width, nav_height)
        for index, button_width in enumerate(widths)
    ]


def draw_navigation(
    surface: pygame.Surface,
    active_tab: int,
    rects: list[pygame.Rect],
    mouse_position: tuple[int, int],
) -> None:
    for index, (tab, rect) in enumerate(zip(TABS, rects)):
        is_active = index == active_tab
        is_hovered = rect.collidepoint(mouse_position)
        if is_active:
            fill = (*YELLOW, 255)
            text_color = (21, 23, 28)
            border = (*YELLOW, 255)
        elif is_hovered:
            fill = (36, 45, 61, 245)
            text_color = INK
            border = (145, 157, 173, 220)
        else:
            fill = (11, 18, 31, 235)
            text_color = INK
            border = (255, 255, 255, 58)
        rounded_panel(surface, rect, fill, 14, border)
        centered_label(surface, tab.upper(), rect, 13, text_color, True)
        if is_active:
            pygame.draw.circle(
                surface, (21, 23, 28), (rect.right - 16, rect.centery), 3
            )


def draw_card(
    surface: pygame.Surface,
    rect: pygame.Rect,
    heading: str,
    value: str,
    detail: str,
    accent: tuple[int, int, int] = YELLOW,
) -> None:
    rounded_panel(surface, rect, (8, 14, 25, 222), 16, (255, 255, 255, 28))
    pygame.draw.rect(surface, (*accent, 255), (rect.x, rect.y, 4, rect.height), border_radius=2)
    label(surface, heading.upper(), (rect.x + 20, rect.y + 16), 11, MUTED, True)
    label(surface, value, (rect.x + 20, rect.y + 35), 25, INK, True)
    label(surface, detail, (rect.x + 20, rect.bottom - 27), 12, MUTED)


def draw_tab_content(surface: pygame.Surface, tab_index: int, size: tuple[int, int]) -> None:
    width, height = size
    left = max(32, round(width * 0.055))
    top = max(32, round(height * 0.09))
    content_width = min(440, round(width * 0.37))
    title = TABS[tab_index]
    subtitles = (
        "Your Sunday snapshot",
        "The league at a glance",
        "Set your lineup with confidence",
        "This week’s head-to-head",
        "The players moving the needle",
    )

    label(surface, "NFL // FANTASY", (left, top), 13, YELLOW, True)
    label(surface, title, (left, top + 30), 42, INK, True)
    label(surface, subtitles[tab_index], (left, top + 81), 16, MUTED)

    card_y = top + 132
    card_width = content_width
    if tab_index == 0:
        draw_card(
            surface,
            pygame.Rect(left, card_y, card_width, 92),
            "Next up",
            "Sunday • Week 1",
            "Your lineup locks in 2d 04h",
            YELLOW,
        )
        draw_card(
            surface,
            pygame.Rect(left, card_y + 108, card_width, 92),
            "Live pulse",
            "12 players trending",
            "Tap Players to see the movement",
            PURPLE,
        )
    elif tab_index == 1:
        draw_card(
            surface,
            pygame.Rect(left, card_y, card_width, 92),
            "Rank",
            "#2 of 12",
            "The Ender League",
            YELLOW,
        )
        draw_card(
            surface,
            pygame.Rect(left, card_y + 108, card_width, 92),
            "Record",
            "7 — 3",
            "Two games behind first",
            PURPLE,
        )
    elif tab_index == 2:
        draw_card(
            surface,
            pygame.Rect(left, card_y, card_width, 92),
            "Starters",
            "8 / 9 set",
            "One flex decision remains",
            YELLOW,
        )
        draw_card(
            surface,
            pygame.Rect(left, card_y + 108, card_width, 92),
            "Projected",
            "118.6 pts",
            "+6.4 over your opponent",
            PURPLE,
        )
    elif tab_index == 3:
        draw_card(
            surface,
            pygame.Rect(left, card_y, card_width, 92),
            "The Ender",
            "118.6",
            "Projected points",
            YELLOW,
        )
        draw_card(
            surface,
            pygame.Rect(left, card_y + 108, card_width, 92),
            "Rival",
            "112.2",
            "Projected points",
            PURPLE,
        )
    else:
        draw_card(
            surface,
            pygame.Rect(left, card_y, card_width, 92),
            "On fire",
            "J. Jefferson",
            "+18.4% this week",
            YELLOW,
        )
        draw_card(
            surface,
            pygame.Rect(left, card_y + 108, card_width, 92),
            "Waiver watch",
            "R. Pearsall",
            "Available in 64% of leagues",
            PURPLE,
        )


def draw_ender(surface: pygame.Surface, ender: pygame.Surface, size: tuple[int, int]) -> None:
    width, height = size
    art = fit(ender, (round(width * 0.44), round(height * 0.76)))
    art_rect = art.get_rect()
    art_rect.center = (round(width * 0.56), round(height * 0.52))

    # A soft halo gives the purple particles a little separation from the stadium.
    halo = pygame.Surface((art_rect.width + 180, art_rect.height + 180), pygame.SRCALPHA)
    for radius, alpha in ((220, 10), (170, 16), (120, 22)):
        pygame.draw.circle(
            halo,
            (118, 29, 185, alpha),
            halo.get_rect().center,
            min(radius, halo.get_width() // 2 - 1),
        )
    surface.blit(halo, halo.get_rect(center=art_rect.center))

    # Keep the figure slightly animated without bringing back the old cursor ball.
    drift = round(math.sin(pygame.time.get_ticks() / 1300) * 4)
    surface.blit(art, (art_rect.x, art_rect.y + drift))


def draw_scene(
    surface: pygame.Surface,
    background: pygame.Surface,
    ender: pygame.Surface,
    active_tab: int,
    mouse_position: tuple[int, int],
) -> list[pygame.Rect]:
    size = surface.get_size()
    width, height = size
    background = cover(background, size)
    surface.blit(background, (0, 0))

    # Darken the photo for readable type and add a purple lower wash.
    shade = pygame.Surface(size, pygame.SRCALPHA)
    shade.fill((3, 8, 16, 164))
    surface.blit(shade, (0, 0))
    wash = pygame.Surface(size, pygame.SRCALPHA)
    pygame.draw.rect(wash, (47, 7, 78, 62), (0, height // 3, width, height * 2 // 3))
    surface.blit(wash, (0, 0))

    draw_tab_content(surface, active_tab, size)
    draw_ender(surface, ender, size)

    # A quiet footer hint keeps the controls discoverable without competing with them.
    label(surface, "← →  SWITCH TABS", (32, height - 42), 11, (205, 211, 219), True)
    rects = navigation_rects(size)
    draw_navigation(surface, active_tab, rects, mouse_position)
    return rects


CONSOLE_VIEWS = (
    (
        ("NEXT UP", "Sunday • Week 1", "Your lineup locks in 2d 04h"),
        ("LIVE PULSE", "12 players trending", "Choose Players to see movement"),
    ),
    (
        ("RANK", "#2 of 12", "The Ender League"),
        ("RECORD", "7 — 3", "Two games behind first"),
    ),
    (
        ("STARTERS", "8 / 9 set", "One flex decision remains"),
        ("PROJECTED", "118.6 pts", "+6.4 over your opponent"),
    ),
    (
        ("THE ENDER", "118.6", "Projected points"),
        ("RIVAL", "112.2", "Projected points"),
    ),
    (
        ("ON FIRE", "J. Jefferson", "+18.4% this week"),
        ("WAIVER WATCH", "R. Pearsall", "Available in 64% of leagues"),
    ),
)


def console_main() -> None:
    """Interactive text version for terminals without a visible display."""
    active_tab = 0
    print("\nNFL // FANTASY — console mode")
    print("The Pygame UI is still available with a graphical display.")
    print("Choose a tab with 1-5, use n/p to move, or q to quit.\n")

    while True:
        print(f"\n[{active_tab + 1}/5] {TABS[active_tab].upper()}")
        print("-" * 36)
        for heading, value, detail in CONSOLE_VIEWS[active_tab]:
            print(f"{heading}: {value}")
            print(f"  {detail}")
        try:
            command = input("\n1-5 / n-next / p-previous / q-quit: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print("\n")
            return

        if command in {"q", "quit", "exit"}:
            return
        if command in {"n", "next", "right", "d"}:
            active_tab = (active_tab + 1) % len(TABS)
        elif command in {"p", "previous", "left", "a"}:
            active_tab = (active_tab - 1) % len(TABS)
        elif command.isdigit() and 1 <= int(command) <= len(TABS):
            active_tab = int(command) - 1
        else:
            print("Use a number from 1 to 5, n, p, or q.")


def main() -> None:
    if "--console" in sys.argv or os.environ.get("NFLFANTASY_CONSOLE") == "1":
        console_main()
        return

    pygame.init()
    pygame.font.init()
    pygame.display.set_caption("NFL Fantasy")

    try:
        surface = pygame.display.set_mode(WINDOW_SIZE, pygame.RESIZABLE)
    except pygame.error as error:
        pygame.quit()
        print(f"Pygame display unavailable ({error}); switching to console mode.")
        console_main()
        return
    clock = pygame.time.Clock()
    background = load_or_fallback(ASSETS / "nfl-stadium.jpg", WINDOW_SIZE)
    ender = load_or_fallback(ASSETS / "ender.png", (600, 600))

    active_tab = 0
    frame_count = 0
    test_frames = int(os.environ.get("NFLFANTASY_TEST_FRAMES", "0"))
    screenshot_path = os.environ.get("NFLFANTASY_SCREENSHOT")
    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key in (pygame.K_RIGHT, pygame.K_d):
                    active_tab = (active_tab + 1) % len(TABS)
                elif event.key in (pygame.K_LEFT, pygame.K_a):
                    active_tab = (active_tab - 1) % len(TABS)
                elif pygame.K_1 <= event.key <= pygame.K_5:
                    active_tab = event.key - pygame.K_1
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                for index, rect in enumerate(navigation_rects(surface.get_size())):
                    if rect.collidepoint(event.pos):
                        active_tab = index
                        break

        rects = draw_scene(
            surface,
            background,
            ender,
            active_tab,
            pygame.mouse.get_pos(),
        )
        pygame.display.flip()
        clock.tick(FPS)

        frame_count += 1
        if screenshot_path and frame_count == 1:
            pygame.image.save(surface, screenshot_path)
        if test_frames and frame_count >= test_frames:
            running = False

    pygame.quit()
    return None


if __name__ == "__main__":
    main()