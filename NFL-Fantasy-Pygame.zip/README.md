# NFL Fantasy Pygame

This is a Python/Pygame fantasy football interface with:

- Five bottom-right tabs: Feed, League, Team, Matchup, and Players.
- Yellow active-tab styling.
- Ender artwork and a local NFL stadium background.
- Keyboard navigation in the Pygame window.
- An interactive terminal fallback for environments without a visible display.

## Run the Pygame interface

```bash
python main.py
```

## Run the interactive console

```bash
python main.py --console
```

Console controls:

- `1`–`5`: choose a tab
- `n` or `d`: next tab
- `p` or `a`: previous tab
- `q`: quit

Pygame is installed through `pyproject.toml`. If your Python environment does
not install project dependencies automatically, run:

```bash
pip install pygame
```