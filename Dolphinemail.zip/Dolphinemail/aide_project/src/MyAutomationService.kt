package com.home.automation

import android.accessibilityservice.AccessibilityService
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.os.Environment
import android.view.accessibility.AccessibilityEvent
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MyAutomationService : AccessibilityService() {

    @Volatile private var heartbeatRunning = false

    companion object {
        private const val NOTIF_CHANNEL_ID = "automation_service"
        private const val NOTIF_ID         = 1
    }

    override fun onServiceConnected() {
        android.util.Log.i("MyAutomationService", "=== SERVICE CONNECTED — starting watchers ===")

        HomeScriptRunner.accessibilityService = this
        startForegroundNotification()
        startHeartbeat()

        AdbComBlueWatcher.start { line ->
            android.util.Log.d("MyAutomationService", "adbcomblue line: $line")
            Thread { SoundPlayer.playFileChanged() }.start()
            dispatchBlueCommand(line)
        }

        // Copy clipboard commands from any app to trigger actions:
        //   "7 1"            → screenshot
        //   "3 2"            → home
        //   "tap 540 1000 3" → tap at (540,1000)
        //   Seq must increase each time: 7 1 → 7 2 → 7 3 …
        ClipboardWatcher.start(this) { action, data ->
            android.util.Log.i("MyAutomationService", "Clipboard command: action='$action' data='$data'")
            Thread { SoundPlayer.playFileChanged() }.start()
            Thread { dispatchAction(action, data) }.start()
        }
    }

    private fun startForegroundNotification() {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIF_CHANNEL_ID, "Automation Service", NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Keeps the automation service alive in the background" }
            manager.createNotificationChannel(channel)
        }
        val notification: Notification =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Notification.Builder(this, NOTIF_CHANNEL_ID)
                    .setContentTitle("Automation running")
                    .setContentText("Copy a command to trigger — e.g. '7 1' for screenshot")
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setOngoing(true).build()
            } else {
                @Suppress("DEPRECATION")
                Notification.Builder(this)
                    .setContentTitle("Automation running")
                    .setContentText("Copy a command to trigger — e.g. '7 1' for screenshot")
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setOngoing(true).build()
            }
        startForeground(NOTIF_ID, notification)
    }

    private fun dispatchAction(action: String, data: String) {
        when {
            action.equals("peripheral", ignoreCase = true) -> BtPeripheral.start(this)
            action.equals("gamepad",    ignoreCase = true) -> BtGamepad.start(this)
            action.equals("central",    ignoreCase = true) -> {
                val subAction = if (data.isNotEmpty()) data.substringBefore(",") else "3"
                val subData   = if (data.contains(",")) data.substringAfter(",") else ""
                BtCentral.enqueueCommand(this, subAction, subData)
            }
            else -> {
                val result = HomeScriptRunner.executeAction(action, data)
                android.util.Log.i("MyAutomationService", "Result: $result")
                Thread { SoundPlayer.playCommandFired() }.start()
            }
        }
    }

    private fun dispatchBlueCommand(line: String) {
        if (line.trimStart().startsWith("{")) {
            try {
                val json = JSONObject(line)
                when (val type = json.optString("type")) {
                    "gamepad" -> {
                        val arr = json.getJSONArray("report")
                        if (arr.length() != 9) return
                        BtGamepad.sendReport(ByteArray(9) { arr.getInt(it).toByte() })
                    }
                    "mouse" -> BtGamepad.sendMouseEvent(json.getInt("event"), json.getInt("x"), json.getInt("y"))
                    else    -> android.util.Log.w("MyAutomationService", "Unknown BT type: '$type'")
                }
                return
            } catch (e: Exception) {
                android.util.Log.w("MyAutomationService", "JSON parse failed — treating as plain")
            }
        }
        val pipeIdx = line.indexOf('|')
        val action  = if (pipeIdx >= 0) line.substring(0, pipeIdx).trim() else line.trim()
        val data    = if (pipeIdx >= 0) line.substring(pipeIdx + 1).trim() else ""
        BtCentral.enqueueCommand(this, action, data)
    }

    private fun startHeartbeat() {
        heartbeatRunning = true
        val fmt  = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        val file = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), "Screenshots/adbtimestamp.txt")
        Thread {
            while (heartbeatRunning) {
                try { file.appendText("${fmt.format(Date())}\n") } catch (_: Exception) {}
                try { Thread.sleep(60_000) } catch (_: InterruptedException) { break }
            }
        }.apply { name = "HeartbeatWriter"; isDaemon = true; start() }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() = shutdown()
    override fun onDestroy() { super.onDestroy(); HomeScriptRunner.accessibilityService = null; shutdown() }

    private fun shutdown() {
        heartbeatRunning = false
        ClipboardWatcher.stop()
        AdbComBlueWatcher.stop()
        BtPeripheral.stop(this)
        BtGamepad.stop(this)
        BtCentral.disconnect()
    }
}
