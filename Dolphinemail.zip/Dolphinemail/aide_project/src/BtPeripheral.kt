package com.home.automation

import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.os.ParcelUuid

object BtPeripheral {

    private var gattServer: BluetoothGattServer? = null
    private var advertiseCallback: AdvertiseCallback? = null
    private val connectedDevices = mutableListOf<BluetoothDevice>()

    fun start(context: Context) {
        val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter = manager.adapter ?: run { android.util.Log.e("BtPeripheral", "Bluetooth not available"); return }
        if (!adapter.isEnabled) { android.util.Log.e("BtPeripheral", "Bluetooth is off"); return }

        val commandChar = BluetoothGattCharacteristic(BtSharedConfig.COMMAND_CHAR_UUID,
            BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE,
            BluetoothGattCharacteristic.PERMISSION_WRITE)

        val resultChar = BluetoothGattCharacteristic(BtSharedConfig.RESULT_CHAR_UUID,
            BluetoothGattCharacteristic.PROPERTY_READ or BluetoothGattCharacteristic.PROPERTY_NOTIFY,
            BluetoothGattCharacteristic.PERMISSION_READ).also {
            it.addDescriptor(BluetoothGattDescriptor(BtSharedConfig.NOTIFY_DESC_UUID,
                BluetoothGattDescriptor.PERMISSION_READ or BluetoothGattDescriptor.PERMISSION_WRITE))
        }

        val service = BluetoothGattService(BtSharedConfig.SERVICE_UUID, BluetoothGattService.SERVICE_TYPE_PRIMARY)
            .also { it.addCharacteristic(commandChar); it.addCharacteristic(resultChar) }

        gattServer = manager.openGattServer(context, object : BluetoothGattServerCallback() {
            override fun onConnectionStateChange(device: BluetoothDevice, status: Int, newState: Int) {
                when (newState) {
                    BluetoothProfile.STATE_CONNECTED    -> connectedDevices.add(device)
                    BluetoothProfile.STATE_DISCONNECTED -> connectedDevices.remove(device)
                }
            }
            override fun onCharacteristicWriteRequest(device: BluetoothDevice, requestId: Int, characteristic: BluetoothGattCharacteristic, preparedWrite: Boolean, responseNeeded: Boolean, offset: Int, value: ByteArray) {
                if (characteristic.uuid != BtSharedConfig.COMMAND_CHAR_UUID) return
                if (responseNeeded) gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, 0, null)
                val (action, data) = BtSharedConfig.decodeCommand(value)
                Thread {
                    SoundPlayer.playFileChanged()
                    val result = HomeScriptRunner.executeAction(action, data)
                    SoundPlayer.playCommandFired()
                    resultChar.value = result.toByteArray(Charsets.UTF_8)
                    connectedDevices.forEach { gattServer?.notifyCharacteristicChanged(it, resultChar, false) }
                }.start()
            }
            override fun onDescriptorWriteRequest(device: BluetoothDevice, requestId: Int, descriptor: BluetoothGattDescriptor, preparedWrite: Boolean, responseNeeded: Boolean, offset: Int, value: ByteArray) {
                descriptor.value = value
                if (responseNeeded) gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, 0, null)
            }
        })
        gattServer?.addService(service)

        val settings = AdvertiseSettings.Builder().setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY).setConnectable(true).setTimeout(0).build()
        val data = AdvertiseData.Builder().addServiceUuid(ParcelUuid(BtSharedConfig.SERVICE_UUID)).setIncludeDeviceName(true).build()
        advertiseCallback = object : AdvertiseCallback() {
            override fun onStartSuccess(s: AdvertiseSettings?) {
                android.util.Log.d("BtPeripheral", "Advertising started")
            }

            override fun onStartFailure(errorCode: Int) {
                android.util.Log.e("BtPeripheral", "Advertising failed: $errorCode")
            }
        }

        adapter.bluetoothLeAdvertiser?.startAdvertising(settings, data, advertiseCallback)
            ?: android.util.Log.e("BtPeripheral", "LE advertising not supported")
    }

    fun stop(context: Context) {
        val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        advertiseCallback?.let { manager.adapter?.bluetoothLeAdvertiser?.stopAdvertising(it) }
        gattServer?.close(); gattServer = null; connectedDevices.clear()
    }
}
