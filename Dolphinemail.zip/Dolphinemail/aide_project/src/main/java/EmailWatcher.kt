package com.home.automation

import android.content.Context
import android.os.Environment
import android.util.Log
import javax.mail.Folder
import javax.mail.Part
import javax.mail.Session
import javax.mail.Store
import javax.mail.UIDFolder
import javax.mail.internet.MimeMultipart
import javax.mail.search.FromStringTerm
import java.io.BufferedReader
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileReader
import java.io.FileWriter
import java.io.IOException
import java.io.InputStream
import java.util.Properties

/**
 * EmailWatcher — Android background thread (Kotlin object).
 *
 * Polls Gmail (IMAP SSL) every 6 s for the newest email FROM the configured
 * address (self-send).  When a NEW email arrives (tracked by UID) it:
 *   1. Extracts the raw body (plain-text preferred, HTML fallback).
 *   2. Strips HTML tags / decodes entities so the body looks like plain text.
 *   3. Mirrors the Python startadd loop: collect between first '$' and '@'/'/'.
 *   4. Trims mha at the first '#'  →  mh2.
 *   5. Parses ugly=[...] command string and writes to DCIM/Screenshots/adbcom.txt.
 *
 * Key fixes vs. earlier version:
 *   - mail.imaps.ssl.trust=*  prevents Android SSL handshake failures (silent crash).
 *   - UID is recorded only AFTER successful processing (no silent drops).
 *   - HTML entities decoded + tags stripped before extractMha so &#39; → '  and
 *     <br> → \n, preserving correct parsing when Gmail returns an HTML part.
 *   - Fallback: if FROM search returns 0 results, tries fetching ALL inbox msgs.
 */
object EmailWatcher {

    private const val TAG       = "EmailWatcher"
    private const val USER      = "nazzyburpee0@gmail.com"
    private const val PASSWORD  = "qntc kxxr wybp bdng"
    private const val IMAP_HOST = "imap.gmail.com"
    private const val POLL_MS   = 6000L

    @Volatile private var lastProcessedUid = -1L
    @Volatile private var seq              = 0
    @Volatile private var running          = false
    private  var watcherThread: Thread?    = null
    private  var adbcomPath:  String?      = null
    private  var lastseqPath: String?      = null

    // ═══════════════════════════════════════════════════════════════
    //  Lifecycle
    // ═══════════════════════════════════════════════════════════════

    @Synchronized
    fun start(context: Context) {
        if (running) {
            Log.i(TAG, "Already running — ignoring duplicate start()")
            return
        }
        val screenshots = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
            "Screenshots"
        )
        screenshots.mkdirs()
        adbcomPath  = File(screenshots, "adbcom.txt").absolutePath
        lastseqPath = File(screenshots, "lastseq.txt").absolutePath
        seq = readSeq()
        Log.i(TAG, "=== STARTING — seq=$seq  adbcom=$adbcomPath ===")
        running = true

        watcherThread = Thread({
            while (running && !Thread.currentThread().isInterrupted) {
                try {
                    poll()
                } catch (e: Exception) {
                    Log.e(TAG, "poll error: ${e.javaClass.simpleName}: ${e.message}")
                }
                try {
                    Thread.sleep(POLL_MS)
                } catch (ex: InterruptedException) {
                    Thread.currentThread().interrupt()
                    break
                }
            }
            Log.i(TAG, "Stopped.")
        }, "EmailWatcher")
        watcherThread!!.isDaemon = true
        watcherThread!!.start()
    }

    @Synchronized
    fun stop() {
        running = false
        watcherThread?.interrupt()
        watcherThread = null
        Log.i(TAG, "stop() called.")
    }

    // ═══════════════════════════════════════════════════════════════
    //  Core poll
    // ═══════════════════════════════════════════════════════════════

    private fun poll() {
        val props = Properties()
        props["mail.store.protocol"]             = "imaps"
        props["mail.imaps.host"]                 = IMAP_HOST
        props["mail.imaps.port"]                 = "993"
        props["mail.imaps.ssl.enable"]           = "true"
        // ── FIX 1: trust Gmail's SSL cert on Android ──────────────────────
        props["mail.imaps.ssl.trust"]            = "*"
        props["mail.imaps.ssl.checkserveridentity"] = "false"
        props["mail.imaps.connectiontimeout"]    = "15000"
        props["mail.imaps.timeout"]              = "15000"

        val session = Session.getInstance(props)
        var store: Store?  = null
        var inbox: Folder? = null
        try {
            store = session.getStore("imaps")
            store.connect(IMAP_HOST, USER, PASSWORD)
            inbox = store.getFolder("INBOX")
            inbox.open(Folder.READ_ONLY)

            // ── Search FROM self, fallback to ALL ─────────────────────────
            var msgs = inbox.search(FromStringTerm(USER))
            if (msgs == null || msgs.isEmpty()) {
                Log.d(TAG, "FROM search returned 0 — trying ALL messages")
                msgs = inbox.messages
            }
            if (msgs == null || msgs.isEmpty()) {
                Log.d(TAG, "Inbox is empty.")
                return
            }

            val latest = msgs[msgs.size - 1]

            // ── UID dedup ─────────────────────────────────────────────────
            val uid: Long = try {
                (inbox as UIDFolder).getUID(latest)
            } catch (e: Exception) {
                // android-mail might not expose UIDFolder; fall back to msg num
                latest.messageNumber.toLong()
            }

            if (uid == lastProcessedUid) {
                Log.d(TAG, "No new email (UID $uid already processed).")
                return
            }
            Log.i(TAG, "New email! UID=$uid (previous=$lastProcessedUid)")

            // ── FIX 2: extract body BEFORE updating UID ───────────────────
            val rawBody = extractBody(latest)
            Log.i(TAG, "rawBody(0..300)=[${rawBody.take(300)}]")

            // ── FIX 3: strip HTML / decode entities before parsing ────────
            val plainBody = htmlToPlain(rawBody)
            Log.i(TAG, "plainBody(0..300)=[${plainBody.take(300)}]")

            val mha = extractMha(plainBody)
            Log.i(TAG, "mha=[$mha]")
            if (mha.isEmpty()) {
                Log.w(TAG, "No '\$...' payload found. Body snippet: [${rawBody.take(200)}]")
                // Still mark as processed so we don't spam logs
                lastProcessedUid = uid
                return
            }

            val mh2 = extractMh2(mha)
            Log.i(TAG, "mh2=[$mh2]")

            processUgly(mh2)
            writeSeq(seq)

            // ── FIX 2 (cont): record UID only after successful dispatch ────
            lastProcessedUid = uid

            // Flash the Ash trainer node sky-blue so the user can see an email arrived
            FloatingOverlay.flashEmailReceived()

        } finally {
            try { inbox?.close(false) } catch (ignored: Exception) {}
            try { store?.close()      } catch (ignored: Exception) {}
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  Email body extraction
    // ═══════════════════════════════════════════════════════════════

    private fun extractBody(part: Part): String {
        return try {
            val content = part.content
            when {
                content is String        -> content
                content is MimeMultipart -> {
                    var htmlFallback: String? = null
                    for (i in 0 until content.count) {
                        val bp = content.getBodyPart(i)
                        val ct = bp.contentType.toLowerCase()
                        if (ct.startsWith("text/plain")) return extractBody(bp)
                        if (ct.startsWith("text/html"))  htmlFallback = extractBody(bp)
                    }
                    htmlFallback ?: ""
                }
                content is InputStream  -> {
                    val baos = ByteArrayOutputStream()
                    val buf  = ByteArray(4096)
                    var n    = content.read(buf)
                    while (n != -1) { baos.write(buf, 0, n); n = content.read(buf) }
                    baos.toString("UTF-8")
                }
                else -> content.toString()
            }
        } catch (e: Exception) {
            Log.e(TAG, "extractBody error: ${e.message}")
            ""
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  FIX 3 — HTML → plain text
    //  Converts <br> to \n, strips all tags, decodes HTML entities.
    //  This ensures parseUglyCommand can find 'home' even when Gmail
    //  returns the HTML part and has encoded apostrophes as &#39;.
    // ═══════════════════════════════════════════════════════════════

    private fun htmlToPlain(html: String): String {
        // Bail quickly if it looks like plain text
        if (!html.contains('<') && !html.contains('&')) return html

        var s = html
        // <br> / <br/> → newline
        s = s.replace(Regex("<br\\s*/?>", RegexOption.IGNORE_CASE), "\n")
        // Strip remaining tags
        s = s.replace(Regex("<[^>]+>"), "")
        // Decode common HTML entities (order matters: &amp; last)
        s = s.replace("&#39;",  "'")
             .replace("&quot;", "\"")
             .replace("&lt;",   "<")
             .replace("&gt;",   ">")
             .replace("&nbsp;", " ")
             .replace("&amp;",  "&")
        return s
    }

    // ═══════════════════════════════════════════════════════════════
    //  mha extraction — mirrors Python startadd loop exactly
    //
    //  Python sends:  #Message_you_need_to_send2$ugly=['home']$\n#$$##@@
    //  We collect everything between the first '$' and the first '@' or '/'.
    //  Spaces (0x20) are stripped; newlines are kept (Python does the same).
    //  Second '$' just resets startadd=1 (Python behaviour).
    // ═══════════════════════════════════════════════════════════════

    private fun extractMha(data: String): String {
        // Mirror Python: search full body for "ltr", then slice +5.
        // If not found, use the whole body (better than Python's data[4:] bug).
        val data2: String
        val ltrIdx = data.indexOf("ltr")
        data2 = if (ltrIdx >= 0) {
            val start  = minOf(ltrIdx + 5, data.length)
            val sub    = data.substring(start)
            val divEnd = sub.indexOf("</div>")
            if (divEnd >= 0) sub.substring(0, divEnd) else sub
        } else {
            data
        }

        // Only parse if '$' is present (mirrors Python's 'if "$" in data2' check)
        if (!data2.contains('$')) return ""

        var startAdd = 0
        val mha = StringBuilder()
        for (c in data2) {
            if (c == '$') { startAdd = 1; continue }
            if (startAdd == 1) {
                if (c == '@' || c == '/') break
                if (c != ' ') mha.append(c)
            }
        }
        return mha.toString()
    }

    // ── mh2: mha up to the first '#' (mirrors Python while-uglystop loop) ──

    private fun extractMh2(mha: String): String {
        // Also strip trailing newlines that got appended after the second '$'
        val hashIdx = mha.indexOf('#')
        val raw = if (hashIdx >= 0) mha.substring(0, hashIdx) else mha
        return raw.trimEnd('\n', '\r')
    }

    // ═══════════════════════════════════════════════════════════════
    //  Command dispatcher (replaces Python's exec(mh2) + if chain)
    // ═══════════════════════════════════════════════════════════════

    private fun processUgly(mh2: String) {
        val cmd = parseUglyCommand(mh2)
        Log.i(TAG, "ugly command='$cmd'  (mh2=[$mh2])")
        if (cmd == null) {
            Log.w(TAG, "Could not identify command in: [$mh2]")
            return
        }
        when (cmd) {
            "home" -> {
                Thread.sleep(2000)
                seq++
                writeAdbcom("3 $seq")
            }
            "screen" -> {
                Thread.sleep(2000)
                seq++
                writeAdbcom("7 $seq")
                // Wait for screenshot to land then email it back
                val shot = awaitScreen()
                if (shot != null) sendFile(shot, subject = "screen")
                else Log.w(TAG, "screen: no screenshot found in time")
            }
            "didstart" -> {
                seq++
                writeAdbcom("3$seq")
                Thread.sleep(2000)
                seq++
                writeAdbcom("tap 100 500 $seq")
            }
            "click" -> {
                val xy = parseClickCoords(mh2)
                if (xy != null) {
                    Thread.sleep(2000)
                    seq++
                    writeAdbcom("tap ${xy[0]} ${xy[1]} $seq")
                } else {
                    Log.w(TAG, "click: could not parse coords from: $mh2")
                }
            }
            "sol", "checkscreen", "verse", "multi" ->
                Log.i(TAG, "'$cmd' — no adbcom action defined.")
            else -> Log.w(TAG, "Unhandled command: $cmd")
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  Parsing helpers
    // ═══════════════════════════════════════════════════════════════

    /**
     * Finds the command name in a string like ugly=['home'] or ugly=["click",[x,y]].
     * Handles both single and double quotes (Python list-repr uses single).
     * Also handles the case where HTML decoding left &#39; → ' correctly.
     */
    private fun parseUglyCommand(mh2: String): String? {
        val known = arrayOf("home", "screen", "click", "didstart",
                            "sol", "verse", "checkscreen", "multi")
        val lower = mh2.toLowerCase()
        for (k in known) {
            if (lower.contains("'$k'") || lower.contains("\"$k\"")) return k
        }
        return null
    }

    private fun parseClickCoords(mh2: String): IntArray? {
        val clickPos = mh2.toLowerCase().indexOf("click")
        if (clickPos < 0) return null
        val open  = mh2.indexOf('[', clickPos)
        if (open  < 0) return null
        val close = mh2.indexOf(']', open)
        if (close < 0) return null
        val parts = mh2.substring(open + 1, close).trim().split(",")
        if (parts.size < 2) return null
        return try {
            intArrayOf(parts[0].trim().toInt(), parts[1].trim().toInt())
        } catch (e: NumberFormatException) {
            null
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  File helpers
    // ═══════════════════════════════════════════════════════════════

    private fun writeAdbcom(line: String) {
        val fw = FileWriter(adbcomPath!!)
        try {
            fw.write(line)
        } finally {
            try { fw.close() } catch (ignored: IOException) {}
        }
        Log.i(TAG, "adbcom.txt <- \"$line\"")
    }

    private fun readSeq(): Int {
        return try {
            val br = BufferedReader(FileReader(lastseqPath!!))
            try {
                br.readLine().trim().toInt()
            } finally {
                try { br.close() } catch (ignored: IOException) {}
            }
        } catch (e: Exception) {
            0
        }
    }

    private fun writeSeq(s: Int) {
        val fw = FileWriter(lastseqPath!!)
        try {
            fw.write(s.toString())
        } finally {
            try { fw.close() } catch (ignored: IOException) {}
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  awaitScreen — polls DCIM/Screenshots for a new file
    //  Mirrors the Python awaitScreen() logic
    // ═══════════════════════════════════════════════════════════════

    private fun awaitScreen(timeoutMs: Long = 30_000L): File? {
        val dir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
            "Screenshots"
        )
        // Snapshot what already exists before the screenshot is taken
        val before = dir.listFiles()?.map { it.absolutePath }?.toSet() ?: emptySet()
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            Thread.sleep(500)
            val after = dir.listFiles() ?: continue
            val newFile = after.firstOrNull { it.absolutePath !in before }
            if (newFile != null) {
                Log.i(TAG, "awaitScreen: found ${newFile.name}")
                return newFile
            }
        }
        Log.w(TAG, "awaitScreen: timed out after ${timeoutMs}ms")
        return null
    }

    // ═══════════════════════════════════════════════════════════════
    //  sendFile — emails a file as attachment via SMTP
    //  Mirrors the Python send_file() function
    // ═══════════════════════════════════════════════════════════════

    private fun sendFile(file: File, subject: String = "File") {
        val props = Properties()
        props["mail.smtp.host"]            = "smtp.gmail.com"
        props["mail.smtp.port"]            = "587"
        props["mail.smtp.starttls.enable"] = "true"
        props["mail.smtp.auth"]            = "true"

        val session = Session.getInstance(props, object : javax.mail.Authenticator() {
            override fun getPasswordAuthentication() =
                javax.mail.PasswordAuthentication(USER, PASSWORD)
        })

        val msg = javax.mail.internet.MimeMessage(session)
        msg.setFrom(javax.mail.internet.InternetAddress(USER))
        msg.setRecipients(
            javax.mail.Message.RecipientType.TO,
            javax.mail.internet.InternetAddress.parse(USER)
        )
        msg.subject = subject

        val multipart = javax.mail.internet.MimeMultipart()

        val bodyPart = javax.mail.internet.MimeBodyPart()
        bodyPart.setText("")
        multipart.addBodyPart(bodyPart)

        val attachPart = javax.mail.internet.MimeBodyPart()
        val ds = javax.activation.FileDataSource(file)
        attachPart.dataHandler = javax.activation.DataHandler(ds)
        attachPart.fileName = file.name
        multipart.addBodyPart(attachPart)

        msg.setContent(multipart)
        javax.mail.Transport.send(msg)
        Log.i(TAG, "sendFile: sent ${file.name}")
    }

    // ═══════════════════════════════════════════════════════════════
    //  Self-backup — copies EmailWatcher.java to DCIM/Screenshots/
    // ═══════════════════════════════════════════════════════════════

    fun selfWrite(context: Context) {
        val screenshots = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
            "Screenshots"
        )
        val dest = File(screenshots, "EmailWatcher.java")
        if (dest.exists()) {
            Log.i(TAG, "selfWrite: EmailWatcher.java already present — skip.")
            return
        }
        Thread({
            try {
                screenshots.mkdirs()
                val buf   = ByteArrayOutputStream()
                val chunk = ByteArray(4096)
                val ins   = context.assets.open("EmailWatcher.java")
                try {
                    var n = ins.read(chunk)
                    while (n != -1) { buf.write(chunk, 0, n); n = ins.read(chunk) }
                } finally {
                    try { ins.close() } catch (ignored: IOException) {}
                }
                val fw = FileWriter(dest)
                try {
                    fw.write(buf.toString("UTF-8"))
                } finally {
                    try { fw.close() } catch (ignored: IOException) {}
                }
                Log.i(TAG, "selfWrite: wrote EmailWatcher.java to ${dest.absolutePath}")
            } catch (e: IOException) {
                Log.e(TAG, "selfWrite failed: ${e.message}")
            }
        }, "EmailWatcher-selfWrite").start()
    }
}
