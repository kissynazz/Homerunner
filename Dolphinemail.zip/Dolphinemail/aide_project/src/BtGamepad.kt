package com.home.automation

import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.os.ParcelUuid
import java.util.UUID

object BtGamepad {

    private val SVC_HID        = uuid("1812");  private val CHR_HID_INFO   = uuid("2A4A")
    private val CHR_HID_CTRL   = uuid("2A4C");  private val CHR_REPORT_MAP = uuid("2A4B")
    private val CHR_REPORT     = uuid("2A4D");  private val CHR_PROTO_MODE = uuid("2A4E")
    private val DSC_REPORT_REF = uuid("2908");  private val DSC_CCCD       = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    private val SVC_BATT       = uuid("180F");  private val CHR_BATT_LEVEL = uuid("2A19")
    private val SVC_DEVINFO    = uuid("180A");  private val CHR_MANUF      = uuid("2A29");  private val CHR_MODEL = uuid("2A24")
    private val SVC_MOUSE      = UUID.fromString("A000B000-C000-D000-E000-F00000000001")
    private val CHR_MOUSE      = UUID.fromString("A000B000-C000-D000-E000-F00000000002")

    private val HID_DESCRIPTOR = byteArrayOf(
        0x05,0x01,0x09,0x05,0xA1.toByte(),0x01,0x85.toByte(),0x01,
        0x09,0x30,0x09,0x31,0x09,0x32,0x09,0x35,0x15,0x00,0x26,0xFF.toByte(),0x00,0x75,0x08,0x95.toByte(),0x04,0x81.toByte(),0x02,
        0x09,0x33,0x09,0x34,0x15,0x00,0x26,0xFF.toByte(),0x00,0x75,0x08,0x95.toByte(),0x02,0x81.toByte(),0x02,
        0x09,0x39,0x15,0x00,0x25,0x07,0x35,0x00,0x46,0x3B,0x01,0x65,0x14,0x75,0x04,0x95.toByte(),0x01,0x81.toByte(),0x42,
        0x75,0x04,0x95.toByte(),0x01,0x81.toByte(),0x03,
        0x05,0x09,0x19,0x01,0x29,0x0E,0x15,0x00,0x25,0x01,0x75,0x01,0x95.toByte(),0x0E,0x81.toByte(),0x02,
        0x75,0x02,0x95.toByte(),0x01,0x81.toByte(),0x03,0xC0.toByte()
    )

    private var gattServer: BluetoothGattServer? = null
    private var advertiseCallback: AdvertiseCallback? = null
    private var reportChar: BluetoothGattCharacteristic? = null
    private var mouseChar: BluetoothGattCharacteristic? = null
    private val connectedDevices = mutableListOf<BluetoothDevice>()

    fun start(context: Context) {
        val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter = manager.adapter ?: run { android.util.Log.e("BtGamepad", "Bluetooth not available"); return }
        if (!adapter.isEnabled) { android.util.Log.e("BtGamepad", "Bluetooth is off"); return }
        gattServer = manager.openGattServer(context, gattCallback)
        gattServer?.addService(buildHidService()); gattServer?.addService(buildBatteryService())
        gattServer?.addService(buildDeviceInfoService()); gattServer?.addService(buildMouseService())
        val settings = AdvertiseSettings.Builder().setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY).setConnectable(true).setTimeout(0).build()
        val data = AdvertiseData.Builder().addServiceUuid(ParcelUuid(SVC_HID)).setIncludeDeviceName(true).build()
        advertiseCallback = object : AdvertiseCallback() {
            override fun onStartSuccess(s: AdvertiseSettings?) {
                android.util.Log.i("BtGamepad", "Advertising as HID gamepad")
            }

            override fun onStartFailure(e: Int) {
                android.util.Log.e("BtGamepad", "Advertising failed: $e")
            }
        }

        adapter.bluetoothLeAdvertiser?.startAdvertising(settings, data, advertiseCallback!!) ?: android.util.Log.e("BtGamepad", "LE advertising not supported")
    }

    fun stop(context: Context) {
        val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        advertiseCallback?.let { manager.adapter?.bluetoothLeAdvertiser?.stopAdvertising(it) }
        gattServer?.close(); gattServer = null; connectedDevices.clear()
    }

    fun sendReport(report: ByteArray) {
        if (report.size != 9) return
        val char = reportChar ?: return
        char.value = report; connectedDevices.forEach { gattServer?.notifyCharacteristicChanged(it, char, false) }
    }

    fun sendMouseEvent(event: Int, x: Int, y: Int) {
        val char = mouseChar ?: return
        char.value = byteArrayOf(event.toByte(), 0x00, (x and 0xFF).toByte(), ((x shr 8) and 0xFF).toByte(), (y and 0xFF).toByte(), ((y shr 8) and 0xFF).toByte())
        connectedDevices.forEach { gattServer?.notifyCharacteristicChanged(it, char, false) }
    }

    private val gattCallback = object : BluetoothGattServerCallback() {
        override fun onConnectionStateChange(device: BluetoothDevice, status: Int, newState: Int) {
            when (newState) {
                BluetoothProfile.STATE_CONNECTED    -> connectedDevices.add(device)
                BluetoothProfile.STATE_DISCONNECTED -> connectedDevices.remove(device)
            }
        }
        override fun onCharacteristicReadRequest(device: BluetoothDevice, requestId: Int, offset: Int, characteristic: BluetoothGattCharacteristic) {
            val v = characteristic.value ?: byteArrayOf()
            gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, offset, if (offset < v.size) v.copyOfRange(offset, v.size) else byteArrayOf())
        }
        override fun onCharacteristicWriteRequest(device: BluetoothDevice, requestId: Int, characteristic: BluetoothGattCharacteristic, preparedWrite: Boolean, responseNeeded: Boolean, offset: Int, value: ByteArray) {
            if (responseNeeded) gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, 0, null)
        }
        override fun onDescriptorReadRequest(device: BluetoothDevice, requestId: Int, offset: Int, descriptor: BluetoothGattDescriptor) {
            gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, offset, descriptor.value ?: byteArrayOf())
        }
        override fun onDescriptorWriteRequest(device: BluetoothDevice, requestId: Int, descriptor: BluetoothGattDescriptor, preparedWrite: Boolean, responseNeeded: Boolean, offset: Int, value: ByteArray) {
            descriptor.value = value; if (responseNeeded) gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, 0, null)
        }
    }

    private fun buildHidService(): BluetoothGattService {
        val svc = BluetoothGattService(SVC_HID, BluetoothGattService.SERVICE_TYPE_PRIMARY)
        svc.addCharacteristic(readChar(CHR_HID_INFO, byteArrayOf(0x01, 0x01, 0x00, 0x02)))
        svc.addCharacteristic(writeNoRespChar(CHR_HID_CTRL))
        svc.addCharacteristic(readChar(CHR_REPORT_MAP, HID_DESCRIPTOR))
        svc.addCharacteristic(BluetoothGattCharacteristic(CHR_PROTO_MODE, BluetoothGattCharacteristic.PROPERTY_READ or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE, BluetoothGattCharacteristic.PERMISSION_READ or BluetoothGattCharacteristic.PERMISSION_WRITE).also { it.value = byteArrayOf(0x01) })
        val rpt = BluetoothGattCharacteristic(CHR_REPORT, BluetoothGattCharacteristic.PROPERTY_READ or BluetoothGattCharacteristic.PROPERTY_NOTIFY, BluetoothGattCharacteristic.PERMISSION_READ)
            .also { it.value = ByteArray(9) { i -> (if (i == 6) 8 else if (i < 4) 128 else 0).toByte() } }
        rpt.addDescriptor(BluetoothGattDescriptor(DSC_CCCD, BluetoothGattDescriptor.PERMISSION_READ or BluetoothGattDescriptor.PERMISSION_WRITE).also { it.value = BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE })
        rpt.addDescriptor(BluetoothGattDescriptor(DSC_REPORT_REF, BluetoothGattDescriptor.PERMISSION_READ).also { it.value = byteArrayOf(0x01, 0x01) })
        svc.addCharacteristic(rpt); reportChar = rpt; return svc
    }

    private fun buildBatteryService(): BluetoothGattService {
        val svc = BluetoothGattService(SVC_BATT, BluetoothGattService.SERVICE_TYPE_PRIMARY)
        val batt = BluetoothGattCharacteristic(CHR_BATT_LEVEL, BluetoothGattCharacteristic.PROPERTY_READ or BluetoothGattCharacteristic.PROPERTY_NOTIFY, BluetoothGattCharacteristic.PERMISSION_READ).also { it.value = byteArrayOf(0x64) }
        batt.addDescriptor(BluetoothGattDescriptor(DSC_CCCD, BluetoothGattDescriptor.PERMISSION_READ or BluetoothGattDescriptor.PERMISSION_WRITE).also { it.value = BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE })
        svc.addCharacteristic(batt); return svc
    }

    private fun buildDeviceInfoService(): BluetoothGattService {
        val svc = BluetoothGattService(SVC_DEVINFO, BluetoothGattService.SERVICE_TYPE_PRIMARY)
        svc.addCharacteristic(readChar(CHR_MANUF, "KotlinGamepad".toByteArray()))
        svc.addCharacteristic(readChar(CHR_MODEL, "PyGamepad 1.0".toByteArray())); return svc
    }

    private fun buildMouseService(): BluetoothGattService {
        val svc = BluetoothGattService(SVC_MOUSE, BluetoothGattService.SERVICE_TYPE_PRIMARY)
        val mouse = BluetoothGattCharacteristic(CHR_MOUSE, BluetoothGattCharacteristic.PROPERTY_READ or BluetoothGattCharacteristic.PROPERTY_NOTIFY or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE, BluetoothGattCharacteristic.PERMISSION_READ or BluetoothGattCharacteristic.PERMISSION_WRITE).also { it.value = ByteArray(6) }
        mouse.addDescriptor(BluetoothGattDescriptor(DSC_CCCD, BluetoothGattDescriptor.PERMISSION_READ or BluetoothGattDescriptor.PERMISSION_WRITE).also { it.value = BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE })
        svc.addCharacteristic(mouse); mouseChar = mouse; return svc
    }

    private fun readChar(uuid: UUID, value: ByteArray) = BluetoothGattCharacteristic(uuid, BluetoothGattCharacteristic.PROPERTY_READ, BluetoothGattCharacteristic.PERMISSION_READ).also { it.value = value }
    private fun writeNoRespChar(uuid: UUID) = BluetoothGattCharacteristic(uuid, BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE, BluetoothGattCharacteristic.PERMISSION_WRITE)
    private fun uuid(s: String): UUID = if (s.length == 4) UUID.fromString("0000$s-0000-1000-8000-00805f9b34fb") else UUID.fromString(s)
}
