package com.home.automation

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.InputDevice
import android.view.MotionEvent
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

object HomeScriptRunner {

    @Volatile var accessibilityService: AccessibilityService? = null

    fun executeAction(actionType: String, data: String = ""): String {
        return try {
            when (actionType.lowercase()) {
                "home", "3"       -> triggerHome()
                "screenshot", "7" -> triggerScreenshot()
                "tap"             -> simulateViewTap(data)
                "swipe"           -> simulateViewSwipe(data)
                else              -> "Error: Action '$actionType' not supported"
            }
        } catch (e: Exception) { "Action Error: ${e.message}" }
    }

    private fun triggerHome(): String {
        val svc = accessibilityService
        return if (svc != null) {
            val ok = svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            if (ok) "Success: Navigated to Home Screen" else "Error: performGlobalAction(HOME) returned false"
        } else {
            val ctx = getContext() ?: return "Error: No context"
            triggerHomeIntent(ctx)
        }
    }

    private fun triggerScreenshot(): String {
        val svc = accessibilityService
        return if (svc != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val ok = svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
            if (ok) "Success: Screenshot taken" else "Error: performGlobalAction(SCREENSHOT) returned false"
        } else {
            val ctx = getContext() ?: return "Error: No context"
            triggerNativeScreenshot(ctx)
        }
    }

    private fun getContext(): android.app.Application? = try {
        val at = Class.forName("android.app.ActivityThread")
        val cur = at.getDeclaredMethod("currentActivityThread").apply { isAccessible = true }.invoke(null)
        at.getDeclaredMethod("getApplication").apply { isAccessible = true }.invoke(cur) as android.app.Application
    } catch (_: Exception) { null }

    private fun getInputManagerAndInjectMethod(): Pair<Any, java.lang.reflect.Method> {
        val cls = Class.forName("android.hardware.input.InputManager")
        val instance = cls.getDeclaredMethod("getInstance").apply { isAccessible = true }.invoke(null)
        val inject = cls.getDeclaredMethod("injectInputEvent", android.view.InputEvent::class.java, Int::class.java).apply { isAccessible = true }
        return Pair(instance, inject)
    }

    private fun injectMotionEvent(im: Any, inject: java.lang.reflect.Method, action: Int, x: Float, y: Float, downTime: Long, eventTime: Long) {
        val e = MotionEvent.obtain(downTime, eventTime, action, x, y, 0).also { it.source = InputDevice.SOURCE_TOUCHSCREEN }
        inject.invoke(im, e, 0); e.recycle()
    }

    private fun triggerHomeIntent(context: android.app.Application): String {
        val intentClass = Class.forName("android.content.Intent")
        val intent = intentClass.getConstructor(String::class.java).newInstance("android.intent.action.MAIN")
        intentClass.getDeclaredMethod("addCategory", String::class.java).invoke(intent, "android.intent.category.HOME")
        intentClass.getDeclaredMethod("setFlags", Int::class.java).invoke(intent, 0x10000000)
        context.javaClass.getMethod("startActivity", intentClass).invoke(context, intent)
        return "Success: Navigated to Home Screen"
    }

    private fun triggerNativeScreenshot(context: android.app.Application): String {
        return try {
            val wmClass = Class.forName("android.view.WindowManagerGlobal")
            val wmInstance = wmClass.getDeclaredMethod("getInstance").apply { isAccessible = true }.invoke(null)
            @Suppress("UNCHECKED_CAST")
            val views = wmClass.getDeclaredField("mViews").apply { isAccessible = true }.get(wmInstance) as? ArrayList<android.view.View>
            if (views.isNullOrEmpty()) return "Error: No root views found"
            val view = views.last()
            if (view.width == 0 || view.height == 0) return "Error: View has no dimensions"
            var result = "Error: Screenshot timed out"
            val latch = CountDownLatch(1)
            Handler(Looper.getMainLooper()).post {
                try {
                    val bitmap = Bitmap.createBitmap(view.width, view.height, Bitmap.Config.ARGB_8888)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        val surface = getSurface(view)
                        if (surface != null && surface.isValid) {
                            android.view.PixelCopy.request(surface, android.graphics.Rect(0, 0, view.width, view.height), bitmap, { cr ->
                                result = if (cr == android.view.PixelCopy.SUCCESS) saveBitmap(context, bitmap) else "Error: PixelCopy failed ($cr)"
                                latch.countDown()
                            }, Handler(Looper.getMainLooper()))
                            return@post
                        }
                    }
                    view.draw(Canvas(bitmap)); result = saveBitmap(context, bitmap); latch.countDown()
                } catch (e: Exception) { result = "Screenshot Error: ${e.message}"; latch.countDown() }
            }
            latch.await(10, TimeUnit.SECONDS); result
        } catch (e: Exception) { "Screenshot Error: ${e.message}" }
    }


    private fun getSurface(view: android.view.View): android.view.Surface? {
        return try {
            val ai = android.view.View::class.java.getDeclaredField("mAttachInfo").apply { isAccessible = true }.get(view) ?: return null
            val vri = ai.javaClass.getDeclaredField("mViewRootImpl").apply { isAccessible = true }.get(ai) ?: return null
            vri.javaClass.getDeclaredField("mSurface").apply { isAccessible = true }.get(vri) as? android.view.Surface
        } catch (_: Exception) {
            null
        }
    }


    private fun saveBitmap(context: android.app.Application, bitmap: Bitmap): String {
        val fileName = "screenshot_${System.currentTimeMillis()}.png"
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = android.content.ContentValues().apply {
                put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, fileName)
                put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(android.provider.MediaStore.Images.Media.RELATIVE_PATH, "DCIM/Screenshots")
                put(android.provider.MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = context.contentResolver.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return "Error: MediaStore insert failed"
            context.contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            values.clear(); values.put(android.provider.MediaStore.Images.Media.IS_PENDING, 0)
            context.contentResolver.update(uri, values, null, null)
            "Success: Screenshot saved to DCIM/Screenshots/$fileName"
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), "Screenshots").also { it.mkdirs() }
            val file = File(dir, fileName)
            FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            android.media.MediaScannerConnection.scanFile(context, arrayOf(file.absolutePath), arrayOf("image/png"), null)
            "Success: Screenshot saved to ${file.absolutePath}"
        }
    }

    private fun simulateViewTap(coordinates: String): String {
        return try {
            val parts = coordinates.split(",")
            if (parts.size < 2) return "Tap Error: Expected 'x,y'"
            val x = parts[0].trim().toFloat(); val y = parts[1].trim().toFloat()
            val (im, inject) = getInputManagerAndInjectMethod()
            val dt = SystemClock.uptimeMillis()
            injectMotionEvent(im, inject, MotionEvent.ACTION_DOWN, x, y, dt, dt)
            Thread.sleep(50)
            injectMotionEvent(im, inject, MotionEvent.ACTION_UP, x, y, dt, SystemClock.uptimeMillis())
            "Success: Tapped at ($x, $y)"
        } catch (e: Exception) { "Tap Error: ${e.message}" }
    }

    private fun simulateViewSwipe(coordinates: String): String {
        return try {
            val parts = coordinates.split(",")
            if (parts.size < 4) return "Swipe Error: Expected 'x1,y1,x2,y2'"
            val x1 = parts[0].trim().toFloat(); val y1 = parts[1].trim().toFloat()
            val x2 = parts[2].trim().toFloat(); val y2 = parts[3].trim().toFloat()
            val dur = if (parts.size >= 5) parts[4].trim().toLong() else 300L
            val (im, inject) = getInputManagerAndInjectMethod()
            val dt = SystemClock.uptimeMillis(); val steps = 20
            injectMotionEvent(im, inject, MotionEvent.ACTION_DOWN, x1, y1, dt, dt)
            for (i in 1..steps) {
                val f = i.toFloat() / steps
                Thread.sleep(dur / steps)
                injectMotionEvent(im, inject, MotionEvent.ACTION_MOVE, x1 + (x2 - x1) * f, y1 + (y2 - y1) * f, dt, dt + (dur * f).toLong())
            }
            injectMotionEvent(im, inject, MotionEvent.ACTION_UP, x2, y2, dt, SystemClock.uptimeMillis())
            "Success: Swiped from ($x1,$y1) to ($x2,$y2)"
        } catch (e: Exception) { "Swipe Error: ${e.message}" }
    }
}
