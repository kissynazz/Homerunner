//
// pswon.csx
//
// Spawns two square "nodes" side by side, both textured with Ashketchem2.png,
// plus a START button (top-middle of the pswon overlay) that slides down a
// Donkey Kong 64-style pause menu: NODES / BLUETOOTH / LIST COMMAND /
// USE COMMAND / HOMEKONTROLLER / RETURN.
//
// Wired to the golden-banana button on BT2FRO.csx's gamepad screen:
//   #load "pswon.csx"   (top of BT2FRO.csx)
//   ...
//   Pswon.Show(this);    // `this` = the GamepadView the button lives on
//
// This is a styling/UI pass, not a new controller — "USE COMMAND" reuses
// GamepadView's own SendRawCommand()/HasLiveConnection (already on the class
// that owns the live BLE connection); nothing new scans or connects here.
//
// Also defines Assets.Load(), a small texture loader shared with BT2FRO.csx —
// PNGs are expected to sit in an "assets" folder next to the scripts
// (homerunner/assets/Ashketchem2.png, homerunner/assets/GoldenBanana.png).
// If your Continuous/csx runner resolves paths differently, adjust Assets.Dir.
//

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using CoreFoundation;
using CoreGraphics;
using Foundation;
using UIKit;

// ── Shared texture loader ───────────────────────────────────────────────────

static class Assets {
    // Scripts run with CWD set to their own folder in most csx/Continuous
    // setups, so "./assets/<file>" is the primary lookup path.
    public static readonly string Dir = Path.Combine(Environment.CurrentDirectory, "assets");

    public static UIImage? Load(string filename) {
        var path = Path.Combine(Dir, filename);
        if (!File.Exists(path)) {
            // Fallback: alongside the app bundle, in case CWD isn't the script folder.
            var alt = Path.Combine(NSBundle.MainBundle.BundlePath, "assets", filename);
            if (File.Exists(alt)) path = alt;
        }
        if (!File.Exists(path)) {
            Console.WriteLine($"[Assets] texture not found: {filename} (looked in {Dir})");
            return null;
        }
        return UIImage.FromFile(path);
    }
}

// ── DK64 pause-menu palette/type ─────────────────────────────────────────────
//
// Matches the look of the in-game DK64 pause screen: warm parchment-gold
// bold text with a dark drop shadow, over a near-black translucent panel
// with a brass/gold border.

static class DkStyle {
    public static readonly UIColor Gold      = UIColor.FromRGB(0xf4, 0xd0, 0x3e);
    public static readonly UIColor GoldDim   = UIColor.FromRGB(0xb8, 0x8a, 0x2a);
    public static readonly UIColor PanelBg   = UIColor.FromRGBA(0x12, 0x0a, 0x04, 0xe8);
    public static readonly UIColor RowHi     = UIColor.FromRGBA(0xf4, 0xd0, 0x3e, 0x28);

    public static UIFont Title => UIFont.FromName("AvenirNext-Bold", 20) ?? UIFont.BoldSystemFontOfSize(20);
    public static UIFont Row   => UIFont.FromName("AvenirNext-DemiBold", 17) ?? UIFont.BoldSystemFontOfSize(17);
    public static UIFont Small => UIFont.FromName("AvenirNext-Medium", 13) ?? UIFont.SystemFontOfSize(13);

    public static UILabel MakeLabel(string text, UIFont font, UIColor color, UITextAlignment align = UITextAlignment.Center) {
        var l = new UILabel {
            Text          = text,
            Font          = font,
            TextColor     = color,
            TextAlignment = align,
            Lines         = 0,
        };
        // DK64-style drop shadow on the gold text.
        l.Layer.ShadowColor   = UIColor.Black.CGColor;
        l.Layer.ShadowOffset  = new CGSize(0, 2);
        l.Layer.ShadowOpacity = 0.85f;
        l.Layer.ShadowRadius  = 0;
        return l;
    }
}

// ── PswonNode — a spawned node's editable state ─────────────────────────────

class PswonKeyframe {
    public double Time;
    public CGPoint Center;
    public nfloat  Scale;
}

class PswonNode {
    public string            Name    = "Node";
    public string            ImageName;
    public UIView?            View;
    public CGPoint            Center;
    public nfloat             Scale   = 1;
    public string?            SoundName;   // optional assets/<name> to play, else a placeholder tock
    public List<PswonKeyframe> Keyframes = new();

    public void ApplyTransform() {
        if (View == null) return;
        View.Center    = Center;
        View.Transform  = CGAffineTransform.MakeScale(Scale, Scale);
    }
}

// ── pswon() — spawns nodes + wires the START button/pause menu ─────────────

static class Pswon {

    const nfloat NodeSize = 110;
    const nfloat Gap      = 16;

    static UIView? _overlay;
    static readonly List<PswonNode> _nodes = new();
    static int _nodeCounter = 0;

    /// Read-only view of the currently spawned nodes — used by the NODES submenu.
    public static IReadOnlyList<PswonNode> Nodes => _nodes;

    /// Spawns an extra node into the currently-open overlay. No-ops if pswon isn't open.
    public static PswonNode? AddNodePublic(string imageName, CGPoint center) {
        if (_overlay == null) return null;
        return AddNode(_overlay, imageName, center);
    }

    /// Creates the pswon overlay: two starter nodes (Ashketchem2), centered on
    /// `parent`, plus a START button pinned top-middle that opens the pause menu.
    /// Unlike the old auto-dismiss preview, this overlay stays up until RETURN
    /// is tapped from the pause menu (or the node area itself is double-tapped).
    public static void Show(UIView parent) {
        DispatchQueue.MainQueue.DispatchAsync(() => {
            if (_overlay != null) return;   // already open

            var overlay = new UIView(parent.Bounds) { BackgroundColor = UIColor.Clear };
            parent.AddSubview(overlay);
            _overlay = overlay;

            _nodes.Clear();
            _nodeCounter = 0;

            nfloat totalW = NodeSize * 2 + Gap;
            nfloat left   = overlay.Bounds.GetMidX() - totalW / 2;
            nfloat top    = overlay.Bounds.GetMidY() - NodeSize / 2;

            AddNode(overlay, "Ashketchem2.png", new CGPoint(left + NodeSize / 2, top + NodeSize / 2));
            AddNode(overlay, "Ashketchem2.png", new CGPoint(left + NodeSize + Gap + NodeSize / 2, top + NodeSize / 2));

            foreach (var n in Nodes) { n.View!.Alpha = 0; }
            UIView.Animate(0.15, () => { foreach (var n in Nodes) n.View!.Alpha = 1; });

            BuildStartButton(overlay);
        });
    }

    static void Dismiss() {
        if (_overlay == null) return;
        var ov = _overlay;
        _overlay = null;
        UIView.Animate(0.2, () => ov!.Alpha = 0, () => ov!.RemoveFromSuperview());
    }

    // ── Node management (used by the NODES submenu) ─────────────────────────

    static PswonNode AddNode(UIView overlay, string imageName, CGPoint center) {
        var img = Assets.Load(imageName);
        var node = new PswonNode {
            Name      = $"Node {++_nodeCounter}",
            ImageName = imageName,
            Center    = center,
        };
        node.View = MakeNodeView(img);
        node.View.Center = center;
        overlay.AddSubview(node.View);
        _nodes.Add(node);
        return node;
    }

    static UIView MakeNodeView(UIImage? img) {
        var bg = new UIView(new CGRect(0, 0, NodeSize, NodeSize)) {
            BackgroundColor        = UIColor.FromRGB(0x11, 0x11, 0x11),
            ClipsToBounds          = true,
            UserInteractionEnabled = true,
        };
        bg.Layer.CornerRadius = 10;
        bg.Layer.BorderColor  = UIColor.White.CGColor;
        bg.Layer.BorderWidth  = 1;

        var imgView = new UIImageView(bg.Bounds) {
            ContentMode   = UIViewContentMode.ScaleAspectFit,
            ClipsToBounds = true,
            Image         = img,
        };
        bg.AddSubview(imgView);
        return bg;
    }

    // ── START button (top-middle of the pswon overlay) ──────────────────────

    static void BuildStartButton(UIView overlay) {
        const nfloat w = 96, h = 34;
        var frame = new CGRect(overlay.Bounds.GetMidX() - w / 2, 28, w, h);

        var btn = new UIView(frame) {
            BackgroundColor        = UIColor.FromRGB(0x1c, 0x1c, 0x1c),
            UserInteractionEnabled = true,
        };
        btn.Layer.CornerRadius = h / 2;
        btn.Layer.BorderColor  = UIColor.FromRGB(0x88, 0x88, 0x88).CGColor;
        btn.Layer.BorderWidth  = 1;

        var lbl = new UILabel(btn.Bounds) {
            Text          = "START",
            Font          = UIFont.BoldSystemFontOfSize(13),
            TextColor     = UIColor.LightGray,
            TextAlignment = UITextAlignment.Center,
        };
        btn.AddSubview(lbl);
        overlay.AddSubview(btn);

        btn.AddGestureRecognizer(new UITapGestureRecognizer(() => PauseMenu.Show(overlay)));
    }
}

// ── PauseMenu — DK64-style panel that slides down from the top ─────────────

static class PauseMenu {

    static UIView?  _panel;
    static UIView?  _content;   // swapped out per submenu
    static GamepadView? _gv;    // set from Show() so USE COMMAND can reach the live link

    public static void Show(UIView overlay) {
        if (_panel != null) return;
        _gv = overlay.Superview as GamepadView ?? overlay.FindGamepadView();

        nfloat w = overlay.Bounds.Width * 0.86f;
        nfloat h = 300;
        nfloat x = (overlay.Bounds.Width - w) / 2;

        var panel = new UIView(new CGRect(x, -h - 10, w, h)) {
            BackgroundColor = DkStyle.PanelBg,
        };
        panel.Layer.CornerRadius  = 14;
        panel.Layer.BorderColor   = DkStyle.GoldDim.CGColor;
        panel.Layer.BorderWidth   = 2;
        overlay.AddSubview(panel);
        _panel = panel;

        ShowRoot();

        UIView.Animate(0.35, 0, UIViewAnimationOptions.CurveEaseOut,
            () => panel.Frame = new CGRect(x, 44, w, h), null);
    }

    static void Dismiss() {
        var panel = _panel;
        if (panel == null) return;
        _panel = null;
        UIView.Animate(0.28, 0, UIViewAnimationOptions.CurveEaseIn,
            () => panel.Frame = new CGRect(panel.Frame.X, -panel.Frame.Height - 10, panel.Frame.Width, panel.Frame.Height),
            () => panel.RemoveFromSuperview());
    }

    // Swap the panel's inner content without re-animating the slide.
    static void SetContent(UIView view) {
        _content?.RemoveFromSuperview();
        _content = view;
        _panel!.AddSubview(view);
    }

    // ── Root menu ────────────────────────────────────────────────────────────

    static void ShowRoot() {
        var panel = _panel!;
        var v = new UIView(new CGRect(0, 0, panel.Bounds.Width, panel.Bounds.Height));

        var title = DkStyle.MakeLabel("PAUSED", DkStyle.Title, DkStyle.Gold);
        title.Frame = new CGRect(0, 14, v.Bounds.Width, 26);
        v.AddSubview(title);

        string[] items = { "NODES", "BLUETOOTH", "LIST COMMAND", "USE COMMAND", "HOMEKONTROLLER", "RETURN" };
        nfloat rowH = 34, startY = 56;
        for (int i = 0; i < items.Length; i++) {
            var idx  = i;
            var name = items[i];
            var row  = MakeRow(name, new CGRect(0, startY + rowH * i, v.Bounds.Width, rowH));
            row.Tag  = idx;
            row.AddGestureRecognizer(new UITapGestureRecognizer(() => OnRootItemTapped(name)));
            v.AddSubview(row);
        }

        SetContent(v);
    }

    static void OnRootItemTapped(string name) {
        switch (name) {
            case "NODES":          Nodes.ShowList(); break;
            case "BLUETOOTH":      ShowBluetooth();  break;
            case "LIST COMMAND":   ShowListCommand(); break;
            case "USE COMMAND":    ShowUseCommand();  break;
            case "HOMEKONTROLLER": ShowHomeKontroller(); break;
            case "RETURN":         Dismiss();         break;
        }
    }

    // ── Shared row/back-button helpers ──────────────────────────────────────

    static UIView MakeRow(string text, CGRect frame) {
        var row = new UIView(frame) { UserInteractionEnabled = true, BackgroundColor = UIColor.Clear };
        var lbl = DkStyle.MakeLabel(text, DkStyle.Row, DkStyle.Gold);
        lbl.Frame = row.Bounds;
        row.AddSubview(lbl);

        // Brief highlight flash so taps feel responsive, DK64-menu style.
        row.AddGestureRecognizer(new UITapGestureRecognizer(() => {
            row.BackgroundColor = DkStyle.RowHi;
            UIView.Animate(0.25, () => row.BackgroundColor = UIColor.Clear);
        }));
        return row;
    }

    // ── NODES submenu ────────────────────────────────────────────────────────

    static class Nodes {
        static PswonNode? _editing;

        public static void ShowList() {
            var panel = _panel!;
            var v = new UIView(new CGRect(0, 0, panel.Bounds.Width, panel.Bounds.Height));
            AddHeader(v, "NODES", ShowRoot);

            var list = Pswon.Nodes;
            nfloat rowH = 30, startY = 48;
            for (int i = 0; i < list.Count; i++) {
                var node = list[i];
                var row  = MakeRow($"{node.Name}  (scale {node.Scale:0.00})", new CGRect(0, startY + rowH * i, v.Bounds.Width, rowH));
                row.AddGestureRecognizer(new UITapGestureRecognizer(() => ShowEditor(node)));
                v.AddSubview(row);
            }

            var addRow = MakeRow("+ ADD NODE", new CGRect(0, startY + rowH * list.Count + 6, v.Bounds.Width, rowH));
            addRow.AddGestureRecognizer(new UITapGestureRecognizer(() => {
                var overlay = panel.Superview!;
                var center  = new CGPoint(overlay.Bounds.GetMidX(), overlay.Bounds.GetMidY() + 90);
                Pswon.AddNodePublic("Ashketchem2.png", center);
                ShowList();  // refresh
            }));
            v.AddSubview(addRow);

            SetContent(v);
        }

        static void ShowEditor(PswonNode node) {
            _editing = node;
            var panel = _panel!;
            var v = new UIView(new CGRect(0, 0, panel.Bounds.Width, panel.Bounds.Height));
            AddHeader(v, node.Name, ShowList);

            var scaleLbl = DkStyle.MakeLabel($"Scale: {node.Scale:0.00}", DkStyle.Row, DkStyle.Gold);
            scaleLbl.Frame = new CGRect(0, 52, v.Bounds.Width, 24);
            v.AddSubview(scaleLbl);

            var minus = MakeSmallButton("–", new CGRect(v.Bounds.Width / 2 - 70, 82, 44, 34));
            var plus  = MakeSmallButton("+", new CGRect(v.Bounds.Width / 2 + 26, 82, 44, 34));
            void Refresh() { scaleLbl.Text = $"Scale: {node.Scale:0.00}"; node.ApplyTransform(); }
            minus.AddGestureRecognizer(new UITapGestureRecognizer(() => { node.Scale = (nfloat)Math.Max(0.2, node.Scale - 0.1); Refresh(); }));
            plus.AddGestureRecognizer (new UITapGestureRecognizer(() => { node.Scale = (nfloat)Math.Min(3.0, node.Scale + 0.1); Refresh(); }));
            v.AddSubview(minus);
            v.AddSubview(plus);

            var kfRow = MakeRow("ADD KEYFRAME", new CGRect(0, 130, v.Bounds.Width, 30));
            kfRow.AddGestureRecognizer(new UITapGestureRecognizer(() => {
                node.Keyframes.Add(new PswonKeyframe { Time = node.Keyframes.Count, Center = node.Center, Scale = node.Scale });
                kfCountLbl!.Text = $"{node.Keyframes.Count} keyframe(s) captured";
            }));
            v.AddSubview(kfRow);

            var kfCountLbl = DkStyle.MakeLabel($"{node.Keyframes.Count} keyframe(s) captured", DkStyle.Small, DkStyle.GoldDim);
            kfCountLbl.Frame = new CGRect(0, 160, v.Bounds.Width, 18);
            v.AddSubview(kfCountLbl);

            var soundRow = MakeRow("▶ PLAY SOUND", new CGRect(0, 186, v.Bounds.Width, 30));
            var soundStatusLbl = DkStyle.MakeLabel("", DkStyle.Small, DkStyle.GoldDim);
            soundStatusLbl.Frame = new CGRect(0, 218, v.Bounds.Width, 18);
            soundRow.AddGestureRecognizer(new UITapGestureRecognizer(() => PlayNodeSound(node, soundStatusLbl)));
            v.AddSubview(soundRow);
            v.AddSubview(soundStatusLbl);

            SetContent(v);
        }

        static void PlayNodeSound(PswonNode node, UILabel statusLbl) {
            // No per-node audio assets exist yet, so this is a visual-only stand-in
            // (flash + status text) rather than a real playback call — honest about
            // not doing audio yet instead of guessing at an API. Once you drop a
            // real clip in assets/<NodeName>.caf, wire an AVAudioPlayer in here.
            statusLbl.Text      = "♪ (placeholder — no sound asset yet)";
            statusLbl.TextColor = DkStyle.Gold;
            UIView.Animate(0.4, () => statusLbl.TextColor = DkStyle.GoldDim);
        }

        static UIView MakeSmallButton(string text, CGRect frame) {
            var btn = new UIView(frame) {
                BackgroundColor        = UIColor.FromRGB(0x2a, 0x1c, 0x08),
                UserInteractionEnabled = true,
            };
            btn.Layer.CornerRadius = 8;
            btn.Layer.BorderColor  = DkStyle.GoldDim.CGColor;
            btn.Layer.BorderWidth  = 1;
            var lbl = DkStyle.MakeLabel(text, DkStyle.Title, DkStyle.Gold);
            lbl.Frame = btn.Bounds;
            btn.AddSubview(lbl);
            return btn;
        }
    }

    // ── BLUETOOTH — read-only status (real BT connect/scan lives on the main relay screen) ─

    static void ShowBluetooth() {
        var panel = _panel!;
        var v = new UIView(new CGRect(0, 0, panel.Bounds.Width, panel.Bounds.Height));
        AddHeader(v, "BLUETOOTH", ShowRoot);

        bool connected = _gv?.HasLiveConnection ?? false;
        var status = DkStyle.MakeLabel(
            connected ? "● Connected" : "○ Not connected",
            DkStyle.Row, connected ? UIColor.FromRGB(0x5c, 0xd6, 0x5c) : DkStyle.GoldDim);
        status.Frame = new CGRect(0, 60, v.Bounds.Width, 26);
        v.AddSubview(status);

        var note = DkStyle.MakeLabel(
            "Connect/scan from the main gamepad screen —\nthis panel just shows current status.",
            DkStyle.Small, UIColor.FromRGB(0x99, 0x99, 0x99));
        note.Frame = new CGRect(20, 100, v.Bounds.Width - 40, 44);
        v.AddSubview(note);

        SetContent(v);
    }

    // ── LIST COMMAND — read-only reference (see COMMAND_REFERENCE.md) ──────

    static void ShowListCommand() {
        var panel = _panel!;
        var v = new UIView(new CGRect(0, 0, panel.Bounds.Width, panel.Bounds.Height));
        AddHeader(v, "LIST COMMAND", ShowRoot);

        string[] refLines = {
            "screenshot|", "home|", "tap|x,y", "swipe|x1,y1,x2,y2",
            "notify: any action|data string",
        };
        var body = DkStyle.MakeLabel(string.Join("\n", refLines), DkStyle.Small, DkStyle.Gold, UITextAlignment.Left);
        body.Frame = new CGRect(20, 54, v.Bounds.Width - 40, 160);
        v.AddSubview(body);

        SetContent(v);
    }

    // ── USE COMMAND — send an action|data string over the existing link ────

    static void ShowUseCommand() {
        var panel = _panel!;
        var v = new UIView(new CGRect(0, 0, panel.Bounds.Width, panel.Bounds.Height));
        AddHeader(v, "USE COMMAND", ShowRoot);

        var actionField = new UITextField(new CGRect(20, 56, v.Bounds.Width - 40, 32)) {
            BackgroundColor = UIColor.FromRGB(0x22, 0x18, 0x08),
            TextColor       = DkStyle.Gold,
            Placeholder     = "action (e.g. tap)",
            BorderStyle     = UITextBorderStyle.RoundedRect,
        };
        var dataField = new UITextField(new CGRect(20, 96, v.Bounds.Width - 40, 32)) {
            BackgroundColor = UIColor.FromRGB(0x22, 0x18, 0x08),
            TextColor       = DkStyle.Gold,
            Placeholder     = "data (e.g. 540,1000)",
            BorderStyle     = UITextBorderStyle.RoundedRect,
        };
        v.AddSubview(actionField);
        v.AddSubview(dataField);

        var resultLbl = DkStyle.MakeLabel("", DkStyle.Small, DkStyle.GoldDim);
        resultLbl.Frame = new CGRect(20, 176, v.Bounds.Width - 40, 20);
        v.AddSubview(resultLbl);

        var sendRow = MakeRow("SEND", new CGRect(0, 136, v.Bounds.Width, 32));
        sendRow.AddGestureRecognizer(new UITapGestureRecognizer(() => {
            var action = actionField.Text ?? "";
            var data   = dataField.Text ?? "";
            if (string.IsNullOrWhiteSpace(action)) { resultLbl.Text = "Enter an action first."; return; }
            bool ok = _gv?.SendRawCommand(action, data) ?? false;
            resultLbl.Text = ok ? $"✓ sent {action}|{data}" : "✗ no live connection";
        }));
        v.AddSubview(sendRow);

        SetContent(v);
    }

    // ── HOMEKONTROLLER — placeholder ─────────────────────────────────────────

    static void ShowHomeKontroller() {
        var panel = _panel!;
        var v = new UIView(new CGRect(0, 0, panel.Bounds.Width, panel.Bounds.Height));
        AddHeader(v, "HOMEKONTROLLER", ShowRoot);

        var body = DkStyle.MakeLabel("Coming soon.", DkStyle.Row, DkStyle.GoldDim);
        body.Frame = new CGRect(0, 90, v.Bounds.Width, 26);
        v.AddSubview(body);

        SetContent(v);
    }

    static void AddHeader(UIView v, string title, Action onBack) {
        var backLbl = DkStyle.MakeLabel("‹ BACK", DkStyle.Small, DkStyle.GoldDim, UITextAlignment.Left);
        backLbl.Frame = new CGRect(12, 14, 70, 20);
        backLbl.UserInteractionEnabled = true;
        backLbl.AddGestureRecognizer(new UITapGestureRecognizer(onBack));
        v.AddSubview(backLbl);

        var titleLbl = DkStyle.MakeLabel(title, DkStyle.Title, DkStyle.Gold);
        titleLbl.Frame = new CGRect(0, 12, v.Bounds.Width, 26);
        v.AddSubview(titleLbl);
    }
}

// Small extension so PauseMenu can find the owning GamepadView without a hard
// reference cycle — walks up the view hierarchy from the pswon overlay.
static class ViewExtensions {
    public static GamepadView? FindGamepadView(this UIView v) {
        var cur = v.Superview;
        while (cur != null) {
            if (cur is GamepadView gv) return gv;
            cur = cur.Superview;
        }
        return null;
    }
}
