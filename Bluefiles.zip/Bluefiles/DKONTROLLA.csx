//
// SharpBlue
//
// Background BLE relay for Nazzara's iPad.
//
// What it does:
//   1. Scans for "Nazzara's iPad" and connects to it via CoreBluetooth.
//   2. Discovers the device's services and writable characteristics.
//   3. Runs a background polling loop every 1 second that reads
//      sharpbluesend.py, writes every pending command over BLE to the
//      connected peripheral, then clears the sent entries from the file.
//
// Command types understood from sharpbluesend.py:
//   "gamepad"  — 9-byte HID report written to the HID Report characteristic (0x2A4D, Report ID 1)
//                Phone relays it as a NOTIFY to the iPad HID host.
//   "keyboard" — 8-byte keyboard HID report [modifier, 0, key×6] written to 0x2A4D (Report ID 2)
//                Phone relays it as a NOTIFY to the iPad HID host.
//                Example: {"ts":"...","type":"keyboard","modifier":0,"keys":[4,0,0,0,0,0]}
//   "mouse"    — 6-byte packet written to the custom mouse characteristic
//   "notify"   — UTF-8 string written to NotifyChar (A000B000-...0004) — phone receives it
//                as an action|data command routed through HomeScriptRunner.
//                Example: {"ts":"...","type":"notify","cmd":"tap|540,1000"}
//
// Background execution:
//   Uses UIApplication.BeginBackgroundTask so the relay loop keeps running
//   even when the app is moved to the background.
//   iOS gives ~30 s of true background time; after that the loop re-requests
//   a task on each tick to stay alive as long as the OS allows.
//
// FIX — multi-device support:
//   iPad and A15 are tracked as separate connection slots.
//   SendHello() and the Relay each use the correct slot independently.
//
// FIX — OnReady fires as soon as NotifyChar is found:
//   The old "_discovered >= 3" gate required all 3 services to be seen before
//   firing OnReady, but discovery order is not guaranteed and the notify
//   characteristic is all that's needed to send. OnReady now fires as soon as
//   NotifyCharField is populated (after all characteristics in a service have
//   been reported).
//
// FIX — write type:
//   The Android CHR_NOTIFY_IN characteristic is declared with PERMISSION_WRITE
//   (not PERMISSION_WRITE_NO_RESPONSE), so iOS must use
//   CBCharacteristicWriteType.WithResponse — otherwise the packet is silently
//   dropped by the Android BT stack. All notify writes now use WithResponse.
//

#load "pswon.csx"

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

using CoreBluetooth;
using CoreFoundation;
using CoreGraphics;
using Foundation;
using UIKit;

// ── Tunables ──────────────────────────────────────────────────────────────────

static class Cfg {
    public static readonly string TargetName      = "Nazzara's iPad";
    public static readonly string KnownAddress    = "E4:43:89:52:0A:DA";  // reference only — iOS hides MACs

    // A15Name MUST match the BLE advertisement name set in BtSharedConfig.DEVICE_NAME ("nazcontroller").
    // "Nazzara's A15" is the classic Bluetooth system name — iOS BLE scanning sees the advertisement
    // name, not the system name, so using the system name here caused quick-connect to never match
    // and HandleConnected to slot the device into _ipadTarget instead of _a15Target.
    public static readonly string A15Name         = "nazcontroller";        // BLE advertisement name
    public static readonly string A15DisplayName  = "Nazzara's A15";        // friendly label for UI only
    public static readonly string A15Address      = "A0:1B:9E:12:36:FD";   // MAC — reference only
    public static readonly string A15BTAddress    = "A0:1B:9E:12:36:FC";   // BT address — reference only
    public static readonly string SendFile     = "sharpbluesend.py";
    public static readonly double PollInterval = 1.0;          // seconds

    // UUIDs that ble_gamepad.py publishes
    public static readonly CBUUID HidService    = CBUUID.FromString("1812");
    public static readonly CBUUID HidReport     = CBUUID.FromString("2A4D");   // gamepad report
    public static readonly CBUUID HidControl    = CBUUID.FromString("2A4C");   // control point
    public static readonly CBUUID MouseService  = CBUUID.FromString("A000B000-C000-D000-E000-F00000000001");
    public static readonly CBUUID MouseChar     = CBUUID.FromString("A000B000-C000-D000-E000-F00000000002");
    public static readonly CBUUID NotifyService = CBUUID.FromString("A000B000-C000-D000-E000-F00000000003");
    public static readonly CBUUID NotifyChar    = CBUUID.FromString("A000B000-C000-D000-E000-F00000000004");

    // nazcontrollerTwo — iPad acts as BLE peripheral so Android phone can connect to it
    public static readonly CBUUID NazTwoService = CBUUID.FromString("A000B000-C000-D000-E000-F00000000005");
    public static readonly CBUUID NazTwoChar    = CBUUID.FromString("A000B000-C000-D000-E000-F00000000006");

    // UI colours
    public static readonly UIColor Accent  = UIColor.SystemBlueColor;
    public static readonly UIColor Good    = UIColor.SystemGreenColor;
    public static readonly UIColor Warn    = UIColor.SystemOrangeColor;
    public static readonly UIColor Danger  = UIColor.SystemRedColor;
}

// ── Parsed command from sharpbluesend.py ──────────────────────────────────────

class BleCommand {
    public string?  Type;        // "gamepad" | "keyboard" | "mouse" | "notify"
    public string?  Timestamp;
    public byte[]?  Bytes;       // ready-to-write payload
    public string?  Raw;         // original JSON line (for clearing)

    // Build the 9-byte gamepad HID report from the "report" int array
    public static BleCommand Gamepad(string ts, int[] report, string raw) {
        var bytes = new byte[report.Length];
        for (int i = 0; i < report.Length; i++) bytes[i] = (byte)(report[i] & 0xFF);
        return new BleCommand { Type = "gamepad", Timestamp = ts, Bytes = bytes, Raw = raw };
    }

    // Build the 8-byte keyboard HID report: [modifier, 0x00, key0..key5]
    public static BleCommand Keyboard(string ts, int modifier, int[] keys, string raw) {
        var bytes = new byte[8];
        bytes[0] = (byte)(modifier & 0xFF);
        bytes[1] = 0x00;  // reserved
        for (int i = 0; i < Math.Min(keys.Length, 6); i++) bytes[i + 2] = (byte)(keys[i] & 0xFF);
        return new BleCommand { Type = "keyboard", Timestamp = ts, Bytes = bytes, Raw = raw };
    }

    // Build the 6-byte mouse packet  [event, 0, xLo, xHi, yLo, yHi]
    public static BleCommand Mouse(string ts, int evt, int x, int y, string raw) {
        var bytes = new byte[6];
        bytes[0] = (byte)(evt & 0xFF);
        bytes[1] = 0;
        bytes[2] = (byte)(x & 0xFF);
        bytes[3] = (byte)((x >> 8) & 0xFF);
        bytes[4] = (byte)(y & 0xFF);
        bytes[5] = (byte)((y >> 8) & 0xFF);
        return new BleCommand { Type = "mouse", Timestamp = ts, Bytes = bytes, Raw = raw };
    }

    // Build a notify (phone command) packet — UTF-8 encoded "action|data" string.
    // The phone's BtGamepad.onCommandReceived handler decodes this and runs it
    // through HomeScriptRunner (same actions as adbcom.txt).
    // cmd examples: "screenshot|"  "home|"  "tap|540,1000"  "swipe|100,900,100,200"
    public static BleCommand Notify(string ts, string cmd, string raw) {
        var bytes = Encoding.UTF8.GetBytes(cmd);
        return new BleCommand { Type = "notify", Timestamp = ts, Bytes = bytes, Raw = raw };
    }
}

// ── sharpbluesend.py parser ───────────────────────────────────────────────────

static class SendFileReader {

    public static List<BleCommand> Read(string path) {
        var result = new List<BleCommand>();
        if (!File.Exists(path)) return result;

        string text;
        try { text = File.ReadAllText(path); }
        catch { return result; }

        int start = text.IndexOf('[');
        int end   = text.LastIndexOf(']');
        if (start < 0 || end <= start) return result;

        string arrayText = text.Substring(start + 1, end - start - 1);
        foreach (var rawLine in arrayText.Split('\n')) {
            var line = rawLine.Trim().TrimEnd(',');
            if (!line.StartsWith("{") || !line.EndsWith("}")) continue;

            var cmd = ParseEntry(line);
            if (cmd != null) result.Add(cmd);
        }
        return result;
    }

    // Shared file-queue lock — used by ClearSent AND GamepadSender to prevent
    // read-modify-write races between the relay drain and the gamepad append path.
    internal static readonly object FileLock = new();

    public static void ClearSent(string path, HashSet<string> sentRaw) {
        if (!File.Exists(path)) return;
        lock (FileLock) {
            var remaining = Read(path).Where(c => !sentRaw.Contains(c.Raw)).ToList();

            var sb = new StringBuilder();
            sb.AppendLine("# sharpbluesend.py — BLE command queue (auto-generated by ble_gamepad.py)");
            sb.AppendLine("# Entries are removed after SharpBlue sends them.");
            sb.AppendLine();
            sb.AppendLine("pending = [");
            foreach (var c in remaining) sb.AppendLine($"    {c.Raw},");
            sb.AppendLine("]");

            try { File.WriteAllText(path, sb.ToString()); }
            catch { /* non-fatal */ }
        }
    }

    static BleCommand ParseEntry(string json) {
        try {
            var data = NSData.FromString(json, NSStringEncoding.UTF8);
            NSError err;
            var obj  = NSJsonSerialization.Deserialize(data, 0, out err) as NSDictionary;
            if (obj == null) return null;

            string ts   = obj.ValueForKey(new NSString("ts"))?.ToString()   ?? "";
            string type = obj.ValueForKey(new NSString("type"))?.ToString() ?? "";

            if (type == "gamepad") {
                var reportArr = obj.ValueForKey(new NSString("report")) as NSArray;
                if (reportArr == null) return null;
                var ints = new int[reportArr.Count];
                for (nuint i = 0; i < reportArr.Count; i++)
                    ints[i] = (int)(reportArr.GetItem<NSNumber>(i).Int32Value);
                return BleCommand.Gamepad(ts, ints, json);
            }

            if (type == "mouse") {
                int evt = ((NSNumber)obj.ValueForKey(new NSString("event"))).Int32Value;
                int x   = ((NSNumber)obj.ValueForKey(new NSString("x"))).Int32Value;
                int y   = ((NSNumber)obj.ValueForKey(new NSString("y"))).Int32Value;
                return BleCommand.Mouse(ts, evt, x, y, json);
            }

            if (type == "keyboard") {
                int modifier = 0;
                var modObj = obj.ValueForKey(new NSString("modifier"));
                if (modObj is NSNumber modNum) modifier = modNum.Int32Value;

                var keysArr = obj.ValueForKey(new NSString("keys")) as NSArray;
                var keys = new int[keysArr?.Count ?? 0];
                for (nuint i = 0; keysArr != null && i < keysArr.Count; i++)
                    keys[i] = (int)keysArr.GetItem<NSNumber>(i).Int32Value;
                return BleCommand.Keyboard(ts, modifier, keys, json);
            }

            if (type == "notify") {
                string cmd = obj.ValueForKey(new NSString("cmd"))?.ToString() ?? "";
                if (string.IsNullOrEmpty(cmd)) return null;
                return BleCommand.Notify(ts, cmd, json);
            }
        }
        catch { /* skip malformed entries */ }
        return null;
    }
}

// ── Device state — holds discovered characteristics and discovery callbacks ────
//
// FIX: OnReady now fires as soon as the notify characteristic is populated,
// rather than requiring all 3 services to be counted. This prevents the case
// where discovery order or missing optional services causes OnReady to never fire.

class DeviceState {
    public CBCharacteristic? HidReportChar;      // gamepad  — first  0x2A4D found (Report ID 1)
    public CBCharacteristic? KeyboardReportChar; // keyboard — second 0x2A4D found (Report ID 2)
    public CBCharacteristic? MouseCharChar;
    public CBCharacteristic? NotifyCharField;
    public Action<string>?   OnStatus;
    public Action<string>?   OnReady;

    bool _firstHidReportSet;
    bool _readyFired;

    public void HandleDiscoveredService(object? sender, NSErrorEventArgs e) {
        var peripheral = sender as CBPeripheral;
        if (peripheral == null) return;
        if (e.Error != null) { OnStatus?.Invoke($"Service error: {e.Error.LocalizedDescription}"); return; }
        // Discover characteristics for EVERY service — do NOT filter here.
        // The DiscoveredService event fires per-service as iOS finds them, so
        // peripheral.Services may only contain the current service at this moment.
        // Filtering by UUID would skip the Notify service if it fires before Notify
        // is in the list. By requesting all characteristics for whatever service just
        // arrived, we guarantee HandleDiscoveredCharacteristic fires for every service.
        foreach (var svc in peripheral.Services ?? new CBService[0])
            peripheral.DiscoverCharacteristics(null, svc);
    }

    public void HandleDiscoveredCharacteristic(object? sender, CBServiceEventArgs e) {
        if (e.Error != null) return;
        foreach (var ch in e.Service.Characteristics ?? new CBCharacteristic[0]) {
            if (ch.UUID.Equals(Cfg.HidReport)) {
                if (!_firstHidReportSet) { HidReportChar = ch; _firstHidReportSet = true; }
                else KeyboardReportChar = ch;
            }
            if (ch.UUID.Equals(Cfg.MouseChar))  MouseCharChar   = ch;
            if (ch.UUID.Equals(Cfg.NotifyChar)) NotifyCharField = ch;
        }

        // Fire OnReady as soon as NotifyCharField is available.
        // HidReportChar (0x2A4D in HID service 0x1812) is blocked by iOS when the phone
        // is bonded as a system-level BT input device via Settings — iOS intercepts the
        // HID service and CoreBluetooth never sees those characteristics.
        // Gamepad reports are sent as JSON via NotifyCharField instead (see GamepadSender).
        if (!_readyFired && NotifyCharField != null) {
            _readyFired = true;
            OnReady?.Invoke($"Ready — NotifyChar found, relaying from {Cfg.SendFile}");
        }
    }
}

// ── Background relay loop ─────────────────────────────────────────────────────

class Relay {
    readonly CBPeripheral  peripheral;
    readonly DeviceState   devState;
    readonly Action<string> onStatus;
    readonly Action<int>    onCount;

    CancellationTokenSource? cts;
    int totalSent;
    nint bgTask = UIApplication.BackgroundTaskInvalid;

    public Relay(CBPeripheral p, DeviceState d,
                 Action<string> status, Action<int> count) {
        peripheral  = p;
        devState    = d;
        onStatus    = status;
        onCount     = count;
    }

    public void Start() {
        cts = new CancellationTokenSource();
        Task.Run(() => Loop(cts.Token));
        onStatus("Relay started — watching " + Cfg.SendFile);
    }

    public void Stop() {
        cts?.Cancel();
        EndBgTask();
        onStatus("Relay stopped.");
    }

    void Loop(CancellationToken token) {
        while (!token.IsCancellationRequested) {
            BeginBgTask();

            var commands = SendFileReader.Read(Cfg.SendFile);
            if (commands.Count > 0) {
                var sent = new HashSet<string>();
                foreach (var cmd in commands) {
                    if (token.IsCancellationRequested) break;
                    bool ok = WriteCommand(cmd);
                    if (ok) { sent.Add(cmd.Raw); totalSent++; }
                }
                SendFileReader.ClearSent(Cfg.SendFile, sent);
                InvokeOnMain(() => {
                    onStatus($"Sent {commands.Count} cmd(s) — {totalSent} total");
                    onCount(totalSent);
                });
            }

            Thread.Sleep(TimeSpan.FromSeconds(Cfg.PollInterval));
        }
        EndBgTask();
    }

    bool WriteCommand(BleCommand cmd) {
        CBCharacteristic? ch = null;

        if (cmd.Type == "keyboard")  ch = devState.KeyboardReportChar;
        if (cmd.Type == "mouse")     ch = devState.MouseCharChar;
        if (cmd.Type == "notify")    ch = devState.NotifyCharField;

        // Gamepad: iOS blocks CoreBluetooth access to HID service (0x1812) characteristics
        // when the phone is bonded as a system-level BT device via Settings, so HidReportChar
        // is never discovered. Send as JSON via NotifyCharField instead — MyAutomationService
        // on Android parses {"type":"gamepad","report":[...]} and calls BtGamepad.sendReport().
        if (cmd.Type == "gamepad") {
            if (devState.NotifyCharField == null || cmd.Bytes == null) return false;
            var report = string.Join(",", cmd.Bytes.Select(b => (int)b));
            var json   = $"{{\"type\":\"gamepad\",\"report\":[{report}]}}";
            var gdata  = NSData.FromArray(System.Text.Encoding.UTF8.GetBytes(json));
            InvokeOnMain(() => peripheral.WriteValue(gdata, devState.NotifyCharField,
                CBCharacteristicWriteType.WithResponse));
            return true;
        }

        if (ch == null || cmd.Bytes == null) return false;

        var data = NSData.FromArray(cmd.Bytes);
        // FIX: notify writes must use WithResponse because Android CHR_NOTIFY_IN
        // is declared with PERMISSION_WRITE (not WRITE_NO_RESPONSE). Using
        // WithoutResponse causes the packet to be silently dropped by the Android stack.
        var writeType = (cmd.Type == "notify")
            ? CBCharacteristicWriteType.WithResponse
            : CBCharacteristicWriteType.WithoutResponse;
        InvokeOnMain(() => peripheral.WriteValue(data, ch, writeType));
        return true;
    }

    void BeginBgTask() {
        InvokeOnMain(() => {
            if (bgTask != UIApplication.BackgroundTaskInvalid) return;
            bgTask = UIApplication.SharedApplication.BeginBackgroundTask("SharpBlueRelay",
                () => { EndBgTask(); });
        });
    }

    void EndBgTask() {
        InvokeOnMain(() => {
            if (bgTask == UIApplication.BackgroundTaskInvalid) return;
            UIApplication.SharedApplication.EndBackgroundTask(bgTask);
            bgTask = UIApplication.BackgroundTaskInvalid;
        });
    }

    static void InvokeOnMain(Action a) =>
        DispatchQueue.MainQueue.DispatchAsync(a);
}

// ─────────────────────────────────────────────────────────────────────────────
// PS4-style Gamepad Screen
//
// Architecture:
//   GamepadView       — custom UIView; owns all nodes and touch logic.
//   GamepadController — UIViewController; pushed fullscreen by BlueController.
//
// Nodes:
//   Background node : GamepadView itself (dark canvas, fills the screen).
//   Button node     : square UIView (the "node") + UIImageView same size (img bg,
//                     len & width = button frame) + UILabel. Hit-tested with
//                     PointInPolygon (see below).
//   Joystick node   : circular UIView + thumb UIView. Hit by radial distance.
//   Trigger node    : vertical bar UIView + fill UIView. Hit by CGRect.Contains.
//
// HID report (9 bytes) — matches ble_gamepad.py build_report():
//   [0] LX  [1] LY  [2] RX  [3] RY  [4] L2  [5] R2
//   [6] hat & 0x0F
//   [7] btn bits 0–7  : Square Cross Circle Triangle L1 R1 L2btn R2btn
//   [8] btn bits 8–13 : Share Options L3 R3 PS Touchpad
// ─────────────────────────────────────────────────────────────────────────────

// ── PointInPolygon — ray-casting, direct C# port of Python version ────────────
//
// Python original (from ble_gamepad.py / user prompt):
//
//   def point_in_polygon(point, polygon):
//       num_vertices = len(polygon)
//       x, y = point.x, point.y
//       inside = False
//       p1 = polygon[0]
//       for i in range(1, num_vertices + 1):
//           p2 = polygon[i % num_vertices]
//           if y > min(p1.y, p2.y):
//               if y <= max(p1.y, p2.y):
//                   if x <= max(p1.x, p2.x):
//                       x_intersection = (y - p1.y) * (p2.x - p1.x) / (p2.y - p1.y) + p1.x
//                       if p1.x == p2.x or x <= x_intersection:
//                           inside = not inside
//           p1 = p2
//       return inside

static class PolygonHit {
    /// <summary>
    /// Returns true if <paramref name="pt"/> lies inside <paramref name="poly"/>.
    /// Direct C# port of the Python point_in_polygon ray-casting function.
    /// </summary>
    public static bool Test(CGPoint pt, CGPoint[] poly) {
        int    n      = poly.Length;
        nfloat x      = pt.X, y = pt.Y;
        bool   inside = false;
        var    p1     = poly[0];

        for (int i = 1; i <= n; i++) {
            var    p2   = poly[i % n];
            nfloat minY = p1.Y < p2.Y ? p1.Y : p2.Y;
            nfloat maxY = p1.Y > p2.Y ? p1.Y : p2.Y;
            nfloat maxX = p1.X > p2.X ? p1.X : p2.X;

            if (y > minY && y <= maxY && x <= maxX) {
                // x-intersection of the edge with the horizontal ray
                nfloat xi = (y - p1.Y) * (p2.X - p1.X) / (p2.Y - p1.Y) + p1.X;
                if (p1.X == p2.X || x <= xi)
                    inside = !inside;
            }
            p1 = p2;
        }
        return inside;
    }

    /// Build a 4-point polygon (clockwise from top-left) from a CGRect.
    public static CGPoint[] FromRect(CGRect r) => new[] {
        new CGPoint(r.Left,  r.Top),
        new CGPoint(r.Right, r.Top),
        new CGPoint(r.Right, r.Bottom),
        new CGPoint(r.Left,  r.Bottom),
    };
}

// ── Gamepad HID state — mirrors ble_gamepad.py 'state' dict ──────────────────

class GamepadState {
    public int    Lx = 128, Ly = 128;   // left stick  0-255 (centre=128)
    public int    Rx = 128, Ry = 128;   // right stick 0-255 (centre=128)
    public int    L2 = 0,   R2 = 0;     // analog triggers 0-255
    public int    Hat = 8;              // 0=N 1=NE 2=E 3=SE 4=S 5=SW 6=W 7=NW 8=none
    public bool[] Btns = new bool[14];  // sq cr ci tr L1 R1 L2b R2b Share Opt L3 R3 PS TP

    /// 9-byte report matching ble_gamepad.py build_report()
    public int[] BuildReport() {
        int bits = 0;
        for (int i = 0; i < 14; i++) if (Btns[i]) bits |= (1 << i);
        return new[] {
            Lx, Ly, Rx, Ry, L2, R2,
            Hat & 0x0F,
            bits & 0xFF,
            (bits >> 8) & 0x3F,
        };
    }
}

// ── Direct BLE gamepad sender ─────────────────────────────────────────────────
// Sends a 9-int gamepad report to the Android phone via the NotifyCharField
// as a JSON string: {"type":"gamepad","report":[b0..b8]}
// MyAutomationService on Android parses this and calls BtGamepad.sendReport().
//
// NOTE: we do NOT write raw bytes to HidReportChar (0x2A4D / HID service 0x1812)
// because iOS blocks CoreBluetooth access to HID service characteristics when the
// phone is bonded at OS level via Settings — those chars are never discovered.

static class GamepadSender {
    // Returns true if the write was dispatched without throwing, false on error.
    public static bool SendDirect(CBPeripheral    peripheral,
                                  CBCharacteristic notifyChar,
                                  int[]            reportSnapshot) {
        try {
            var report  = string.Join(",", reportSnapshot);
            var json    = $"{{\"type\":\"gamepad\",\"report\":[{report}]}}";
            var data    = NSData.FromArray(System.Text.Encoding.UTF8.GetBytes(json));
            DispatchQueue.MainQueue.DispatchAsync(() =>
                peripheral.WriteValue(data, notifyChar,
                    CBCharacteristicWriteType.WithResponse));
            return true;
        } catch (Exception ex) {
            Console.WriteLine($"[GamepadSender] SendDirect error: {ex.Message}");
            return false;
        }
    }
}

// ── GamepadView — full-screen node canvas with PS4-style layout ───────────────

class GamepadView : UIView {

    // ── Node descriptors ──────────────────────────────────────────────────────

    class BtnNode {
        public int        BtnIdx;    // index in GamepadState.Btns; -1 = not a regular btn
        public int        DpadDir;   // hat direction 0-8; -1 = not a d-pad button
        public CGRect     Frame;     // position in GamepadView coords
        public CGPoint[]  Polygon;   // 4-corner polygon for PointInPolygon hit test
        public UIView     Bg;        // square background "node"
        public UIImageView ImgBg;   // image view same size as Bg  ← "img len and width"
        public UILabel    Lbl;
        public Action?    OnTap;     // set for standalone action buttons (BtnIdx/DpadDir both -1);
                                      // fires once per tap instead of participating in the HID report.
    }

    class JsNode {
        public bool     IsLeft;
        public CGRect   Frame;
        public CGPoint  Center;
        public UIView   Bg;     // circular background node (square frame, rounded to circle)
        public UIView   Thumb;  // thumb indicator
    }

    class TrigNode {
        public bool    IsLeft;
        public CGRect  Frame;
        public UIView  Bg;
        public UIView  Fill;
    }

    // ── Instance data ─────────────────────────────────────────────────────────

    readonly List<BtnNode>           _btns       = new();
    JsNode                           _ljs, _rjs;
    TrigNode                         _l2t, _r2t;
    readonly GamepadState            _st         = new();
    readonly Dictionary<int, string> _tm         = new();  // GetHashCode() → control-id
    readonly Dictionary<int, int>    _dpadTouches = new(); // GetHashCode() → hat-dir
    UILabel?                         _log;       // bottom status bar
    int                              _sentCount;
    // Tracks all currently-active d-pad touch-keys so releasing one touch
    // only resets Hat when no other d-pad touch is still held.

    /// Set by GamepadController so the Close button can pop the stack.
    public Action? OnClose;

    readonly CBPeripheral?      _peripheral;
    readonly CBCharacteristic?  _notifyChar;   // NotifyCharField — used for JSON gamepad commands

    public GamepadView(CBPeripheral?      peripheral  = null,
                       CBCharacteristic?  notifyChar  = null) : base(CGRect.Empty) {
        _peripheral  = peripheral;
        _notifyChar  = notifyChar;
        BackgroundColor        = UIColor.Black;
        MultipleTouchEnabled   = true;
        UserInteractionEnabled = true;
        // Build() is NOT called here — frame is still empty.
        // GamepadController calls BuildLayout() from ViewDidAppear when bounds are final.
    }

    // Called by GamepadController.ViewDidAppear with the real screen bounds.
    public void BuildLayout(CGRect screenBounds) {
        Frame = screenBounds;
        Build();
    }

    // Block all gesture recognizers (nav bar swipe/tap, interactive pop, etc.)
    // so raw UITouch events reach our TouchesBegan/Moved/Ended overrides.
    public override bool GestureRecognizerShouldBegin(UIGestureRecognizer g) => false;

    // ── Layout ────────────────────────────────────────────────────────────────

    void Build() {
        nfloat W   = Bounds.Width;
        nfloat H   = Bounds.Height;
        nfloat top = 44;
        nfloat mid = H / 2;
        nfloat pad = 12;
        nfloat jsS = (nfloat)Math.Min(W * 0.28, 130);  // joystick diameter

        // Status label — shows whether we have a live BLE link or not
        var modeText = (_peripheral != null && _notifyChar != null)
            ? "BLE via Notify ✓"
            : NazServer.HasSubscribers
                ? "BLE via nazcontrollerTwo ✓"
                : "No BLE — connect first";
        var modeColor = (_peripheral != null && _notifyChar != null) || NazServer.HasSubscribers
            ? UIColor.Green : UIColor.Red;
        MkLabel(modeText,
            new CGRect(70, 8, W - 140, 28), 11, modeColor)
            .TextAlignment = UITextAlignment.Center;

        // ✕ Close / back button
        var closeBtn = UIButton.FromType(UIButtonType.System);
        closeBtn.Frame = new CGRect(W - 68, 8, 62, 28);
        closeBtn.SetTitle("✕ Back", UIControlState.Normal);
        closeBtn.SetTitleColor(UIColor.FromRGB(0xff, 0x66, 0x66), UIControlState.Normal);
        closeBtn.TouchUpInside += (s, e) => OnClose?.Invoke();
        AddSubview(closeBtn);

        // ── Left joystick ─────────────────────────────────────────────────────
        _ljs = MkJs(new CGRect(pad, mid - jsS / 2, jsS, jsS), isLeft: true);

        // ── Right joystick ────────────────────────────────────────────────────
        nfloat rjsX = W - pad - jsS;
        _rjs = MkJs(new CGRect(rjsX, mid - jsS / 2, jsS, jsS), isLeft: false);

        // ── L2 / R2 analog triggers ───────────────────────────────────────────
        _l2t = MkTrig(new CGRect(pad, top + 4, 44, 90), isLeft: true,  "L2");
        _r2t = MkTrig(new CGRect(W - pad - 44, top + 4, 44, 90), isLeft: false, "R2");

        // ── L1 / R1 ───────────────────────────────────────────────────────────
        MkBtn("L1", 4, -1,
              new CGRect(pad + 44 + 8, top + 4, 70, 36),
              UIColor.FromRGB(0x55, 0x55, 0x55));
        MkBtn("R1", 5, -1,
              new CGRect(W - pad - 44 - 78, top + 4, 70, 36),
              UIColor.FromRGB(0x55, 0x55, 0x55));

        // ── L2btn / R2btn (digital trigger buttons) ───────────────────────────
        MkBtn("L2▼", 6, -1,
              new CGRect(pad, top + 98, 44, 28),
              UIColor.FromRGB(0x44, 0x44, 0x44));
        MkBtn("R2▼", 7, -1,
              new CGRect(W - pad - 44, top + 98, 44, 28),
              UIColor.FromRGB(0x44, 0x44, 0x44));

        // ── D-pad ─────────────────────────────────────────────────────────────
        nfloat dpCx = pad + jsS + 60;
        nfloat dpCy = top + 70;
        nfloat dpR  = 28;
        // hat value, normalised offset (dx,dy), label
        var dpDirs = new (int h, nfloat dx, nfloat dy, string lbl)[] {
            (0,  0, -1, "U"),  (1,  1, -1, "UR"), (2,  1,  0, "R"),  (3,  1,  1, "DR"),
            (4,  0,  1, "D"),  (5, -1,  1, "DL"), (6, -1,  0, "L"),  (7, -1, -1, "UL"),
        };
        foreach (var (h, dx, dy, lbl) in dpDirs) {
            nfloat bx = dpCx + dx * dpR * (nfloat)1.55 - 22;
            nfloat by = dpCy + dy * dpR * (nfloat)1.55 - 22;
            MkBtn(lbl, -1, h, new CGRect(bx, by, 44, 44), UIColor.FromRGB(0x44, 0x44, 0x44));
        }
        // D-pad centre — neutral (hat=8)
        MkBtn("·", -1, 8, new CGRect(dpCx - 15, dpCy - 15, 30, 30),
              UIColor.FromRGB(0x33, 0x33, 0x33));

        // ── Face buttons (Triangle=top, Circle=right, Cross=bottom, Square=left)
        nfloat fcCx = W - pad - jsS - 60;
        nfloat fcCy = top + 70;
        var face = new (string lbl, int idx, UIColor col, nfloat dx, nfloat dy)[] {
            ("△", 3, UIColor.FromRGB(0x33, 0xaa, 0x66),  0, -1),
            ("○", 2, UIColor.FromRGB(0xcc, 0x44, 0x44),  1,  0),
            ("✕", 1, UIColor.FromRGB(0x33, 0x77, 0xcc),  0,  1),
            ("□", 0, UIColor.FromRGB(0x99, 0x66, 0xcc), -1,  0),
        };
        foreach (var (lbl, idx, col, dx, dy) in face)
            MkBtn(lbl, idx, -1, new CGRect(fcCx + dx * 38 - 22, fcCy + dy * 38 - 22, 44, 44), col);

        // ── Share / Options ───────────────────────────────────────────────────
        MkBtn("Share",   8, -1, new CGRect(W / 2 - 76, top + 8, 70, 32),
              UIColor.FromRGB(0x33, 0x33, 0x33));
        MkBtn("Options", 9, -1, new CGRect(W / 2 + 6, top + 8, 70, 32),
              UIColor.FromRGB(0x33, 0x33, 0x33));

        // ── PS (round) ────────────────────────────────────────────────────────
        var psNode = MkBtn("PS", 12, -1, new CGRect(W / 2 - 25, mid - 25, 50, 50),
                           UIColor.FromRGB(0xcc, 0x88, 0x00));
        psNode.Bg.Layer.CornerRadius = 25;

        // ── 🍌 Golden Banana (action button) ─────────────────────────────────
        // Sits between Share/Options and the PS button. Not part of the HID
        // report — tapping it fires pswon.csx's Pswon.Show() instead.
        MkBtn("", -1, -1, new CGRect(W / 2 - 25, top + 48, 50, 50),
              UIColor.FromRGB(0x22, 0x22, 0x22),
              imageName: "GoldenBanana.png",
              onTap: () => Pswon.Show(this));

        // ── Touchpad ──────────────────────────────────────────────────────────
        MkBtn("Touch\npad", 13, -1, new CGRect(W / 2 - 40, mid + 36, 80, 44),
              UIColor.FromRGB(0x33, 0x44, 0x55));

        // ── L3 / R3 (tap-stick) ───────────────────────────────────────────────
        MkBtn("L3", 10, -1,
              new CGRect(pad + jsS / 2 - 22, mid + jsS / 2 + 8, 44, 24),
              UIColor.FromRGB(0x33, 0x33, 0x44));
        MkBtn("R3", 11, -1,
              new CGRect(rjsX + jsS / 2 - 22, mid + jsS / 2 + 8, 44, 24),
              UIColor.FromRGB(0x33, 0x33, 0x44));

        // Axis labels
        MkLabel("LEFT STICK",  new CGRect(pad,  mid - jsS / 2 - 18, jsS, 16), 9, UIColor.DarkGray);
        MkLabel("RIGHT STICK", new CGRect(rjsX, mid - jsS / 2 - 18, jsS, 16), 9, UIColor.DarkGray);

        // ── Bottom status bar ─────────────────────────────────────────────────
        var logBg = new UIView(new CGRect(0, H - 28, W, 28)) {
            BackgroundColor = UIColor.FromRGB(0x10, 0x10, 0x10)
        };
        AddSubview(logBg);
        _log = new UILabel(new CGRect(8, H - 26, W - 16, 22)) {
            Text          = "No commands sent yet",
            TextColor     = UIColor.FromRGB(0x88, 0x88, 0x88),
            Font          = UIFont.FromName("Courier", 11) ?? UIFont.SystemFontOfSize(11),
            TextAlignment = UITextAlignment.Left,
        };
        AddSubview(_log);
    }

    // ── Node factories ────────────────────────────────────────────────────────

    JsNode MkJs(CGRect frame, bool isLeft) {
        // Background node — square frame, rounded into a circle
        var bg = new UIView(frame) { BackgroundColor = UIColor.FromRGB(0x22, 0x22, 0x22) };
        bg.Layer.CornerRadius = frame.Width / 2;
        bg.Layer.BorderColor  = UIColor.FromRGB(0x44, 0x44, 0x44).CGColor;
        bg.Layer.BorderWidth  = 1;
        AddSubview(bg);

        // Crosshair guides
        var hLine = new UIView(new CGRect(8, frame.Height / 2 - (nfloat)0.5, frame.Width - 16, 1))
            { BackgroundColor = UIColor.FromRGB(0x33, 0x33, 0x33) };
        var vLine = new UIView(new CGRect(frame.Width / 2 - (nfloat)0.5, 8, 1, frame.Height - 16))
            { BackgroundColor = UIColor.FromRGB(0x33, 0x33, 0x33) };
        bg.AddSubview(hLine);
        bg.AddSubview(vLine);

        // Thumb
        nfloat tr = 18;
        var thumb = new UIView(new CGRect(frame.Width / 2 - tr, frame.Height / 2 - tr, tr * 2, tr * 2)) {
            BackgroundColor = UIColor.FromRGB((byte)0x44, (byte)0x66, isLeft ? (byte)0x99 : (byte)0xbb),
        };
        thumb.Layer.CornerRadius = tr;
        bg.AddSubview(thumb);

        return new JsNode {
            IsLeft = isLeft, Frame = frame, Bg = bg, Thumb = thumb,
            Center = new CGPoint(frame.GetMidX(), frame.GetMidY()),
        };
    }

    TrigNode MkTrig(CGRect frame, bool isLeft, string lbl) {
        var bg = new UIView(frame) { BackgroundColor = UIColor.FromRGB(0x22, 0x22, 0x22) };
        bg.Layer.CornerRadius = 8;
        AddSubview(bg);

        var fill = new UIView(new CGRect(4, frame.Height - 4, frame.Width - 8, 0)) {
            BackgroundColor = isLeft
                ? UIColor.FromRGB(0x88, 0x22, 0x22)
                : UIColor.FromRGB(0x22, 0x22, 0x88),
        };
        bg.AddSubview(fill);

        var label = new UILabel(new CGRect(0, 2, frame.Width, 14)) {
            Text = lbl, Font = UIFont.SystemFontOfSize(9),
            TextColor = UIColor.DarkGray, TextAlignment = UITextAlignment.Center,
        };
        bg.AddSubview(label);

        return new TrigNode { IsLeft = isLeft, Frame = frame, Bg = bg, Fill = fill };
    }

    // `imageName` (optional) loads a real texture from assets/ over the placeholder
    // tint. `onTap` (optional) turns this into a standalone action button — BtnIdx
    // and dpadDir should both be -1 in that case; it fires once per tap instead of
    // participating in the HID report / hold-state machinery.
    BtnNode MkBtn(string lbl, int btnIdx, int dpadDir, CGRect frame, UIColor color,
                  string? imageName = null, Action? onTap = null) {
        // ── Background square "node" ──────────────────────────────────────────
        var bg = new UIView(frame) { BackgroundColor = color, ClipsToBounds = true };
        bg.Layer.CornerRadius = 8;
        bg.Layer.BorderColor  = UIColor.FromRGB(0x55, 0x55, 0x55).CGColor;
        bg.Layer.BorderWidth  = (nfloat)0.5;
        AddSubview(bg);

        // ── Image view — same len & width as bg node (placeholder for artwork) ─
        var imgBg = new UIImageView(bg.Bounds) {
            ContentMode   = UIViewContentMode.ScaleAspectFill,
            ClipsToBounds = true,
            Alpha         = (nfloat)0.12,   // subtle; set .Image to show button art
        };
        if (imageName != null) {
            imgBg.Image       = Assets.Load(imageName);
            imgBg.ContentMode = UIViewContentMode.ScaleAspectFit;
            imgBg.Alpha       = 1;
        }
        bg.AddSubview(imgBg);

        // ── Label ─────────────────────────────────────────────────────────────
        nfloat fs = lbl.Length <= 2 ? 15 : 10;
        var label = new UILabel(bg.Bounds) {
            Text          = lbl,
            Font          = UIFont.BoldSystemFontOfSize(fs),
            TextColor     = UIColor.White,
            TextAlignment = UITextAlignment.Center,
            Lines         = 2,
        };
        bg.AddSubview(label);

        var node = new BtnNode {
            BtnIdx  = btnIdx,
            DpadDir = dpadDir,
            Frame   = frame,
            Polygon = PolygonHit.FromRect(frame),   // ← polygon used by PointInPolygon
            Bg      = bg,
            ImgBg   = imgBg,
            Lbl     = label,
            OnTap   = onTap,
        };
        _btns.Add(node);
        return node;
    }

    UILabel MkLabel(string text, CGRect frame, nfloat size, UIColor color) {
        var l = new UILabel(frame) {
            Text          = text,
            Font          = UIFont.SystemFontOfSize(size),
            TextColor     = color,
            TextAlignment = UITextAlignment.Center,
            Lines         = 0,
        };
        AddSubview(l);
        return l;
    }

    // ── Visual helpers ────────────────────────────────────────────────────────

    void HighlightBtn(BtnNode btn, bool on) {
        DispatchQueue.MainQueue.DispatchAsync(() => {
            btn.Bg.Layer.BorderWidth = on ? (nfloat)2.5 : (nfloat)0.5;
            btn.Bg.Layer.BorderColor = on
                ? UIColor.White.CGColor
                : UIColor.FromRGB(0x55, 0x55, 0x55).CGColor;
        });
    }

    void MoveThumb(JsNode js, nfloat nx, nfloat ny) {
        nfloat r  = js.Frame.Width / 2 - 20;
        nfloat sz = 36;
        nfloat tx = js.Frame.Width  / 2 + nx * r - sz / 2;
        nfloat ty = js.Frame.Height / 2 + ny * r - sz / 2;
        DispatchQueue.MainQueue.DispatchAsync(() =>
            js.Thumb.Frame = new CGRect(tx, ty, sz, sz));
    }

    void UpdateFill(TrigNode tr, nfloat value) {
        nfloat barH  = tr.Frame.Height - 8;
        nfloat fillH = barH * value;
        DispatchQueue.MainQueue.DispatchAsync(() =>
            tr.Fill.Frame = new CGRect(4, tr.Frame.Height - 4 - fillH, tr.Frame.Width - 8, fillH));
    }

    // ── Multi-touch handling ──────────────────────────────────────────────────

    public override void TouchesBegan(NSSet touches, UIEvent? evt) {
        foreach (var touch in touches.Cast<UITouch>()) {
            var loc = touch.LocationInView(this);
            int key = touch.GetHashCode();

            // 1. Joysticks — radial distance
            if (HitJs(loc, _ljs)) { _tm[key] = "ljs"; ApplyJs(loc, _ljs); continue; }
            if (HitJs(loc, _rjs)) { _tm[key] = "rjs"; ApplyJs(loc, _rjs); continue; }

            // 2. Triggers — rect
            if (_l2t.Frame.Contains(loc)) { _tm[key] = "l2t"; ApplyTrig(loc, _l2t); continue; }
            if (_r2t.Frame.Contains(loc)) { _tm[key] = "r2t"; ApplyTrig(loc, _r2t); continue; }

            // 3. Buttons — PointInPolygon
            foreach (var btn in _btns) {
                if (!PolygonHit.Test(loc, btn.Polygon)) continue;

                // Standalone action buttons (e.g. 🍌) fire once and don't
                // participate in the held-state HID report machinery.
                if (btn.OnTap != null) {
                    HighlightBtn(btn, true);
                    btn.OnTap.Invoke();
                    DispatchQueue.MainQueue.DispatchAfter(
                        new DispatchTime(DispatchTime.Now, 150_000_000),
                        () => HighlightBtn(btn, false));
                    break;
                }

                if (btn.DpadDir >= 0) {
                    _tm[key]          = $"dpad{btn.DpadDir}";
                    _dpadTouches[key] = btn.DpadDir;   // register d-pad touch
                    _st.Hat           = btn.DpadDir;   // last pressed wins
                } else if (btn.BtnIdx >= 0) {
                    _tm[key] = $"btn{btn.BtnIdx}";
                    _st.Btns[btn.BtnIdx] = true;
                }
                HighlightBtn(btn, true);
                SendBg();
                break;
            }
        }
    }

    public override void TouchesMoved(NSSet touches, UIEvent? evt) {
        foreach (var touch in touches.Cast<UITouch>()) {
            var loc = touch.LocationInView(this);
            int key = touch.GetHashCode();
            if (!_tm.TryGetValue(key, out var ctrl)) continue;

            if (ctrl == "ljs") { ApplyJs(loc, _ljs); continue; }
            if (ctrl == "rjs") { ApplyJs(loc, _rjs); continue; }
            if (ctrl == "l2t") { ApplyTrig(loc, _l2t); continue; }
            if (ctrl == "r2t") { ApplyTrig(loc, _r2t); continue; }
        }
    }

    public override void TouchesEnded(NSSet touches, UIEvent? evt)      => Release(touches);
    public override void TouchesCancelled(NSSet touches, UIEvent? evt)  => Release(touches);

    void Release(NSSet touches) {
        foreach (var touch in touches.Cast<UITouch>()) {
            int key = touch.GetHashCode();
            if (!_tm.TryGetValue(key, out var ctrl)) continue;
            _tm.Remove(key);

            if (ctrl == "ljs") {
                _st.Lx = 128; _st.Ly = 128; MoveThumb(_ljs, 0, 0); SendBg(); continue;
            }
            if (ctrl == "rjs") {
                _st.Rx = 128; _st.Ry = 128; MoveThumb(_rjs, 0, 0); SendBg(); continue;
            }
            if (ctrl == "l2t") { _st.L2 = 0; UpdateFill(_l2t, 0); SendBg(); continue; }
            if (ctrl == "r2t") { _st.R2 = 0; UpdateFill(_r2t, 0); SendBg(); continue; }

            if (ctrl.StartsWith("btn") && int.TryParse(ctrl.Substring(3), out int bi)) {
                _st.Btns[bi] = false;
                var bn = _btns.FirstOrDefault(b => b.BtnIdx == bi);
                if (bn != null) HighlightBtn(bn, false);
                SendBg();
                continue;
            }
            if (ctrl.StartsWith("dpad") && int.TryParse(ctrl.Substring(4), out int di)) {
                _dpadTouches.Remove(key);
                // Only neutralise hat when ALL d-pad touches have lifted
                if (_dpadTouches.Count == 0)
                    _st.Hat = 8;
                else
                    _st.Hat = _dpadTouches.Values.Last();  // fall back to last remaining dir
                var dn = _btns.FirstOrDefault(b => b.DpadDir == di);
                if (dn != null) HighlightBtn(dn, false);
                SendBg();
            }
        }
    }

    // ── Input application ─────────────────────────────────────────────────────

    bool HitJs(CGPoint loc, JsNode js) {
        nfloat dx = loc.X - js.Center.X, dy = loc.Y - js.Center.Y;
        nfloat r  = js.Frame.Width / 2;
        return dx * dx + dy * dy <= r * r;
    }

    void ApplyJs(CGPoint loc, JsNode js) {
        nfloat r  = js.Frame.Width / 2 - 20;
        nfloat nx = (loc.X - js.Center.X) / r;
        nfloat ny = (loc.Y - js.Center.Y) / r;
        if (nx < -1) nx = -1; else if (nx > 1) nx = 1;
        if (ny < -1) ny = -1; else if (ny > 1) ny = 1;
        int vx = (int)((nx + 1) / 2 * 255);
        int vy = (int)((ny + 1) / 2 * 255);
        if (js.IsLeft) { _st.Lx = vx; _st.Ly = vy; } else { _st.Rx = vx; _st.Ry = vy; }
        MoveThumb(js, nx, ny);
        SendBg();
    }

    void ApplyTrig(CGPoint loc, TrigNode tr) {
        nfloat barH = tr.Frame.Height - 8;
        nfloat relY = loc.Y - tr.Frame.Top - 4;
        nfloat val  = 1 - relY / barH;
        if (val < 0) val = 0; else if (val > 1) val = 1;
        int v = (int)(val * 255);
        if (tr.IsLeft) _st.L2 = v; else _st.R2 = v;
        UpdateFill(tr, val);
        SendBg();
    }

    // Snapshot the report bytes on the UI thread, then fire-and-forget the write.
    // If a live BLE link is available, calls peripheral.WriteValue directly.
    // Silently no-ops when no peripheral or characteristic is present (not connected).
    void SendBg() {
        var count    = ++_sentCount;
        var snapshot = _st.BuildReport();
        var arr      = string.Join(",", snapshot);

        // Always update the label so touches are visible even without BLE.
        bool hasNotify = _peripheral != null && _notifyChar != null;
        bool hasServer = NazServer.HasSubscribers;
        if (!hasNotify && !hasServer) {
            if (_log != null) {
                _log.Text      = $"✗ #{count}  no BLE connection";
                _log.TextColor = UIColor.Red;
            }
            return;
        }

        Task.Run(() => {
            bool ok = false;
            // Path 1: iPad connected TO phone (central → phone's NotifyChar)
            if (hasNotify)
                ok = GamepadSender.SendDirect(_peripheral!, _notifyChar!, snapshot);
            // Path 2: phone connected TO iPad (NazServer → subscribed centrals)
            if (hasServer)
                ok |= NazServer.SendGamepadReport(snapshot);
            DispatchQueue.MainQueue.DispatchAsync(() => {
                if (_log != null) {
                    _log.Text      = ok
                        ? $"✓ #{count}  [{arr}]"
                        : $"✗ #{count}  send failed";
                    _log.TextColor = ok ? UIColor.Green : UIColor.Red;
                }
            });
        });
    }

    // ── Generic "action|data" command send (used by pswon.csx pause menu) ──────
    //
    // Same wire format/path as SendHello / Relay's "notify" commands (COMMAND_REFERENCE.md):
    // writes a UTF-8 "action|data" string straight to NotifyCharField. Returns false
    // (no-op) when there's no live peripheral/characteristic — callers should show that
    // to the user rather than pretend it worked.
    public bool SendRawCommand(string action, string data) {
        if (_peripheral == null || _notifyChar == null) return false;
        var payload = string.IsNullOrEmpty(data) ? action : $"{action}|{data}";
        var bytes   = Encoding.UTF8.GetBytes(payload);
        _peripheral.WriteValue(NSData.FromArray(bytes), _notifyChar, CBCharacteristicWriteType.WithResponse);
        return true;
    }

    public bool HasLiveConnection => _peripheral != null && _notifyChar != null;
}

// ── GamepadController — pushes GamepadView as a fullscreen screen ─────────────

class GamepadController : UIViewController {
    GamepadView? _gv;
    readonly CBPeripheral?      _peripheral;
    readonly CBCharacteristic?  _notifyChar;

    public GamepadController(CBPeripheral?     peripheral  = null,
                             CBCharacteristic? notifyChar  = null) {
        _peripheral = peripheral;
        _notifyChar = notifyChar;
    }

    // Hide the status bar so the gamepad truly fills every pixel.
    public override bool PrefersStatusBarHidden() => true;

    public override void ViewDidLoad() {
        base.ViewDidLoad();
        View!.BackgroundColor = UIColor.Black;
        _gv = new GamepadView(_peripheral, _notifyChar);
        _gv.AutoresizingMask = UIViewAutoresizing.FlexibleWidth | UIViewAutoresizing.FlexibleHeight;
        _gv.OnClose = () => DismissViewController(true, null);
        View.AddSubview(_gv);
    }

    public override void ViewDidAppear(bool animated) {
        base.ViewDidAppear(animated);
        // View.Bounds is guaranteed final here — build the layout now.
        _gv?.BuildLayout(View.Bounds);
    }
}

// ── Table source for discovered peripherals ───────────────────────────────────

class DeviceSource : UITableViewSource {
    readonly List<(CBPeripheral p, NSNumber rssi)> items;
    readonly string target;

    public DeviceSource(List<(CBPeripheral, NSNumber)> items, string target) {
        this.items  = items;
        this.target = target;
    }

    public override nint NumberOfSections(UITableView tv) => 1;
    public override nint RowsInSection(UITableView tv, nint s) => items.Count;

    public override string[]  SectionIndexTitles(UITableView tv) => new string[0];
    public override string    TitleForHeader(UITableView tv, nint s) => null;
    public override string    TitleForFooter(UITableView tv, nint s) => null;
    public override nfloat    EstimatedHeight(UITableView tv, NSIndexPath ip) => 44f;
    public override nfloat    GetHeightForRow(UITableView tv, NSIndexPath ip) => UITableView.AutomaticDimension;
    public override nfloat    EstimatedHeightForFooter(UITableView tv, nint s) => 0f;
    public override nfloat    EstimatedHeightForHeader(UITableView tv, nint s) => 0f;

    public override UITableViewCell GetCell(UITableView tv, NSIndexPath ip) {
        var cell = tv.DequeueReusableCell("c") ??
                   new UITableViewCell(UITableViewCellStyle.Subtitle, "c");
        var (p, rssi) = items[ip.Row];
        bool isTarget = p.Name == target;
        cell.TextLabel.Text       = string.IsNullOrEmpty(p.Name) ? "(unnamed)" : p.Name;
        cell.DetailTextLabel.Text = $"RSSI {rssi} dBm  ·  {p.Identifier}";
        cell.TextLabel.TextColor  = isTarget ? Cfg.Good : UIColor.LabelColor;
        cell.TextLabel.Font       = isTarget
            ? UIFont.BoldSystemFontOfSize(16)
            : UIFont.SystemFontOfSize(16);
        return cell;
    }
}

// ── NazServer — iPad advertises as "nazcontrollerTwo" (CBPeripheralManager) ───
//
// When active the iPad acts as a BLE peripheral.  The Android phone connects as
// a BLE central, discovers NazTwoChar, and subscribes to notifications.
// GamepadSender.SendBg() calls NazServer.SendGamepadReport() which pushes the
// JSON {"type":"gamepad","report":[...]} to every subscribed central.
// MyAutomationService on Android receives it via the same CHR_NOTIFY_IN path and
// dispatches it through dispatchBlueCommand → BtGamepad.sendReport + GamepadInjector.

static class NazServer {

    static CBPeripheralManager?     _pm;
    static CBMutableCharacteristic? _char;
    static Action<string>?          _onStatus;

    // Tracks centrals that have subscribed to notifications.
    static readonly List<CBCentral> _subs = new();

    // Latest report that failed to send due to CBPeripheralManager backpressure.
    // Drained when ReadyToUpdateSubscribers fires.  Stored as a pre-encoded NSData
    // so we avoid re-allocating on the hot path.
    static volatile NSData? _pendingData;

    public static bool IsAdvertising  => _pm?.Advertising == true;
    public static bool HasSubscribers { get { lock (_subs) return _subs.Count > 0; } }

    // Start advertising.  Safe to call multiple times — no-ops if already running.
    public static void Start(Action<string> onStatus) {
        if (_pm != null) { onStatus("Already advertising as \"nazcontrollerTwo\"."); return; }
        _onStatus = onStatus;
        // CBPeripheralManager must be created on the main queue.
        DispatchQueue.MainQueue.DispatchAsync(() => {
            _pm = new CBPeripheralManager();
            _pm.StateUpdated                  += OnStateUpdated;
            _pm.ServiceAdded                  += OnServiceAdded;
            _pm.AdvertisingStarted            += OnAdvertisingStarted;
            _pm.CharacteristicSubscribed      += OnSubscribed;
            _pm.CharacteristicUnsubscribed    += OnUnsubscribed;
            _pm.WriteRequestsReceived         += OnWriteRequests;
            _pm.ReadRequestReceived           += OnReadRequest;
            _pm.ReadyToUpdateSubscribers      += OnReadyToUpdateSubscribers;
        });
    }

    public static void Stop() {
        DispatchQueue.MainQueue.DispatchAsync(() => {
            if (_pm == null) return;
            _pm.StopAdvertising();
            _pm.RemoveAllServices();
            // Unregister all handlers before nulling so no callbacks fire on a dead object.
            _pm.StateUpdated                  -= OnStateUpdated;
            _pm.ServiceAdded                  -= OnServiceAdded;
            _pm.AdvertisingStarted            -= OnAdvertisingStarted;
            _pm.CharacteristicSubscribed      -= OnSubscribed;
            _pm.CharacteristicUnsubscribed    -= OnUnsubscribed;
            _pm.WriteRequestsReceived         -= OnWriteRequests;
            _pm.ReadRequestReceived           -= OnReadRequest;
            _pm.ReadyToUpdateSubscribers      -= OnReadyToUpdateSubscribers;
            _pm   = null;
            _char = null;
            _pendingData = null;
            lock (_subs) _subs.Clear();
        });
        _onStatus?.Invoke("📡 nazcontrollerTwo stopped.");
        _onStatus = null;
    }

    static void OnStateUpdated(object? s, EventArgs e) {
        if (_pm?.State != CBPeripheralManagerState.PoweredOn) {
            _onStatus?.Invoke($"📡 nazcontrollerTwo: BT state = {_pm?.State}");
            return;
        }
        // BT ready — build the GATT service.
        _char = new CBMutableCharacteristic(
            uuid:        Cfg.NazTwoChar,
            properties:  CBCharacteristicProperties.Notify |
                         CBCharacteristicProperties.WriteWithoutResponse,
            value:       null,
            permissions: CBAttributePermissions.Readable | CBAttributePermissions.Writeable
        );
        var svc = new CBMutableService(Cfg.NazTwoService, primary: true);
        svc.Characteristics = new CBCharacteristic[] { _char };
        _pm!.AddService(svc);
    }

    static void OnServiceAdded(object? s, CBPeripheralManagerServiceEventArgs e) {
        if (e.Error != null) {
            _onStatus?.Invoke($"📡 service error: {e.Error.LocalizedDescription}");
            return;
        }
        _pm?.StartAdvertising(new StartAdvertisingOptions {
            LocalName    = "nazcontrollerTwo",
            ServicesUUID = new[] { Cfg.NazTwoService }
        });
    }

    static void OnAdvertisingStarted(object? s, NSErrorEventArgs e) {
        if (e.Error != null)
            _onStatus?.Invoke($"📡 advertise failed: {e.Error.LocalizedDescription}");
        else
            _onStatus?.Invoke("📡 Advertising as \"nazcontrollerTwo\" — waiting for phone...");
    }

    static void OnSubscribed(object? s, CBPeripheralManagerSubscriptionEventArgs e) {
        lock (_subs) { if (!_subs.Contains(e.Central)) _subs.Add(e.Central); }
        _onStatus?.Invoke($"📡 Phone subscribed ({_subs.Count} subscriber(s)) — Gamepad ready!");
    }

    static void OnUnsubscribed(object? s, CBPeripheralManagerSubscriptionEventArgs e) {
        lock (_subs) _subs.Remove(e.Central);
        _onStatus?.Invoke($"📡 Phone unsubscribed ({_subs.Count} subscriber(s))");
    }

    // Accept any writes from the phone (e.g. ack / future commands back to iPad).
    static void OnWriteRequests(object? s, CBATTRequestsEventArgs e) {
        foreach (var req in e.Requests)
            _pm?.RespondToRequest(req, CBATTError.Success);
    }

    static void OnReadRequest(object? s, CBATTRequestEventArgs e) {
        e.Request.Value = NSData.FromArray(new byte[0]);
        _pm?.RespondToRequest(e.Request, CBATTError.Success);
    }

    // CoreBluetooth fires this on the main queue when UpdateValue previously returned false
    // (send queue was full) and it is now ready for more data.  Drain the latest pending report.
    static void OnReadyToUpdateSubscribers(object? s, EventArgs e) {
        var pending = System.Threading.Interlocked.Exchange(ref _pendingData, null);
        if (pending == null) return;
        var pm = _pm; var ch = _char;
        if (pm == null || ch == null) return;
        // Already on the main queue — call UpdateValue directly (no DispatchSync needed).
        if (!pm.UpdateValue(pending, ch, null))
            System.Threading.Interlocked.CompareExchange(ref _pendingData, pending, null);
    }

    // Called by GamepadView.SendBg() alongside (or instead of) the NotifyChar path.
    // At ~60 Hz on a background Task thread.
    public static bool SendGamepadReport(int[] reportSnapshot) {
        var pm  = _pm;
        var ch  = _char;
        if (pm == null || ch == null) return false;
        lock (_subs) { if (_subs.Count == 0) return false; }

        var report = string.Join(",", reportSnapshot);
        var json   = $"{{\"type\":\"gamepad\",\"report\":[{report}]}}";
        var data   = NSData.FromArray(System.Text.Encoding.UTF8.GetBytes(json));

        bool ok = false;
        // UpdateValue must run on the main queue.  Use DispatchSync so we know
        // immediately whether it succeeded or hit backpressure.
        // (This is called from Task.Run — never from the main queue — so no deadlock risk.)
        DispatchQueue.MainQueue.DispatchSync(() => ok = pm.UpdateValue(data, ch, null));
        if (!ok) {
            // Peripheral manager queue is full.  Store the latest report so
            // OnReadyToUpdateSubscribers can flush it when the queue drains.
            // We keep only the LATEST report (drop older ones) — for HID we care
            // about recency, not every intermediate frame.
            System.Threading.Interlocked.Exchange(ref _pendingData, data);
        }
        return ok;
    }
}

// ── Main view controller ──────────────────────────────────────────────────────
//
// FIX: Multi-device support.
//   Previously a single `target` + `devState` field meant connecting to the A15
//   would overwrite the iPad connection, and SendHello() would refuse to send
//   if the stored target didn't match by name.
//
//   Now each device has its own slot:
//     _ipadTarget / _ipadState  — Nazzara's iPad
//     _a15Target  / _a15State   — Nazzara's A15
//
//   SendHello(deviceName) picks the correct slot. The relay button always uses
//   whichever slot is currently ready (prefers iPad, falls back to A15).

class BlueController : UIViewController {

    // BLE central
    CBCentralManager  central;

    // Per-device connection slots — null when not connected
    CBPeripheral? _ipadTarget;
    DeviceState?  _ipadState;
    CBPeripheral? _a15Target;
    DeviceState?  _a15State;

    // Relay (runs on the primary connected device)
    Relay? relay;

    // Data
    List<(CBPeripheral p, NSNumber rssi)> discovered = new();

    // Quick-connect target name currently being scanned for, or null
    string? _quickConnectTarget;

    // UI
    UILabel      statusLabel;
    UILabel      counterLabel;
    UILabel      ipadStatusDot;   // per-device connection indicator
    UILabel      a15StatusDot;    // per-device connection indicator
    UIButton     quickConnectBtn;
    UIButton     quickConnectA15Btn;
    UIButton     helloIpadBtn;
    UIButton     helloA15Btn;
    UIButton     connectBtn;
    UIButton     relayBtn;
    UIButton     advBtn;        // toggle nazcontrollerTwo advertising
    UITableView  tableView;

    public BlueController() { Title = "SharpBlue"; }

    public override void ViewDidLoad() {
        View.BackgroundColor = UIColor.SystemBackgroundColor;
        BuildUI();
        InitBluetooth();
    }

    // ── UI construction ───────────────────────────────────────────────────────

    void BuildUI() {
        statusLabel = MakeLabel("Initialising Bluetooth...", UIFont.SystemFontOfSize(13),
                                UIColor.SecondaryLabelColor);

        counterLabel = MakeLabel("Relayed: 0 commands", UIFont.SystemFontOfSize(12),
                                 UIColor.SystemBlueColor);

        // Per-device status dots — show ○ Disconnected / ◑ Discovering / ● Ready
        ipadStatusDot = MakeLabel($"○  {Cfg.TargetName}  —  Disconnected",
                                  UIFont.SystemFontOfSize(12),
                                  UIColor.SecondaryLabelColor);
        ipadStatusDot.TextAlignment = UITextAlignment.Left;

        a15StatusDot  = MakeLabel($"○  {Cfg.A15DisplayName}  —  Disconnected",
                                  UIFont.SystemFontOfSize(12),
                                  UIColor.SecondaryLabelColor);
        a15StatusDot.TextAlignment = UITextAlignment.Left;

        quickConnectBtn = MakeButton($"Quick Connect  {Cfg.KnownAddress}", Cfg.Accent);
        quickConnectBtn.TouchUpInside += (s, e) => StartQuickConnect(Cfg.TargetName, quickConnectBtn, $"Quick Connect  {Cfg.KnownAddress}");

        quickConnectA15Btn = MakeButton($"Quick Connect  {Cfg.A15Address}", Cfg.Accent);
        quickConnectA15Btn.TouchUpInside += (s, e) => StartQuickConnect(Cfg.A15Name, quickConnectA15Btn, $"Quick Connect  {Cfg.A15Address}");

        // FIX: Hello buttons now call SendHello(deviceName) which looks up the
        // correct connection slot rather than checking a single shared `target`.
        helloIpadBtn = MakeButton($"✉  Hello → {Cfg.TargetName}", Cfg.Warn);
        helloIpadBtn.TouchUpInside += (s, e) => SendHello(Cfg.TargetName);

        helloA15Btn = MakeButton($"✉  Hello → {Cfg.A15DisplayName}", Cfg.Warn);
        helloA15Btn.TouchUpInside += (s, e) => SendHello(Cfg.A15Name);

        connectBtn = MakeButton($"Connect to {Cfg.TargetName}", Cfg.Good);
        connectBtn.Hidden = true;
        connectBtn.TouchUpInside += OnConnectTapped;

        relayBtn = MakeButton("▶  Start Relay", Cfg.Accent);
        relayBtn.Hidden = true;
        relayBtn.TouchUpInside += OnRelayTapped;

        advBtn = MakeButton("📡  Advertise as nazcontrollerTwo", UIColor.SystemPurpleColor);
        advBtn.TouchUpInside += (s, e) => ToggleAdvertise();

        tableView = new UITableView {
            TranslatesAutoresizingMaskIntoConstraints = false
        };

        View.AddSubviews(statusLabel, counterLabel, ipadStatusDot, a15StatusDot,
                         quickConnectBtn, quickConnectA15Btn,
                         helloIpadBtn, helloA15Btn, advBtn, connectBtn, relayBtn, tableView);

        var g = View.SafeAreaLayoutGuide;
        NSLayoutConstraint.ActivateConstraints(new[] {
            statusLabel.TopAnchor.ConstraintEqualTo(g.TopAnchor, 12),
            statusLabel.LeadingAnchor.ConstraintEqualTo(View.LeadingAnchor, 16),
            statusLabel.TrailingAnchor.ConstraintEqualTo(View.TrailingAnchor, -16),

            counterLabel.TopAnchor.ConstraintEqualTo(statusLabel.BottomAnchor, 4),
            counterLabel.LeadingAnchor.ConstraintEqualTo(View.LeadingAnchor, 16),
            counterLabel.TrailingAnchor.ConstraintEqualTo(View.TrailingAnchor, -16),

            // Per-device status dots
            ipadStatusDot.TopAnchor.ConstraintEqualTo(counterLabel.BottomAnchor, 8),
            ipadStatusDot.LeadingAnchor.ConstraintEqualTo(View.LeadingAnchor, 16),
            ipadStatusDot.TrailingAnchor.ConstraintEqualTo(View.TrailingAnchor, -16),

            a15StatusDot.TopAnchor.ConstraintEqualTo(ipadStatusDot.BottomAnchor, 2),
            a15StatusDot.LeadingAnchor.ConstraintEqualTo(View.LeadingAnchor, 16),
            a15StatusDot.TrailingAnchor.ConstraintEqualTo(View.TrailingAnchor, -16),

            quickConnectBtn.TopAnchor.ConstraintEqualTo(a15StatusDot.BottomAnchor, 12),
            quickConnectBtn.LeadingAnchor.ConstraintEqualTo(View.LeadingAnchor, 24),
            quickConnectBtn.TrailingAnchor.ConstraintEqualTo(View.TrailingAnchor, -24),
            quickConnectBtn.HeightAnchor.ConstraintEqualTo(48),

            quickConnectA15Btn.TopAnchor.ConstraintEqualTo(quickConnectBtn.BottomAnchor, 8),
            quickConnectA15Btn.LeadingAnchor.ConstraintEqualTo(View.LeadingAnchor, 24),
            quickConnectA15Btn.TrailingAnchor.ConstraintEqualTo(View.TrailingAnchor, -24),
            quickConnectA15Btn.HeightAnchor.ConstraintEqualTo(48),

            helloIpadBtn.TopAnchor.ConstraintEqualTo(quickConnectA15Btn.BottomAnchor, 8),
            helloIpadBtn.LeadingAnchor.ConstraintEqualTo(View.LeadingAnchor, 24),
            helloIpadBtn.TrailingAnchor.ConstraintEqualTo(View.TrailingAnchor, -24),
            helloIpadBtn.HeightAnchor.ConstraintEqualTo(48),

            helloA15Btn.TopAnchor.ConstraintEqualTo(helloIpadBtn.BottomAnchor, 8),
            helloA15Btn.LeadingAnchor.ConstraintEqualTo(View.LeadingAnchor, 24),
            helloA15Btn.TrailingAnchor.ConstraintEqualTo(View.TrailingAnchor, -24),
            helloA15Btn.HeightAnchor.ConstraintEqualTo(48),

            advBtn.TopAnchor.ConstraintEqualTo(helloA15Btn.BottomAnchor, 8),
            advBtn.LeadingAnchor.ConstraintEqualTo(View.LeadingAnchor, 24),
            advBtn.TrailingAnchor.ConstraintEqualTo(View.TrailingAnchor, -24),
            advBtn.HeightAnchor.ConstraintEqualTo(48),

            connectBtn.TopAnchor.ConstraintEqualTo(advBtn.BottomAnchor, 8),
            connectBtn.LeadingAnchor.ConstraintEqualTo(View.LeadingAnchor, 24),
            connectBtn.TrailingAnchor.ConstraintEqualTo(View.TrailingAnchor, -24),
            connectBtn.HeightAnchor.ConstraintEqualTo(48),

            relayBtn.TopAnchor.ConstraintEqualTo(connectBtn.BottomAnchor, 8),
            relayBtn.LeadingAnchor.ConstraintEqualTo(View.LeadingAnchor, 24),
            relayBtn.TrailingAnchor.ConstraintEqualTo(View.TrailingAnchor, -24),
            relayBtn.HeightAnchor.ConstraintEqualTo(48),

            tableView.TopAnchor.ConstraintEqualTo(relayBtn.BottomAnchor, 12),
            tableView.LeadingAnchor.ConstraintEqualTo(View.LeadingAnchor),
            tableView.TrailingAnchor.ConstraintEqualTo(View.TrailingAnchor),
            tableView.BottomAnchor.ConstraintEqualTo(View.BottomAnchor),
        });

        NavigationItem.RightBarButtonItem = new UIBarButtonItem(
            "Scan", UIBarButtonItemStyle.Plain, (s, e) => BeginScan());
        NavigationItem.LeftBarButtonItem = new UIBarButtonItem(
            "Stop", UIBarButtonItemStyle.Plain, (s, e) => StopScan());

        // "Gamepad" button centred between Scan and Stop in the nav bar
        var gpBtn = UIButton.FromType(UIButtonType.System);
        gpBtn.SetTitle("🎮 Gamepad", UIControlState.Normal);
        gpBtn.SetTitleColor(UIColor.SystemBlueColor, UIControlState.Normal);
        gpBtn.Frame = new CGRect(0, 0, 120, 32);
        gpBtn.TouchUpInside += (s, e) => OpenGamepad();
        NavigationItem.TitleView = gpBtn;
    }

    UILabel MakeLabel(string text, UIFont font, UIColor color) {
        return new UILabel {
            Text          = text,
            Font          = font,
            TextColor     = color,
            TextAlignment = UITextAlignment.Center,
            Lines         = 0,
            TranslatesAutoresizingMaskIntoConstraints = false
        };
    }

    UIButton MakeButton(string title, UIColor bg) {
        var b = UIButton.FromType(UIButtonType.System);
        b.SetTitle(title, UIControlState.Normal);
        b.SetTitleColor(UIColor.White, UIControlState.Normal);
        b.BackgroundColor = bg;
        b.Layer.CornerRadius = 12;
        b.TranslatesAutoresizingMaskIntoConstraints = false;
        return b;
    }

    // ── Per-device dot helpers ────────────────────────────────────────────────

    enum DotState { Disconnected, Discovering, Ready }

    void SetDot(string deviceName, DotState state) {
        var label       = (deviceName == Cfg.A15Name) ? a15StatusDot : ipadStatusDot;
        // Always show the friendly display name in the UI, not the BLE advertisement name.
        var displayName = (deviceName == Cfg.A15Name) ? Cfg.A15DisplayName : deviceName;
        switch (state) {
            case DotState.Disconnected:
                label.Text      = $"○  {displayName}  —  Disconnected";
                label.TextColor = UIColor.SecondaryLabelColor;
                break;
            case DotState.Discovering:
                label.Text      = $"◑  {displayName}  —  Discovering...";
                label.TextColor = Cfg.Warn;
                break;
            case DotState.Ready:
                label.Text      = $"●  {displayName}  —  Ready";
                label.TextColor = Cfg.Good;
                break;
        }
    }

    // ── Bluetooth init ────────────────────────────────────────────────────────

    void InitBluetooth() {
        central = new CBCentralManager(DispatchQueue.MainQueue);
        central.UpdatedState              += (s, e) => InvokeOnMainThread(() => HandleState(central.State));
        central.DiscoveredPeripheral      += (s, e) => InvokeOnMainThread(() => HandleDiscovered(e.Peripheral, e.RSSI));
        central.ConnectedPeripheral       += (s, e) => InvokeOnMainThread(() => HandleConnected(e.Peripheral));
        central.FailedToConnectPeripheral += (s, e) => InvokeOnMainThread(() => HandleFailed(e.Peripheral, e.Error));
        central.DisconnectedPeripheral    += (s, e) => InvokeOnMainThread(() => HandleDisconnected(e.Peripheral, e.Error));
    }

    // ── State ─────────────────────────────────────────────────────────────────

    void HandleState(CBCentralManagerState s) {
        switch (s) {
            case CBCentralManagerState.PoweredOn:
                statusLabel.Text = "Bluetooth ready — scanning...";
                BeginScan();
                break;
            case CBCentralManagerState.PoweredOff:
                statusLabel.Text = "Bluetooth off — enable in Settings.";
                break;
            case CBCentralManagerState.Unauthorized:
                statusLabel.Text = "Bluetooth permission denied.";
                break;
            default:
                statusLabel.Text = $"Bluetooth: {s}";
                break;
        }
    }

    // ── Scanning ──────────────────────────────────────────────────────────────

    void BeginScan() {
        if (central.State != CBCentralManagerState.PoweredOn) return;
        discovered.Clear();
        // FIX: don't clear per-device slots here — existing connections survive a new scan.
        // Only reset the transient UI hint if no quick-connect is in progress.
        if (_quickConnectTarget == null) {
            connectBtn.Hidden = true;
        }
        RefreshTable();
        statusLabel.Text = $"Scanning...";
        central.ScanForPeripherals(peripheralUuids: null,
            options: new PeripheralScanningOptions { AllowDuplicatesKey = false });
    }

    void StopScan() {
        central.StopScan();
        statusLabel.Text = $"Scan stopped — {discovered.Count} device(s) found.";
    }

    // ── Discovery ─────────────────────────────────────────────────────────────

    void HandleDiscovered(CBPeripheral p, NSNumber rssi) {
        var existing = discovered.FindIndex(d => d.p.Identifier == p.Identifier);
        if (existing >= 0)
            discovered[existing] = (p, rssi);
        else
            discovered.Add((p, rssi));

        // Auto-connect when quick-connect target appears
        if (p.Name == _quickConnectTarget) {
            bool alreadyConnected = (p.Name == Cfg.TargetName  && _ipadTarget != null) ||
                                    (p.Name == Cfg.A15Name     && _a15Target  != null);
            if (!alreadyConnected) {
                StopScan();
                string found = _quickConnectTarget;
                _quickConnectTarget = null;
                statusLabel.Text      = $"✓ {p.Name} found — connecting...";
                statusLabel.TextColor = Cfg.Good;
                ConnectToPeripheral(p);
            }
        } else if (p.Name == Cfg.TargetName && _ipadTarget == null && _quickConnectTarget == null) {
            // Passive discovery of iPad — show connect button
            connectBtn.Hidden   = false;
            connectBtn.SetTitle($"Connect to {Cfg.TargetName}", UIControlState.Normal);
            connectBtn.BackgroundColor = Cfg.Good;
            connectBtn.Tag = 0;  // 0 = iPad
            statusLabel.Text      = $"✓ {Cfg.TargetName} found!";
            statusLabel.TextColor = Cfg.Good;
        } else if (p.Name == Cfg.A15Name && _a15Target == null && _quickConnectTarget == null) {
            // Passive discovery of nazcontroller (A15) — show connect button
            connectBtn.Hidden   = false;
            connectBtn.SetTitle($"Connect to {Cfg.A15DisplayName}", UIControlState.Normal);
            connectBtn.BackgroundColor = Cfg.Good;
            connectBtn.Tag = 1;  // 1 = A15 / nazcontroller
            statusLabel.Text      = $"✓ {Cfg.A15DisplayName} ({Cfg.A15Name}) found!";
            statusLabel.TextColor = Cfg.Good;
        }
        RefreshTable();
    }

    // ── Connection ────────────────────────────────────────────────────────────

    void StartQuickConnect(string targetName, UIButton btn, string originalTitle) {
        _quickConnectTarget = targetName;
        btn.Enabled = false;
        btn.SetTitle("Scanning...", UIControlState.Normal);
        // Show the friendly display name rather than the raw BLE advertisement name.
        var displayName = (targetName == Cfg.A15Name) ? Cfg.A15DisplayName : targetName;
        statusLabel.Text      = $"Quick connecting to {displayName}...";
        statusLabel.TextColor = UIColor.SecondaryLabelColor;
        BeginScan();
    }

    void ResetQuickConnectButtons() {
        quickConnectBtn.SetTitle($"Quick Connect  {Cfg.KnownAddress}", UIControlState.Normal);
        quickConnectBtn.BackgroundColor = Cfg.Accent;
        quickConnectBtn.Enabled = true;
        quickConnectA15Btn.SetTitle($"Quick Connect  {Cfg.A15Address}", UIControlState.Normal);
        quickConnectA15Btn.BackgroundColor = Cfg.Accent;
        quickConnectA15Btn.Enabled = true;
        _quickConnectTarget = null;
    }

    void MarkConnectedButton(string deviceName) {
        if (deviceName == Cfg.TargetName) {
            quickConnectBtn.SetTitle($"● Connected  {Cfg.KnownAddress}", UIControlState.Normal);
            quickConnectBtn.BackgroundColor = UIColor.SystemPinkColor;
        } else if (deviceName == Cfg.A15Name) {
            quickConnectA15Btn.SetTitle($"● Connected  {Cfg.A15Address}", UIControlState.Normal);
            quickConnectA15Btn.BackgroundColor = UIColor.SystemPinkColor;
        }
    }

    // "Connect" button — used when iPad or nazcontroller is passively found during scan.
    // Tag 0 = iPad (TargetName), Tag 1 = A15 / nazcontroller (A15Name).
    void OnConnectTapped(object sender, EventArgs e) {
        string target = (connectBtn.Tag == 1) ? Cfg.A15Name : Cfg.TargetName;
        var p = discovered.FirstOrDefault(d => d.p.Name == target).p;
        if (p == null) return;
        StopScan();
        statusLabel.Text      = $"Connecting to {p.Name}...";
        statusLabel.TextColor = UIColor.SecondaryLabelColor;
        connectBtn.Enabled    = false;
        ConnectToPeripheral(p);
    }

    void ConnectToPeripheral(CBPeripheral p) {
        central.ConnectPeripheral(p, new PeripheralConnectionOptions());
    }

    void HandleConnected(CBPeripheral p) {
        ResetQuickConnectButtons();
        MarkConnectedButton(p.Name ?? "");
        var connDisplayName = (p.Name == Cfg.A15Name) ? Cfg.A15DisplayName : (p.Name ?? "");
        statusLabel.Text      = $"Connected to {connDisplayName} — discovering services...";
        statusLabel.TextColor = Cfg.Good;
        connectBtn.SetTitle("Connected ✓", UIControlState.Normal);
        connectBtn.BackgroundColor = Cfg.Accent;
        SetDot(p.Name ?? "", DotState.Discovering);

        bool isA15 = p.Name == Cfg.A15Name;

        // Create a DeviceState for this device.
        // OnReady is assigned after construction so the lambda can safely
        // capture `ds` — it is fully assigned by the time OnReady ever fires.
        var ds = new DeviceState {
            OnStatus = msg => InvokeOnMainThread(() => statusLabel.Text = msg),
        };
        ds.OnReady = msg => InvokeOnMainThread(() => {
            statusLabel.Text = msg;
            SetDot(p.Name ?? "", DotState.Ready);
            // Show relay button as soon as any device is ready
            relayBtn.Hidden = false;

            // For A15: trigger iOS pairing by subscribing to HID report notifications.
            // OnReady only fires when HidReportChar is already non-null (see DeviceState),
            // so the null check here is redundant — kept as a safety assertion only.
            if (isA15) {
                statusLabel.Text      = $"Requesting pair with {Cfg.A15DisplayName}...";
                statusLabel.TextColor = UIColor.SecondaryLabelColor;
                p.SetNotifyValue(true, ds.HidReportChar!);
            }
        });

        // Store in the correct slot
        if (isA15) { _a15Target = p;    _a15State  = ds; }
        else        { _ipadTarget = p;  _ipadState = ds; }

        p.DiscoveredService        += ds.HandleDiscoveredService;
        p.DiscoveredCharacteristic += ds.HandleDiscoveredCharacteristic;

        // Pairing confirmation for A15
        if (isA15) {
            p.UpdatedNotificationState += (s, e) => InvokeOnMainThread(() => {
                if (e.Error == null) {
                    statusLabel.Text      = $"✓ Paired & subscribed to {Cfg.A15DisplayName}";
                    statusLabel.TextColor = Cfg.Good;
                } else {
                    statusLabel.Text      = $"Pair failed: {e.Error.LocalizedDescription}";
                    statusLabel.TextColor = Cfg.Warn;
                }
            });
        }

        // Pass null to discover ALL GATT services on the device.
        // Using a filtered list only returns services that were in the advertisement
        // payload — the phone only advertises HID (1812), so Mouse and Notify services
        // would never be found with a filter, leaving NotifyCharField null and
        // preventing any command from being sent.
        p.DiscoverServices(null);
    }

    void HandleFailed(CBPeripheral p, NSError e) {
        ResetQuickConnectButtons();
        ClearSlotForPeripheral(p);
        statusLabel.Text      = $"Connection failed: {e?.LocalizedDescription ?? "unknown"}";
        statusLabel.TextColor = Cfg.Danger;
        connectBtn.Enabled    = true;
    }

    void HandleDisconnected(CBPeripheral p, NSError e) {
        ResetQuickConnectButtons();
        ClearSlotForPeripheral(p);

        // Stop relay only if it was running on this device
        if (relay != null) {
            relay.Stop();
            relay = null;
            relayBtn.SetTitle("▶  Start Relay", UIControlState.Normal);
            relayBtn.BackgroundColor = Cfg.Accent;
        }

        // Hide relay button only if neither device is ready
        if (_ipadState == null && _a15State == null)
            relayBtn.Hidden = true;

        var discDisplayName = (p.Name == Cfg.A15Name) ? Cfg.A15DisplayName : (p.Name ?? "device");
        statusLabel.Text      = $"Disconnected from {discDisplayName}. Tap Quick Connect to retry.";
        statusLabel.TextColor = Cfg.Warn;
    }

    void ClearSlotForPeripheral(CBPeripheral p) {
        if (p.Name == Cfg.A15Name)     { _a15Target  = null; _a15State  = null; }
        else if (p.Name == Cfg.TargetName) { _ipadTarget = null; _ipadState = null; }
    }

    // ── Hello World BLE write ─────────────────────────────────────────────────
    //
    // FIX: look up the correct connection slot by device name.
    // Previously this checked `target.Name != deviceName` against a single shared
    // `target`, which always failed when two devices were involved.

    // Reads sharpbluesend.py and sends all pending notify commands to deviceName.
    // Replaces the old hardcoded "Hello, World!" — lets you put any "notify" entry
    // in sharpbluesend.py and test it with this button without starting the full relay.
    // Non-notify entries (gamepad, keyboard, mouse) are skipped here since those need
    // the HID/mouse characteristics which may not be available on this connection.
    void SendHello(string deviceName) {
        CBPeripheral? p  = (deviceName == Cfg.A15Name) ? _a15Target  : _ipadTarget;
        DeviceState?  ds = (deviceName == Cfg.A15Name) ? _a15State   : _ipadState;

        if (p == null) {
            statusLabel.Text      = $"Not connected to {deviceName}.";
            statusLabel.TextColor = Cfg.Warn;
            return;
        }
        if (ds?.NotifyCharField == null) {
            statusLabel.Text      = $"Notify characteristic not yet found on {deviceName}.\nWait for 'Ready' status, then try again.";
            statusLabel.TextColor = Cfg.Warn;
            return;
        }

        // Read pending commands from sharpbluesend.py
        var commands = SendFileReader.Read(Cfg.SendFile);
        var notifyCommands = commands.Where(c => c.Type == "notify").ToList();

        if (notifyCommands.Count == 0) {
            // Fallback: if sharpbluesend.py is empty or has no notify entries,
            // send a plain "Hello, World!" so you can confirm the channel works.
            var helloBytes = Encoding.UTF8.GetBytes("Hello, World!");
            p.WriteValue(NSData.FromArray(helloBytes), ds.NotifyCharField, CBCharacteristicWriteType.WithResponse);
            statusLabel.Text      = $"✉  No notify entries in {Cfg.SendFile} — sent Hello, World! → {deviceName}";
            statusLabel.TextColor = Cfg.Warn;
            return;
        }

        // Send every pending notify command and clear the ones that went out
        var sent = new HashSet<string>();
        foreach (var cmd in notifyCommands) {
            if (cmd.Bytes == null) continue;
            var data = NSData.FromArray(cmd.Bytes);
            p.WriteValue(data, ds.NotifyCharField, CBCharacteristicWriteType.WithResponse);
            sent.Add(cmd.Raw);
        }
        SendFileReader.ClearSent(Cfg.SendFile, sent);

        statusLabel.Text      = $"✉  Sent {sent.Count} command(s) from {Cfg.SendFile} → {deviceName}";
        statusLabel.TextColor = Cfg.Good;
    }

    // ── Relay ─────────────────────────────────────────────────────────────────
    //
    // The relay sends commands to whichever device is ready.
    // Prefers iPad; falls back to A15.

    void OnRelayTapped(object sender, EventArgs e) {
        if (relay == null) {
            // Pick the best ready device
            CBPeripheral? rp  = _ipadTarget ?? _a15Target;
            DeviceState?  rds = _ipadState  ?? _a15State;
            if (rp == null || rds == null) {
                statusLabel.Text      = "No device ready — connect first.";
                statusLabel.TextColor = Cfg.Warn;
                return;
            }
            relay = new Relay(rp, rds,
                msg   => InvokeOnMainThread(() => statusLabel.Text = msg),
                count => InvokeOnMainThread(() =>
                    counterLabel.Text = $"Relayed: {count} command(s)"));
            relay.Start();
            relayBtn.SetTitle("⏹  Stop Relay", UIControlState.Normal);
            relayBtn.BackgroundColor = Cfg.Danger;
        } else {
            relay.Stop();
            relay = null;
            relayBtn.SetTitle("▶  Start Relay", UIControlState.Normal);
            relayBtn.BackgroundColor = Cfg.Accent;
        }
    }

    // ── Table ─────────────────────────────────────────────────────────────────

    void RefreshTable() {
        var sorted = discovered
            .OrderByDescending(d => d.p.Name == Cfg.TargetName)
            .ThenByDescending(d => d.rssi.Int32Value)
            .ToList();
        discovered = sorted;
        tableView.Source = new DeviceSource(discovered, Cfg.TargetName);
        tableView.ReloadData();
    }

    // ── nazcontrollerTwo advertise toggle ────────────────────────────────────

    void ToggleAdvertise() {
        if (NazServer.IsAdvertising) {
            NazServer.Stop();
            advBtn.SetTitle("📡  Advertise as nazcontrollerTwo", UIControlState.Normal);
            advBtn.BackgroundColor = UIColor.SystemPurpleColor;
        } else {
            NazServer.Start(msg => InvokeOnMainThread(() => {
                statusLabel.Text      = msg;
                statusLabel.TextColor = NazServer.HasSubscribers ? Cfg.Good : Cfg.Warn;
                // Once phone subscribes, light up the button green
                advBtn.BackgroundColor = NazServer.HasSubscribers
                    ? Cfg.Good : UIColor.SystemPurpleColor;
                advBtn.SetTitle(NazServer.IsAdvertising
                    ? "📡  Stop nazcontrollerTwo"
                    : "📡  Advertise as nazcontrollerTwo", UIControlState.Normal);
            }));
            advBtn.SetTitle("📡  Stop nazcontrollerTwo", UIControlState.Normal);
            advBtn.BackgroundColor = Cfg.Warn;
        }
    }

    // ── Gamepad ───────────────────────────────────────────────────────────────

    void OpenGamepad() {
        // Prefer whichever connected device has a discovered HID report characteristic.
        // Fall back to the other slot so the screen still opens (showing "No BLE") if
        // neither is fully ready yet — the user can see the status rather than nothing.
        CBPeripheral?     p;
        CBCharacteristic? ch;

        // Gamepad commands go via NotifyCharField (JSON path) — HidReportChar is never
        // accessible when the phone is bonded as a system BT device via iOS Settings.
        if (_a15State?.NotifyCharField != null) {
            p  = _a15Target;
            ch = _a15State.NotifyCharField;
        } else if (_ipadState?.NotifyCharField != null) {
            p  = _ipadTarget;
            ch = _ipadState.NotifyCharField;
        } else if (NazServer.IsAdvertising || NazServer.HasSubscribers) {
            // iPad is advertising as nazcontrollerTwo (phone may not have subscribed yet).
            // Open the gamepad anyway — SendBg() will send once subscribers arrive,
            // and the status label inside GamepadView shows the live connection state.
            p  = null;
            ch = null;
        } else {
            // No device is ready yet — tell the user and bail out.
            statusLabel.Text      = "Gamepad not ready — connect to A15 first, or tap Advertise nazcontrollerTwo.";
            statusLabel.TextColor = Cfg.Warn;
            return;
        }

        var gc = new GamepadController(p, ch);
        gc.ModalPresentationStyle = UIModalPresentationStyle.FullScreen;
        PresentViewController(gc, true, null);
    }
}

// ── Entry point ───────────────────────────────────────────────────────────────

var Main = new UINavigationController(new BlueController());
