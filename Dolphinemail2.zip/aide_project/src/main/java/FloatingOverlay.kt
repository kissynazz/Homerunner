package com.home.automation

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.*
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.*
import android.widget.*
import java.io.File
import java.io.FileWriter
import java.io.PrintWriter
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sqrt

// ══════════════════════════════════════════════════════════════════════════
//  FloatingOverlay
//
//  TRAINER TAP STATES
//    0 → idle (trainer draggable)
//    1 → controller panel at bottom
//    2 → trainer centres + top bar [Step | ● REC1 | ● REC2]
//
//  CONTROLLER LAYOUT
//   ┌─────────────────────────────────────────────────┐
//   │  [L1]                                   [R1]    │
//   │  [↑]                                    [X/△]  │
//   │[←][ ][→] [SEL][PS][STA]  [Y/□][MENU][A/○]     │
//   │  [↓]                                    [B/✕]  │
//   │  (L-stick)                          (R-stick)   │
//   └─────────────────────────────────────────────────┘
//
//  MENU BUTTON (centre of face cluster, between Y/□ and A/○)
//    Long-press (500 ms) → Nokia-style radial bubble appears with earth icon
//    While still holding, drag finger to earth ↑ and release → Main Menu opens
//
//  MAIN MENU (ash-grey opaque overlay, full-width near-full-height)
//    Tab 1 PLAYBACK  — lists saved keyframes_N.txt; tap to preview with button glow
//    Tab 2 SHOTS     — grid of DCIM/Screenshots PNGs; tap to select → assign to custom slot
//    Tab 3 CUSTOM    — 6 slots with screenshot thumbnails; hold to execute
//
//  PS BUTTON (controller centre)
//    Tap   → start/keyframe controller recording
//    Long  → stop & save keyframes_N.txt
// ══════════════════════════════════════════════════════════════════════════
object FloatingOverlay {

    // ── system ─────────────────────────────────────────────────────────────
    private var wm: WindowManager? = null
    private var service: AccessibilityService? = null
    private val mainH = Handler(Looper.getMainLooper())

    // ── trainer ────────────────────────────────────────────────────────────
    private var trainerWin: View? = null
    private var trainerParams: WindowManager.LayoutParams? = null
    private var trainerX = 200; private var trainerY = 400

    // ── controller ─────────────────────────────────────────────────────────
    private var controllerWin: View? = null
    private var psBtn: PsButtonView? = null
    private val buttonRefs = mutableMapOf<String, View>()  // for glow during playback

    // ── top bar (state 2) ──────────────────────────────────────────────────
    private var topBarWin: View? = null
    private var btnRec1: Button? = null
    private var btnRec2: Button? = null

    // ── stop button ────────────────────────────────────────────────────────
    private var stopWin: View? = null

    // ── ui state ───────────────────────────────────────────────────────────
    private var uiState = 0

    // ── screen-rec ─────────────────────────────────────────────────────────
    enum class RecMode { NONE, REC1, REC2 }
    private var recMode = RecMode.NONE
    private val recBuffer = mutableListOf<String>()
    private var stepCursor = 0
    private var recCounter = 1
    private var captureWin: View? = null

    // ── controller recording ───────────────────────────────────────────────
    private var ctrlRecording = false
    private val ctrlBuffer = mutableListOf<String>()
    private var keyframeCount = 0
    private var ctrlRecCounter = 1

    // ── controller tappable toggle ─────────────────────────────────────────
    // Default: screen (Dolphin) is tappable. Double-tap trainer → flip.
    private var controllerTappable = false
    private var controllerWinParams: WindowManager.LayoutParams? = null

    // ── radial / main menu ─────────────────────────────────────────────────
    private var radialWin: View? = null
    private var mainMenuWin: View? = null
    // screen rect of the earth option (set when radial menu opens, checked on finger-up)
    private val earthScreenRect = RectF()
    // currently selected screenshot (for assigning to custom slots)
    private var selectedShot: Bitmap? = null
    private val customSlots = arrayOfNulls<Bitmap>(6)          // icons
    private val customSlotActions = Array<String?>(6) { null } // associated keyframe filename
    // playback thread
    private var playbackThread: Thread? = null

    // ══════════════════════════════════════════════════════════════════════
    //  Public
    // ══════════════════════════════════════════════════════════════════════

    fun show(context: Context) {
        service = context as? AccessibilityService
        wm    = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        recCounter    = nextIndex(context, "rec_steps", "rec_live")
        ctrlRecCounter = nextIndex(context, "keyframes")
        buildTrainer(context)
    }

    fun dismiss() {
        playbackThread?.interrupt()
        removeAllWindows()
        service = null; wm = null
        recMode = RecMode.NONE; recBuffer.clear(); stepCursor = 0
        ctrlRecording = false; ctrlBuffer.clear(); keyframeCount = 0
        buttonRefs.clear(); uiState = 0
    }

    /**
     * Flash the Ash trainer node sky-blue for 2 s to signal an email was received.
     * Safe to call from any thread — posts to the main handler.
     */
    fun flashEmailReceived() {
        mainH.post {
            val v = trainerWin ?: return@post
            // Tint the image sky-blue while keeping the bitmap visible
            (v as? ImageView)?.setColorFilter(
                Color.argb(180, 135, 206, 235),   // semi-transparent sky blue
                PorterDuff.Mode.SCREEN
            ) ?: v.setBackgroundColor(Color.argb(180, 135, 206, 235))
            // Restore after 2 seconds
            mainH.postDelayed({
                (v as? ImageView)?.clearColorFilter()
                    ?: v.setBackgroundColor(Color.TRANSPARENT)
            }, 2000L)
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    //  Trainer
    // ══════════════════════════════════════════════════════════════════════

    private fun buildTrainer(ctx: Context) {
        val iv = ImageView(ctx)
        try { iv.setImageBitmap(BitmapFactory.decodeStream(ctx.assets.open("trainer.png"))) }
        catch (_: Exception) { iv.setBackgroundColor(0xFF22AAFF.toInt()) }
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        val p = makeParams(dp(ctx, 90), dp(ctx, 110))
        p.x = trainerX; p.y = trainerY
        setupDragAndTap(iv, p, ctx)
        wm?.addView(iv, p); trainerWin = iv; trainerParams = p
    }

    private fun setupDragAndTap(v: View, p: WindowManager.LayoutParams, ctx: Context) {
        var ix = 0; var iy = 0; var tx = 0f; var ty = 0f; var moved = false
        var lastTapMs = 0L
        var pendingSingle: Runnable? = null
        v.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { ix=p.x; iy=p.y; tx=ev.rawX; ty=ev.rawY; moved=false }
                MotionEvent.ACTION_MOVE -> {
                    val dx=(ev.rawX-tx).toInt(); val dy=(ev.rawY-ty).toInt()
                    if (abs(dx)>8||abs(dy)>8) moved=true
                    p.x=ix+dx; p.y=iy+dy; trainerX=p.x; trainerY=p.y
                    try { wm?.updateViewLayout(v,p) } catch (_:Exception) {}
                }
                MotionEvent.ACTION_UP -> if (!moved) {
                    val now = System.currentTimeMillis()
                    if (now - lastTapMs < 350 && pendingSingle != null) {
                        // Double-tap detected
                        mainH.removeCallbacks(pendingSingle!!)
                        pendingSingle = null; lastTapMs = 0L
                        onTrainerDoubleTap(ctx)
                    } else {
                        lastTapMs = now
                        val r = Runnable { pendingSingle = null; onTrainerTap(ctx) }
                        pendingSingle = r
                        mainH.postDelayed(r, 360)
                    }
                }
            }; true
        }
    }

    private fun onTrainerTap(ctx: Context) {
        when (uiState) {
            // 0 → horizontal GC controller (new default view)
            0 -> { uiState=1; buildControllerHorizontal(ctx) }
            // 1 → vertical portrait controller (legacy)
            1 -> {
                controllerWin?.let { wm?.removeView(it) }; controllerWin=null
                controllerWinParams = null; uiState=2; buildController(ctx)
            }
            // 2 → top-bar recording mode
            2 -> {
                uiState=3
                controllerWin?.let { wm?.removeView(it) }; controllerWin=null
                controllerWinParams = null
                buildTopBar(ctx); centerTrainer(ctx)
            }
            // 3 → back to idle
            3 -> {
                stopScreenRec(ctx)
                topBarWin?.let { wm?.removeView(it) }; topBarWin=null
                uiState=0
            }
        }
    }

    /** Double-tap Ash: toggle whether the controller captures touches or passes them to the screen.
     *  When tappable, all buttons get a green tint so you know they're ready to press. */
    private fun onTrainerDoubleTap(ctx: Context) {
        val cParams = controllerWinParams
        val cWin    = controllerWin
        if (cParams == null || cWin == null) {
            toast(ctx, "Open controller first (tap Ash)")
            return
        }
        controllerTappable = !controllerTappable
        if (controllerTappable) {
            cParams.flags = cParams.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            // Green tint on all buttons — signals they're live and ready
            buttonRefs.values.forEach { v ->
                v.background?.setColorFilter(
                    Color.argb(160, 0, 220, 80), PorterDuff.Mode.SRC_ATOP)
                v.invalidate()
            }
            toast(ctx, "✓ Buttons READY — green = live")
        } else {
            cParams.flags = cParams.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            // Clear tint — back to pass-through mode
            buttonRefs.values.forEach { v ->
                v.background?.clearColorFilter()
                v.invalidate()
            }
            toast(ctx, "Pass-through — double-tap to activate buttons")
        }
        try { wm?.updateViewLayout(cWin, cParams) } catch (_: Exception) {}
    }

    private fun moveTrainer(ctx: Context, x: Int, y: Int) {
        trainerX=x; trainerY=y
        trainerParams?.let { p -> p.x=x; p.y=y
            try { trainerWin?.let { wm?.updateViewLayout(it,p) } } catch (_:Exception) {} }
    }

    private fun centerTrainer(ctx: Context) {
        val dm=ctx.resources.displayMetrics
        moveTrainer(ctx, dm.widthPixels/2-dp(ctx,45), dm.heightPixels/2-dp(ctx,55))
    }

    // ══════════════════════════════════════════════════════════════════════
    //  Controller panel
    // ══════════════════════════════════════════════════════════════════════

    private fun buildController(ctx: Context) {
        buttonRefs.clear()
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xEE0D0D1A.toInt())
            setPadding(dp(ctx,6), dp(ctx,6), dp(ctx,6), dp(ctx,6))
        }

        // Row 1: shoulder buttons
        root.addView(centreRow(ctx,
            ctrlBtnRef(ctx,"L1","BTN_L1"),
            hSpace(ctx,120),
            ctrlBtnRef(ctx,"R1","BTN_R1")
        ))

        // Row 2: D-pad | SEL·PS·STA | Face
        val midRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(ctx,4), 0, dp(ctx,4))
        }

        // D-pad
        val dpad = GridLayout(ctx).apply { columnCount=3; rowCount=3 }
        dpad.addView(blk(ctx));  dpad.addView(ctrlBtnRef(ctx,"↑","DPAD_UP")); dpad.addView(blk(ctx))
        dpad.addView(ctrlBtnRef(ctx,"←","DPAD_LEFT"))
        dpad.addView(blk(ctx))
        dpad.addView(ctrlBtnRef(ctx,"→","DPAD_RIGHT"))
        dpad.addView(blk(ctx));  dpad.addView(ctrlBtnRef(ctx,"↓","DPAD_DOWN")); dpad.addView(blk(ctx))
        midRow.addView(dpad); midRow.addView(hSpace(ctx,8))

        // Centre column: SEL · PS · STA
        val centre = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        centre.addView(ctrlBtnRef(ctx,"SEL","BTN_SELECT", size=36))
        centre.addView(vSpace(ctx,4))
        val ps = PsButtonView(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(dp(ctx,52),dp(ctx,52)).apply { setMargins(2,2,2,2) }
            setOnClickListener { onPsClick(ctx, this) }
            setOnLongClickListener { stopCtrlRec(ctx); true }
        }
        psBtn = ps; centre.addView(ps)
        centre.addView(vSpace(ctx,4))
        centre.addView(ctrlBtnRef(ctx,"STA","BTN_START", size=36))
        midRow.addView(centre); midRow.addView(hSpace(ctx,8))

        // Face buttons: [blk][X][blk] / [Y][MENU][A] / [blk][B][blk]
        val face = GridLayout(ctx).apply { columnCount=3; rowCount=3 }
        face.addView(blk(ctx))
        face.addView(ctrlBtnRef(ctx,"X","BTN_X"))
        face.addView(blk(ctx))
        face.addView(ctrlBtnRef(ctx,"Y","BTN_Y"))

        // ── MENU BUTTON (between Y/□ and A/○) ────────────
        val menuBtn = MenuButtonView(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(dp(ctx,44),dp(ctx,44)).apply { setMargins(3,3,3,3) }
            onLongPressDetected = { v -> showRadialMenu(ctx, v) }
            onDragRelease = { rx, ry ->
                // If finger released over earth rect → open main menu
                if (earthScreenRect.contains(rx, ry)) {
                    dismissRadialMenu()
                    showMainMenu(ctx)
                } else {
                    dismissRadialMenu()
                }
            }
        }
        face.addView(menuBtn)
        face.addView(ctrlBtnRef(ctx,"A","BTN_A"))
        face.addView(blk(ctx))
        face.addView(ctrlBtnRef(ctx,"B","BTN_B"))
        face.addView(blk(ctx))
        midRow.addView(face)
        root.addView(midRow)

        // Row 3: analog sticks
        root.addView(centreRow(ctx,
            JoystickView(ctx,"L") { nx,ny -> ctrlEvent(ctx,"ANALOG_L:$nx:$ny") },
            hSpace(ctx,80),
            JoystickView(ctx,"R") { nx,ny -> ctrlEvent(ctx,"ANALOG_R:$nx:$ny") }
        ))

        // Default: touches pass through to Dolphin. Double-tap Ash to flip.
        val touchFlag = if (controllerTappable) 0
                        else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or touchFlag,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM }
        wm?.addView(root, params); controllerWin = root; controllerWinParams = params
    }

    // ══════════════════════════════════════════════════════════════════════
    //  Horizontal GameCube controller layout (state 1 — default)
    //
    //  Full-screen transparent overlay so buttons sit over the game exactly
    //  like Dolphin's built-in touch controller.  Left cluster on the left
    //  edge, right cluster on the right edge, START/PS centred at bottom.
    // ══════════════════════════════════════════════════════════════════════

    private fun buildControllerHorizontal(ctx: Context) {
        buttonRefs.clear()

        // Root: full-screen, transparent — game shows through.
        // Override dispatchTouchEvent so that touches landing on transparent
        // gaps return false → WindowManager propagates them to the window
        // below (Dolphin / phone), while button areas still consume their touches.
        val root = object : FrameLayout(ctx) {
            override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
                return super.dispatchTouchEvent(ev) // false = falls through to phone
            }
            override fun onInterceptTouchEvent(ev: MotionEvent) = false // never steal from children
        }
        root.setBackgroundColor(Color.TRANSPARENT)

        // ── LEFT CLUSTER ──────────────────────────────────────────────────
        // L shoulder → Z → Left-stick → D-pad  (top to bottom, left edge)
        val leftCol = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity     = Gravity.CENTER_HORIZONTAL
            setPadding(dp(ctx, 8), dp(ctx, 20), dp(ctx, 8), dp(ctx, 20))
        }
        leftCol.addView(gcShoulderBtn(ctx, "L", "BTN_L1"))
        leftCol.addView(vSpace(ctx, 6))
        leftCol.addView(gcSmallBtn(ctx, "Z", "BTN_SELECT"))
        leftCol.addView(vSpace(ctx, 14))
        leftCol.addView(JoystickView(ctx, "L") { nx, ny -> ctrlEvent(ctx, "ANALOG_L:$nx:$ny") })
        leftCol.addView(vSpace(ctx, 14))

        val dpad = GridLayout(ctx).apply { columnCount = 3; rowCount = 3 }
        dpad.addView(blk(ctx, 40)); dpad.addView(gcFaceBtn(ctx, "↑", "DPAD_UP",    40)); dpad.addView(blk(ctx, 40))
        dpad.addView(gcFaceBtn(ctx, "←", "DPAD_LEFT",  40))
        dpad.addView(blk(ctx, 40))
        dpad.addView(gcFaceBtn(ctx, "→", "DPAD_RIGHT", 40))
        dpad.addView(blk(ctx, 40)); dpad.addView(gcFaceBtn(ctx, "↓", "DPAD_DOWN",  40)); dpad.addView(blk(ctx, 40))
        leftCol.addView(dpad)

        root.addView(leftCol, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.START or Gravity.CENTER_VERTICAL
        ))

        // ── RIGHT CLUSTER ─────────────────────────────────────────────────
        // R shoulder → face buttons (Y/B/X/A diamond) + C-stick  (top to bottom, right edge)
        val rightCol = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity     = Gravity.CENTER_HORIZONTAL
            setPadding(dp(ctx, 8), dp(ctx, 20), dp(ctx, 8), dp(ctx, 20))
        }
        rightCol.addView(gcShoulderBtn(ctx, "R", "BTN_R1"))
        rightCol.addView(vSpace(ctx, 10))

        // Face diamond: [ ][Y][ ] / [B][ ][X] / [ ][A][ ]
        val faceGrid = GridLayout(ctx).apply { columnCount = 3; rowCount = 3 }
        faceGrid.addView(blk(ctx, 44)); faceGrid.addView(gcFaceBtn(ctx, "Y", "BTN_Y")); faceGrid.addView(blk(ctx, 44))
        faceGrid.addView(gcFaceBtn(ctx, "B", "BTN_B")); faceGrid.addView(blk(ctx, 44)); faceGrid.addView(gcFaceBtn(ctx, "X", "BTN_X"))
        faceGrid.addView(blk(ctx, 44)); faceGrid.addView(gcFaceBtn(ctx, "A", "BTN_A")); faceGrid.addView(blk(ctx, 44))
        rightCol.addView(faceGrid)
        rightCol.addView(vSpace(ctx, 14))

        // C-stick (right analog)
        rightCol.addView(JoystickView(ctx, "C") { nx, ny -> ctrlEvent(ctx, "ANALOG_R:$nx:$ny") })

        root.addView(rightCol, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.END or Gravity.CENTER_VERTICAL
        ))

        // ── CENTER BOTTOM: START + PS ─────────────────────────────────────
        val centre = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity     = Gravity.CENTER_HORIZONTAL
            setPadding(0, 0, 0, dp(ctx, 24))
        }
        centre.addView(gcSmallBtn(ctx, "START", "BTN_START"))
        centre.addView(vSpace(ctx, 6))
        val ps2 = PsButtonView(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(dp(ctx, 48), dp(ctx, 48))
            setOnClickListener { onPsClick(ctx, this) }
            setOnLongClickListener { stopCtrlRec(ctx); true }
        }
        psBtn = ps2; centre.addView(ps2)

        root.addView(centre, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        ))

        // Full-screen overlay — transparent, passes touches through by default
        val touchFlag = if (controllerTappable) 0
                        else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or touchFlag,
            PixelFormat.TRANSLUCENT
        )
        wm?.addView(root, params); controllerWin = root; controllerWinParams = params
    }

    // ══════════════════════════════════════════════════════════════════════
    //  PS button logic (controller recording)
    // ══════════════════════════════════════════════════════════════════════

    private fun onPsClick(ctx: Context, ps: PsButtonView) {
        if (!ctrlRecording) {
            ctrlRecording = true; ctrlBuffer.clear(); keyframeCount = 0
            ps.setRecording(true)
            toast(ctx,"Controller REC — tap PS to stamp keyframe, long-press to save")
        } else {
            keyframeCount++
            ctrlBuffer.add("KEYFRAME_$keyframeCount:${System.currentTimeMillis()}")
            toast(ctx,"Keyframe $keyframeCount stamped")
        }
    }

    private fun stopCtrlRec(ctx: Context) {
        if (!ctrlRecording) { toast(ctx,"Not recording"); return }
        ctrlRecording = false; psBtn?.setRecording(false)
        if (ctrlBuffer.isEmpty()) { toast(ctx,"Nothing recorded"); return }
        val fn = "keyframes_${ctrlRecCounter}.txt"; ctrlRecCounter++
        saveStringArray(ctx, fn, ctrlBuffer, "$keyframeCount keyframes")
    }

    private fun ctrlEvent(ctx: Context, tag: String) {
        writeCmd(tag)
        injectButton(tag)   // also fire directly into Dolphin via GamepadInjector
        if (ctrlRecording) ctrlBuffer.add("$tag:${System.currentTimeMillis()}")
    }

    // ══════════════════════════════════════════════════════════════════════
    //  Radial (Nokia-style) menu
    // ══════════════════════════════════════════════════════════════════════

    /**
     * Shows a small bubble with an Earth icon above the menu button.
     * The caller (MenuButtonView) continues to track touch; when the finger
     * lifts over the Earth screen rect, onDragRelease fires and we open the main menu.
     */
    private fun showRadialMenu(ctx: Context, anchor: View) {
        if (radialWin != null) return

        // Derive screen position of the anchor button
        val loc = IntArray(2); anchor.getLocationOnScreen(loc)
        val btnCX = loc[0] + anchor.width / 2f
        val btnTop = loc[1].toFloat()

        // Build the bubble
        val bubbleSize = dp(ctx, 80)
        val bubble = FrameLayout(ctx).apply {
            setBackgroundColor(Color.TRANSPARENT)
        }

        val earth = EarthView(ctx).apply {
            layoutParams = FrameLayout.LayoutParams(bubbleSize, bubbleSize)
        }
        bubble.addView(earth)

        // Position: centred above the button
        val margin = dp(ctx, 8)
        val winX = (btnCX - bubbleSize / 2f).toInt()
        val winY = (btnTop - bubbleSize - margin).toInt().coerceAtLeast(0)

        val params = WindowManager.LayoutParams(
            bubbleSize, bubbleSize + dp(ctx,16),
            overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = winX; y = winY }

        wm?.addView(bubble, params); radialWin = bubble

        // Record earth screen rect so MenuButtonView can check drag-release
        earthScreenRect.set(
            winX.toFloat(), winY.toFloat(),
            (winX + bubbleSize).toFloat(), (winY + bubbleSize).toFloat()
        )

        // Also allow direct tap on earth (in case user lifts inside the radial window)
        earth.setOnClickListener {
            dismissRadialMenu()
            showMainMenu(ctx)
        }
    }

    private fun dismissRadialMenu() {
        radialWin?.let { try { wm?.removeView(it) } catch (_:Exception) {} }
        radialWin = null
        earthScreenRect.setEmpty()
    }

    // ══════════════════════════════════════════════════════════════════════
    //  Main Menu (ash overlay)
    // ══════════════════════════════════════════════════════════════════════

    private fun showMainMenu(ctx: Context) {
        if (mainMenuWin != null) return

        val dm = ctx.resources.displayMetrics

        // Root: ash-coloured full overlay
        val root = FrameLayout(ctx).apply {
            setBackgroundColor(Color.argb(238, 90, 90, 95))  // ash
        }

        // Card inside
        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(245, 30, 30, 38))
            setPadding(dp(ctx,12), dp(ctx,12), dp(ctx,12), dp(ctx,12))
        }

        // ── Header ─────────────────────────────────────────
        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(ctx).apply {
            text = "◆ MENU"; textSize = 16f; setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        header.addView(Button(ctx).apply {
            text = "✕"; textSize = 14f; setTextColor(Color.WHITE)
            setBackgroundColor(0xFF661111.toInt())
            layoutParams = LinearLayout.LayoutParams(dp(ctx,44), dp(ctx,44))
            setOnClickListener { dismissMainMenu() }
        })
        card.addView(header)
        card.addView(divider(ctx))

        // ── Tab strip ──────────────────────────────────────
        val tabBar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(ctx,8), 0, dp(ctx,8))
        }
        val contentHost = FrameLayout(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        }

        val tabs = listOf("▶ PLAYBACK","📷 SHOTS","⚙ CUSTOM")
        val tabBtns = mutableListOf<Button>()
        tabs.forEachIndexed { i, label ->
            val b = Button(ctx).apply {
                text = label; textSize = 10f; setTextColor(Color.WHITE)
                setBackgroundColor(if (i==0) 0xFF3A86FF.toInt() else 0xFF333344.toInt())
                layoutParams = LinearLayout.LayoutParams(0, dp(ctx,40), 1f).apply { setMargins(2,0,2,0) }
            }
            b.setOnClickListener {
                tabBtns.forEach { it.setBackgroundColor(0xFF333344.toInt()) }
                b.setBackgroundColor(0xFF3A86FF.toInt())
                contentHost.removeAllViews()
                when (i) {
                    0 -> contentHost.addView(buildPlaybackTab(ctx))
                    1 -> contentHost.addView(buildShotsTab(ctx))
                    2 -> contentHost.addView(buildCustomTab(ctx))
                }
            }
            tabBtns.add(b); tabBar.addView(b)
        }
        card.addView(tabBar)

        // Default to playback tab
        contentHost.addView(buildPlaybackTab(ctx))
        card.addView(contentHost)

        val lp = FrameLayout.LayoutParams(
            (dm.widthPixels * 0.94f).toInt(),
            (dm.heightPixels * 0.78f).toInt(),
            Gravity.CENTER
        )
        root.addView(card, lp)

        // Dismiss on outside tap (tap ash area)
        root.setOnClickListener { dismissMainMenu() }
        card.setOnClickListener { /* consume — don't dismiss */ }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        )
        wm?.addView(root, params); mainMenuWin = root
    }

    private fun dismissMainMenu() {
        mainMenuWin?.let { try { wm?.removeView(it) } catch (_:Exception) {} }
        mainMenuWin = null
    }

    // ── Tab 1: Playback ────────────────────────────────────

    private fun buildPlaybackTab(ctx: Context): View {
        val sv = ScrollView(ctx)
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(ctx,8), 0, dp(ctx,8))
        }

        val dir = ctx.getExternalFilesDir(null)
        val files = dir?.listFiles { f -> f.name.startsWith("keyframes_") && f.name.endsWith(".txt") }
            ?.sortedBy { it.name } ?: emptyList()

        if (files.isEmpty()) {
            col.addView(TextView(ctx).apply {
                text = "No keyframe files yet.\nRecord with the PS button then long-press to save."
                setTextColor(0xFFAAAAAA.toInt()); textSize = 12f; setPadding(dp(ctx,8),dp(ctx,16),dp(ctx,8),0)
            })
        } else {
            files.forEach { file ->
                val row = LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(ctx,4), dp(ctx,4), dp(ctx,4), dp(ctx,4))
                }
                row.addView(TextView(ctx).apply {
                    text = file.name; setTextColor(Color.WHITE); textSize = 12f
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                })
                row.addView(Button(ctx).apply {
                    text = "▶ Play"; textSize = 10f; setTextColor(Color.WHITE)
                    setBackgroundColor(0xFF2D7A2D.toInt())
                    layoutParams = LinearLayout.LayoutParams(dp(ctx,70), dp(ctx,36)).apply { setMargins(4,0,0,0) }
                    setOnClickListener { startPlayback(ctx, file) }
                })
                col.addView(row)
                col.addView(divider(ctx))
            }
        }

        // Stop playback button
        col.addView(Button(ctx).apply {
            text = "■ Stop Playback"; textSize = 11f; setTextColor(Color.WHITE)
            setBackgroundColor(0xFF882222.toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(ctx,44)).apply { setMargins(0,dp(ctx,12),0,0) }
            setOnClickListener { stopPlayback(); toast(ctx,"Playback stopped") }
        })

        sv.addView(col); return sv
    }

    // ── Tab 2: Screenshots ─────────────────────────────────

    private fun buildShotsTab(ctx: Context): View {
        val sv = ScrollView(ctx)
        val grid = GridLayout(ctx).apply {
            columnCount = 3
            setPadding(dp(ctx,4), dp(ctx,4), dp(ctx,4), dp(ctx,4))
        }

        val shotDir = File(
            android.os.Environment.getExternalStoragePublicDirectory(
                android.os.Environment.DIRECTORY_DCIM), "Screenshots"
        )
        val pngs = shotDir.listFiles { f -> f.extension.toLowerCase() == "png" }
            ?.sortedByDescending { it.lastModified() } ?: emptyList()

        if (pngs.isEmpty()) {
            sv.addView(TextView(ctx).apply {
                text = "No screenshots found in DCIM/Screenshots"
                setTextColor(0xFFAAAAAA.toInt()); textSize = 12f; setPadding(dp(ctx,8),dp(ctx,16),dp(ctx,8),0)
            })
            return sv
        }

        pngs.take(30).forEach { file ->
            val cell = FrameLayout(ctx).apply {
                val s = dp(ctx, 90)
                layoutParams = GridLayout.LayoutParams().apply {
                    width = s; height = s; setMargins(4,4,4,4)
                }
                setBackgroundColor(0xFF222233.toInt())
            }

            val iv = ImageView(ctx).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                layoutParams = FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            }
            // Load thumbnail on background thread
            Thread {
                try {
                    val opts = BitmapFactory.Options().apply { inSampleSize = 4 }
                    val bmp = BitmapFactory.decodeFile(file.absolutePath, opts)
                    mainH.post { iv.setImageBitmap(bmp) }
                } catch (_: Exception) {}
            }.start()

            cell.addView(iv)

            // Selected highlight ring
            cell.setOnClickListener {
                try {
                    val opts = BitmapFactory.Options().apply { inSampleSize = 2 }
                    selectedShot = BitmapFactory.decodeFile(file.absolutePath, opts)
                    // Scale to button size
                    selectedShot = selectedShot?.let {
                        Bitmap.createScaledBitmap(it, dp(ctx,44), dp(ctx,44), true)
                    }
                    toast(ctx, "Screenshot selected — go to CUSTOM tab to assign")
                } catch (_: Exception) { toast(ctx,"Could not load screenshot") }
                // highlight selection
                cell.setBackgroundColor(0xFF3A86FF.toInt())
            }

            grid.addView(cell)
        }

        sv.addView(grid); return sv
    }

    // ── Tab 3: Custom buttons ──────────────────────────────

    private fun buildCustomTab(ctx: Context): View {
        val sv = ScrollView(ctx)
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(ctx,8), dp(ctx,8), dp(ctx,8), dp(ctx,8))
        }

        col.addView(TextView(ctx).apply {
            text = "Hold a slot to assign the selected screenshot + last keyframe file.\nTap to execute."
            setTextColor(0xFFAAAAAA.toInt()); textSize = 11f; setPadding(0,0,0,dp(ctx,8))
        })

        val grid = GridLayout(ctx).apply { columnCount = 3 }

        for (i in 0..5) {
            val cell = FrameLayout(ctx).apply {
                val s = dp(ctx, 100)
                layoutParams = GridLayout.LayoutParams().apply {
                    width = s; height = s; setMargins(6,6,6,6)
                }
                setBackgroundColor(0xFF1E1E2E.toInt())
            }

            // Show existing icon if assigned
            val iv = ImageView(ctx).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                layoutParams = FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
                customSlots[i]?.let { setImageBitmap(it) }
                    ?: setBackgroundColor(0xFF2D2D44.toInt())
            }
            cell.addView(iv)

            val label = TextView(ctx).apply {
                text = if (customSlotActions[i] != null) "Slot ${i+1}\n${customSlotActions[i]}" else "Slot ${i+1}"
                setTextColor(Color.WHITE); textSize = 9f; gravity = Gravity.CENTER
                layoutParams = FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT,
                    Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = 4 }
                setBackgroundColor(Color.argb(140, 0, 0, 0))
            }
            cell.addView(label)

            // Tap → execute (play associated keyframe)
            cell.setOnClickListener {
                val fn = customSlotActions[i]
                if (fn != null) {
                    val f = File(ctx.getExternalFilesDir(null), fn)
                    if (f.exists()) startPlayback(ctx, f) else toast(ctx,"File not found: $fn")
                } else toast(ctx,"Slot ${i+1} empty — long-press to assign")
            }

            // Long press → assign current selection
            cell.setOnLongClickListener {
                val shot = selectedShot
                if (shot != null) {
                    customSlots[i] = shot
                    iv.setImageBitmap(shot)
                }
                // Find the latest keyframe file and link it
                val dir = ctx.getExternalFilesDir(null)
                val latest = dir?.listFiles { f -> f.name.startsWith("keyframes_") }
                    ?.maxByOrNull { it.lastModified() }
                customSlotActions[i] = latest?.name
                label.text = "Slot ${i+1}\n${latest?.name ?: "(no file)"}"
                cell.setBackgroundColor(0xFF2244AA.toInt())
                toast(ctx,"Slot ${i+1} assigned → ${latest?.name ?: "no file"}")
                true
            }

            grid.addView(cell)
        }

        col.addView(grid); sv.addView(col); return sv
    }

    // ══════════════════════════════════════════════════════════════════════
    //  Playback engine
    // ══════════════════════════════════════════════════════════════════════

    private fun startPlayback(ctx: Context, file: File) {
        stopPlayback()
        toast(ctx,"Playing: ${file.name}")

        val lines = try {
            file.readLines()
                .map { it.trim() }
                .filter { it.isNotEmpty() && !it.startsWith("//") && !it.startsWith("String") && !it.startsWith("}") }
                .map { it.trimStart('"').trimEnd('"').trimEnd(',').trim() }
        } catch (e: Exception) { toast(ctx,"Read error: ${e.message}"); return }

        playbackThread = Thread {
            var prevTs = -1L
            for (line in lines) {
                if (Thread.currentThread().isInterrupted) break
                try {
                    val parts = line.split(":")
                    val tag = parts[0]

                    // Extract timestamp (last numeric token)
                    val ts = parts.last().toLongOrNull()

                    // Wait relative to previous event for realistic timing
                    if (ts != null && prevTs > 0) {
                        val delay = (ts - prevTs).coerceIn(0, 2000)
                        if (delay > 0) Thread.sleep(delay)
                    } else {
                        Thread.sleep(200)
                    }
                    if (ts != null) prevTs = ts

                    when {
                        tag == "KEYFRAME" -> {
                            val num = parts.getOrNull(1)?.trimEnd(':')?.takeLast(4) ?: ""
                            mainH.post { toast(ctx, "▶ Keyframe $num") }
                        }
                        tag.startsWith("ANALOG") -> { /* no visual for now */ }
                        else -> {
                            // Flash controller button
                            mainH.post { flashButton(tag) }
                            // Also dispatch gesture if it's a screen event
                            if (tag == "TAP" || tag == "SWIPE") {
                                mainH.post { dispatchEntry(line) }
                            }
                        }
                    }
                } catch (e: InterruptedException) { break }
                catch (_: Exception) {}
            }
            mainH.post { toast(ctx,"Playback complete") }
        }.also { it.start() }
    }

    private fun stopPlayback() {
        playbackThread?.interrupt(); playbackThread = null
    }

    /** Briefly flash a controller button yellow then restore it. */
    private fun flashButton(tag: String) {
        val v = buttonRefs[tag] ?: return
        val orig = (v.background as? android.graphics.drawable.ColorDrawable)?.color ?: 0xFF2D2D44.toInt()
        v.setBackgroundColor(0xFFFFDD00.toInt())
        mainH.postDelayed({ v.setBackgroundColor(orig) }, 300)
    }

    // ══════════════════════════════════════════════════════════════════════
    //  Screen-rec (REC1 / REC2) — top bar, state 2
    // ══════════════════════════════════════════════════════════════════════

    private fun buildTopBar(ctx: Context) {
        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xDD1A1A2E.toInt())
            setPadding(dp(ctx,4), dp(ctx,4), dp(ctx,4), dp(ctx,4))
            gravity = Gravity.CENTER_VERTICAL
        }
        val btnStep = Button(ctx).apply {
            text="Step"; textSize=11f; setTextColor(Color.WHITE)
            setBackgroundColor(0xFF3A86FF.toInt()); setOnClickListener { onStep(ctx) }
        }
        btnRec1 = Button(ctx).apply {
            text="● REC1"; textSize=11f; setTextColor(Color.WHITE)
            setBackgroundColor(0xFF555555.toInt()); setOnClickListener { toggleRec1(ctx) }
        }
        btnRec2 = Button(ctx).apply {
            text="● REC2"; textSize=11f; setTextColor(Color.WHITE)
            setBackgroundColor(0xFF555555.toInt()); setOnClickListener { toggleRec2(ctx) }
        }
        bar.addView(btnStep); bar.addView(hSpace(ctx,6))
        bar.addView(btnRec1); bar.addView(hSpace(ctx,4))
        bar.addView(btnRec2)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity=Gravity.TOP or Gravity.END; y=dp(ctx,8); x=dp(ctx,8) }
        wm?.addView(bar,params); topBarWin=bar
    }

    private fun buildStopButton(ctx: Context) {
        if (stopWin!=null) return
        val btn = Button(ctx).apply {
            text="■ STOP"; textSize=13f; setTextColor(Color.WHITE)
            setBackgroundColor(0xFFCC0000.toInt()); setOnClickListener { stopScreenRec(ctx) }
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity=Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y=dp(ctx,32) }
        wm?.addView(btn,params); stopWin=btn
    }

    private fun toggleRec1(ctx: Context) {
        when (recMode) {
            RecMode.NONE -> {
                recMode=RecMode.REC1; recBuffer.clear(); stepCursor=0
                btnRec1?.apply { text="● REC1 ON"; setBackgroundColor(0xFFDD0000.toInt()) }
                buildStopButton(ctx)
                toast(ctx,"REC1: drag trainer, tap REC1 to record each step position")
            }
            RecMode.REC1 -> {
                val cx=trainerX+dp(ctx,45); val cy=trainerY+dp(ctx,55)
                recBuffer.add("TAP:$cx:$cy")
                toast(ctx,"Step ${recBuffer.size} @ ($cx,$cy)")
            }
            else -> {}
        }
    }

    private fun onStep(ctx: Context) {
        if (recBuffer.isEmpty()) { toast(ctx,"No steps"); return }
        if (stepCursor>=recBuffer.size) { toast(ctx,"All ${recBuffer.size} steps done"); stepCursor=0; return }
        val e=recBuffer[stepCursor++]; toast(ctx,"Step $stepCursor/${recBuffer.size}: $e"); dispatchEntry(e)
    }

    private fun toggleRec2(ctx: Context) {
        when (recMode) {
            RecMode.NONE -> {
                recMode=RecMode.REC2; recBuffer.clear(); stepCursor=0
                btnRec2?.apply { text="● REC2 ON"; setBackgroundColor(0xFFDD0000.toInt()) }
                // Capture overlay first, stop button second so STOP is on top and receives touches
                buildCaptureOverlay(ctx); buildStopButton(ctx)
                toast(ctx,"REC2 live — interact normally")
            }
            RecMode.REC2 -> toast(ctx,"${recBuffer.size} events so far")
            else -> {}
        }
    }

    private fun buildCaptureOverlay(ctx: Context) {
        val v = View(ctx); v.setBackgroundColor(Color.TRANSPARENT)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
        var dx=0f; var dy=0f; var dt=0L
        v.setOnTouchListener { _, ev ->
            val rx=ev.rawX.toInt(); val ry=ev.rawY.toInt()
            when(ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    dx=ev.rawX; dy=ev.rawY; dt=System.currentTimeMillis()
                    moveTrainer(ctx, rx-dp(ctx,45), ry-dp(ctx,55))
                }
                MotionEvent.ACTION_UP -> {
                    val dur=System.currentTimeMillis()-dt
                    val ddx=ev.rawX-dx; val ddy=ev.rawY-dy
                    val dist=sqrt((ddx*ddx+ddy*ddy).toDouble())
                    val entry=if(dist<dp(ctx,12)) "TAP:$rx:$ry"
                    else "SWIPE:${dx.toInt()}:${dy.toInt()}:$rx:$ry:$dur"
                    recBuffer.add(entry); dispatchEntry(entry)
                }
            }; true
        }
        wm?.addView(v,params); captureWin=v
    }

    private fun stopScreenRec(ctx: Context) {
        val mode=recMode; recMode=RecMode.NONE
        captureWin?.let { wm?.removeView(it) }; captureWin=null
        btnRec1?.apply { text="● REC1"; setBackgroundColor(0xFF555555.toInt()) }
        btnRec2?.apply { text="● REC2"; setBackgroundColor(0xFF555555.toInt()) }
        stopWin?.let { wm?.removeView(it) }; stopWin=null
        if (recBuffer.isEmpty()) { toast(ctx,"Nothing recorded"); return }
        val prefix=if(mode==RecMode.REC1) "rec_steps" else "rec_live"
        saveStringArray(ctx,"${prefix}_${recCounter}.txt",recBuffer,"${recBuffer.size} entries")
        recCounter++; stepCursor=0
    }

    // ══════════════════════════════════════════════════════════════════════
    //  Gesture dispatch
    // ══════════════════════════════════════════════════════════════════════

    private fun dispatchEntry(entry: String) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return
        val svc=service ?: return; val parts=entry.split(":")
        try {
            when(parts[0]) {
                "TAP" -> {
                    val path=Path().apply { moveTo(parts[1].toFloat(),parts[2].toFloat()) }
                    svc.dispatchGesture(GestureDescription.Builder()
                        .addStroke(GestureDescription.StrokeDescription(path,0,100)).build(),null,null)
                }
                "SWIPE" -> {
                    val path=Path().apply { moveTo(parts[1].toFloat(),parts[2].toFloat()); lineTo(parts[3].toFloat(),parts[4].toFloat()) }
                    val dur=if(parts.size>5) parts[5].toLong().coerceIn(100,2000) else 400L
                    svc.dispatchGesture(GestureDescription.Builder()
                        .addStroke(GestureDescription.StrokeDescription(path,0,dur)).build(),null,null)
                }
            }
        } catch(e:Exception){ android.util.Log.e("FloatingOverlay","dispatch: $e") }
    }

    // ══════════════════════════════════════════════════════════════════════
    //  MenuButtonView — face-centre, long-press radial trigger
    // ══════════════════════════════════════════════════════════════════════

    class MenuButtonView(ctx: Context) : View(ctx) {

        var onLongPressDetected: ((View) -> Unit)? = null
        /** rawX, rawY of finger-up after long press was shown */
        var onDragRelease: ((Float, Float) -> Unit)? = null

        private var longPressShown = false
        private val lph = Handler(Looper.getMainLooper())
        private val lpRun = Runnable {
            longPressShown = true
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
                performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
            onLongPressDetected?.invoke(this)
        }

        private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF1E1E3A.toInt() }
        private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style=Paint.Style.STROKE; strokeWidth=2.5f; color=0xFF8888BB.toInt() }
        private val symPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color=0xFFCCCCDD.toInt(); textAlign=Paint.Align.CENTER; typeface=Typeface.DEFAULT_BOLD }

        override fun onTouchEvent(ev: MotionEvent): Boolean {
            when(ev.action) {
                MotionEvent.ACTION_DOWN -> { lph.postDelayed(lpRun,480); longPressShown=false }
                MotionEvent.ACTION_CANCEL,
                MotionEvent.ACTION_UP -> {
                    lph.removeCallbacks(lpRun)
                    if (longPressShown) { longPressShown=false; onDragRelease?.invoke(ev.rawX,ev.rawY) }
                }
            }; return true
        }

        override fun onDraw(c: Canvas) {
            val cx=width/2f; val cy=height/2f; val r=min(cx,cy)-3f
            c.drawCircle(cx,cy,r,bgPaint); c.drawCircle(cx,cy,r,ringPaint)
            symPaint.textSize=r*0.52f
            // Draw three horizontal lines (hamburger/menu symbol)
            val lw=r*0.55f; val gap=r*0.22f
            val linePaint=Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color=0xFFCCCCDD.toInt(); strokeWidth=r*0.12f; strokeCap=Paint.Cap.ROUND }
            c.drawLine(cx-lw,cy-gap,cx+lw,cy-gap,linePaint)
            c.drawLine(cx-lw,cy,       cx+lw,cy,       linePaint)
            c.drawLine(cx-lw,cy+gap,cx+lw,cy+gap,linePaint)
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    //  EarthView — canvas-drawn globe
    // ══════════════════════════════════════════════════════════════════════

    class EarthView(ctx: Context) : View(ctx) {

        private val oceanPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val landPaint  = Paint(Paint.ANTI_ALIAS_FLAG).apply { color=0xFF2E7D32.toInt() }
        private val rimPaint   = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style=Paint.Style.STROKE; strokeWidth=3f; color=0xFF88BBFF.toInt() }
        private val glowPaint  = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style=Paint.Style.STROKE; strokeWidth=8f; color=Color.argb(80,100,180,255) }
        private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color=Color.WHITE; textAlign=Paint.Align.CENTER; typeface=Typeface.DEFAULT_BOLD }

        override fun onDraw(c: Canvas) {
            val cx=width/2f; val cy=height/2f; val r=min(cx,cy)-6f

            // Ocean gradient
            oceanPaint.shader = RadialGradient(cx-r*0.25f, cy-r*0.25f, r*1.2f,
                intArrayOf(0xFF1565C0.toInt(), 0xFF0D47A1.toInt(), 0xFF01579B.toInt()),
                floatArrayOf(0f,0.5f,1f), Shader.TileMode.CLAMP)
            c.drawCircle(cx,cy,r,oceanPaint)

            // Glow ring
            c.drawCircle(cx,cy,r+4f,glowPaint)

            // Landmasses (simplified blobs)
            // Americas
            val lp = Path().apply {
                moveTo(cx-r*0.42f, cy-r*0.55f)
                cubicTo(cx-r*0.52f,cy-r*0.3f, cx-r*0.60f,cy, cx-r*0.48f,cy+r*0.5f)
                cubicTo(cx-r*0.30f,cy+r*0.4f, cx-r*0.20f,cy+r*0.1f, cx-r*0.28f,cy-r*0.3f)
                cubicTo(cx-r*0.28f,cy-r*0.45f, cx-r*0.35f,cy-r*0.55f, cx-r*0.42f,cy-r*0.55f)
            }
            c.drawPath(lp, landPaint)

            // Eurasia+Africa blob
            val ep = Path().apply {
                moveTo(cx+r*0.05f, cy-r*0.55f)
                cubicTo(cx+r*0.35f,cy-r*0.50f, cx+r*0.55f,cy-r*0.20f, cx+r*0.50f,cy+r*0.10f)
                cubicTo(cx+r*0.40f,cy+r*0.45f, cx+r*0.15f,cy+r*0.55f, cx+r*0.05f,cy+r*0.50f)
                cubicTo(cx-r*0.05f,cy+r*0.20f, cx+r*0.00f,cy-r*0.20f, cx+r*0.05f,cy-r*0.55f)
            }
            c.drawPath(ep, landPaint)

            // Clip to sphere
            c.drawCircle(cx,cy,r,rimPaint)

            // Label
            labelPaint.textSize = r * 0.28f
            c.drawText("Earth", cx, cy+r+labelPaint.textSize+4f, labelPaint.apply { color=Color.WHITE })
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    //  PS Button — drawn circle with glow when recording
    // ══════════════════════════════════════════════════════════════════════

    class PsButtonView(ctx: Context) : View(ctx) {
        private var recording = false
        private val bgPaint  = Paint(Paint.ANTI_ALIAS_FLAG)
        private val ringPaint= Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style=Paint.Style.STROKE; strokeWidth=3f; color=0xFF4488FF.toInt() }
        private val textPaint= Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color=Color.WHITE; typeface=Typeface.create(Typeface.DEFAULT,Typeface.BOLD); textAlign=Paint.Align.CENTER }
        private val glowPaint= Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style=Paint.Style.STROKE; strokeWidth=6f; color=0xFFFF2222.toInt() }

        fun setRecording(on: Boolean) { recording=on; invalidate() }

        override fun onDraw(c: Canvas) {
            val cx=width/2f; val cy=height/2f; val r=min(cx,cy)-4f
            bgPaint.shader=RadialGradient(cx,cy,r,
                intArrayOf(0xFF2B5FC9.toInt(),0xFF040420.toInt()),floatArrayOf(0f,1f),Shader.TileMode.CLAMP)
            c.drawCircle(cx,cy,r,bgPaint)
            if (recording) { glowPaint.setShadowLayer(12f,0f,0f,0xFFFF0000.toInt()); c.drawCircle(cx,cy,r+3f,glowPaint) }
            c.drawCircle(cx,cy,r,ringPaint)
            textPaint.textSize=r*0.55f; c.drawText("PS",cx,cy+textPaint.textSize*0.35f,textPaint)
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    //  Joystick — virtual analog stick
    // ══════════════════════════════════════════════════════════════════════

    class JoystickView(ctx: Context, private val lbl: String, private val onMove:(String,String)->Unit) : View(ctx) {
        private val basePaint =Paint(Paint.ANTI_ALIAS_FLAG).apply{ color=0xFF222233.toInt() }
        private val ringPaint =Paint(Paint.ANTI_ALIAS_FLAG).apply{ style=Paint.Style.STROKE; strokeWidth=2f; color=0xFF4444AA.toInt() }
        private val thumbPaint=Paint(Paint.ANTI_ALIAS_FLAG).apply{ color=0xFF5588FF.toInt() }
        private val lblPaint  =Paint(Paint.ANTI_ALIAS_FLAG).apply{ color=0xFF888888.toInt(); textAlign=Paint.Align.CENTER; textSize=24f }
        private var tx=0f; private var ty=0f; private var active=false
        init {
            val s=(ctx.resources.displayMetrics.density*72).toInt()
            layoutParams=LinearLayout.LayoutParams(s,s).apply{ setMargins(8,8,8,8) }
            setOnTouchListener{ _,ev ->
                val cx=width/2f; val cy=height/2f; val maxR=cx*0.55f
                when(ev.action) {
                    MotionEvent.ACTION_DOWN,MotionEvent.ACTION_MOVE -> {
                        active=true; var dx=ev.x-cx; var dy=ev.y-cy
                        val d=sqrt(dx*dx+dy*dy); if(d>maxR){val s=maxR/d;dx*=s;dy*=s}
                        tx=dx; ty=dy; onMove("%.2f".format(dx/maxR),"%.2f".format(dy/maxR)); invalidate() }
                    else -> { active=false; tx=0f; ty=0f; onMove("0.00","0.00"); invalidate() }
                }; true }
        }
        override fun onDraw(c:Canvas) {
            val cx=width/2f; val cy=height/2f; val r=min(cx,cy)-4f
            c.drawCircle(cx,cy,r,basePaint); c.drawCircle(cx,cy,r,ringPaint)
            if(!active) c.drawText(lbl,cx,cy+lblPaint.textSize*0.35f,lblPaint)
            c.drawCircle(cx+tx,cy+ty,r*0.38f,thumbPaint)
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    //  Helpers
    // ══════════════════════════════════════════════════════════════════════

    /** Creates a controller button, stores ref in buttonRefs under [refKey]. */
    private fun ctrlBtnRef(ctx: Context, label: String, refKey: String, size: Int = 44): View {
        val b = Button(ctx).apply {
            text=label; textSize=10f; setTextColor(Color.WHITE)
            setBackgroundColor(0xFF4A4A6A.toInt())   // fully opaque, matches Dolphin button look
            layoutParams=LinearLayout.LayoutParams(dp(ctx,size),dp(ctx,size)).apply{ setMargins(3,3,3,3) }
            setOnClickListener { ctrlEvent(ctx, refKey) }
        }
        buttonRefs[refKey] = b; return b
    }

    // ── GCN-style button builders ────────────────────────────────────────

    /** Standard face button: rounded square, solid grey — like Dolphin on-screen buttons. */
    private fun gcFaceBtn(ctx: Context, label: String, refKey: String, size: Int = 44): View {
        val b = Button(ctx).apply {
            text = label; textSize = 11f
            setTextColor(Color.BLACK)
            setBackgroundColor(0xFFAAAAAA.toInt())   // solid grey, fully opaque
            layoutParams = GridLayout.LayoutParams().apply {
                width = dp(ctx, size); height = dp(ctx, size); setMargins(3, 3, 3, 3)
            }
            setOnClickListener { ctrlEvent(ctx, refKey) }
        }
        buttonRefs[refKey] = b; return b
    }

    /** Wide shoulder pill (L / R). */
    private fun gcShoulderBtn(ctx: Context, label: String, refKey: String): View {
        val b = Button(ctx).apply {
            text = label; textSize = 12f
            setTextColor(Color.BLACK)
            setBackgroundColor(0xFFAAAAAA.toInt())
            layoutParams = LinearLayout.LayoutParams(dp(ctx, 64), dp(ctx, 30)).apply { setMargins(2, 2, 2, 2) }
            setOnClickListener { ctrlEvent(ctx, refKey) }
        }
        buttonRefs[refKey] = b; return b
    }

    /** Small button for Z / START. */
    private fun gcSmallBtn(ctx: Context, label: String, refKey: String): View {
        val b = Button(ctx).apply {
            text = label; textSize = 9f
            setTextColor(Color.BLACK)
            setBackgroundColor(0xFFAAAAAA.toInt())
            layoutParams = LinearLayout.LayoutParams(dp(ctx, 52), dp(ctx, 26)).apply { setMargins(2, 2, 2, 2) }
            setOnClickListener { ctrlEvent(ctx, refKey) }
        }
        buttonRefs[refKey] = b; return b
    }

    // ── Button injection ─────────────────────────────────────────────────
    //
    //  Primary path: InputManager.injectInputEvent() with SOURCE_GAMEPAD so
    //  Dolphin (which listens for gamepad events, not keyboard events) can
    //  detect and bind the press.  Sends ACTION_DOWN then ACTION_UP so the
    //  emulator sees a full, complete button event.
    //
    //  Fallback: `input keyevent <kc>` shell command (works for apps that
    //  accept keyboard input, e.g. binding menus that don't filter by source).

    private val BUTTON_KEYCODES = mapOf(
        "BTN_A"      to KeyEvent.KEYCODE_BUTTON_A,
        "BTN_B"      to KeyEvent.KEYCODE_BUTTON_B,
        "BTN_C"      to KeyEvent.KEYCODE_BUTTON_C,
        "BTN_X"      to KeyEvent.KEYCODE_BUTTON_X,
        "BTN_Y"      to KeyEvent.KEYCODE_BUTTON_Y,
        "BTN_Z"      to KeyEvent.KEYCODE_BUTTON_Z,
        "BTN_L1"     to KeyEvent.KEYCODE_BUTTON_L1,
        "BTN_R1"     to KeyEvent.KEYCODE_BUTTON_R1,
        "BTN_L2"     to KeyEvent.KEYCODE_BUTTON_L2,
        "BTN_R2"     to KeyEvent.KEYCODE_BUTTON_R2,
        "BTN_SELECT" to KeyEvent.KEYCODE_BUTTON_SELECT,
        "BTN_START"  to KeyEvent.KEYCODE_BUTTON_START,
        "DPAD_UP"    to KeyEvent.KEYCODE_DPAD_UP,
        "DPAD_DOWN"  to KeyEvent.KEYCODE_DPAD_DOWN,
        "DPAD_LEFT"  to KeyEvent.KEYCODE_DPAD_LEFT,
        "DPAD_RIGHT" to KeyEvent.KEYCODE_DPAD_RIGHT
    )

    // Cached InputManager + injectInputEvent method (reflection, set once)
    private var imInstance: Any? = null
    private var imInject: java.lang.reflect.Method? = null

    private fun ensureIm() {
        if (imInstance != null) return
        try {
            val cls = Class.forName("android.hardware.input.InputManager")
            imInstance = cls.getDeclaredMethod("getInstance").apply { isAccessible = true }.invoke(null)
            imInject   = cls.getDeclaredMethod("injectInputEvent",
                android.view.InputEvent::class.java, Int::class.java).apply { isAccessible = true }
        } catch (e: Exception) {
            android.util.Log.w("FloatingOverlay", "InputManager init: ${e.message}")
        }
    }

    private fun injectButton(tag: String) {
        if (tag.startsWith("ANALOG_")) return
        val kc = BUTTON_KEYCODES[tag] ?: return
        Thread {
            ensureIm()
            val im     = imInstance
            val inject = imInject
            val src    = InputDevice.SOURCE_GAMEPAD or InputDevice.SOURCE_JOYSTICK
            if (im != null && inject != null) {
                try {
                    val t    = SystemClock.uptimeMillis()
                    val down = KeyEvent(t, t, KeyEvent.ACTION_DOWN, kc, 0, 0,
                                       KeyCharacterMap.VIRTUAL_KEYBOARD, 0, 0, src)
                    val up   = KeyEvent(t + 80, t + 80, KeyEvent.ACTION_UP, kc, 0, 0,
                                       KeyCharacterMap.VIRTUAL_KEYBOARD, 0, 0, src)
                    inject.invoke(im, down, 0)
                    Thread.sleep(80)
                    inject.invoke(im, up, 0)
                    return@Thread
                } catch (e: Exception) {
                    android.util.Log.w("FloatingOverlay", "injectInputEvent $tag: ${e.message}")
                }
            }
            // Fallback: shell input keyevent (keyboard source — works for non-Dolphin apps)
            try {
                Runtime.getRuntime().exec(arrayOf("sh", "-c", "input keyevent $kc")).waitFor()
            } catch (e: Exception) {
                android.util.Log.w("FloatingOverlay", "shell keyevent $tag: ${e.message}")
            }
        }.start()
    }

    private fun makeParams(w:Int,h:Int)=WindowManager.LayoutParams(
        w,h,overlayType(),WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT
    ).apply{ gravity=Gravity.TOP or Gravity.START }

    private fun overlayType()=
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun blk(ctx:Context, size:Int=44)=Space(ctx).apply{ layoutParams=ViewGroup.LayoutParams(dp(ctx,size),dp(ctx,size)) }
    private fun centreRow(ctx:Context,vararg vs:View)=LinearLayout(ctx).apply{
        orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_HORIZONTAL; vs.forEach{ addView(it) } }
    private fun hSpace(ctx:Context,dpv:Int)=Space(ctx).apply{ layoutParams=LinearLayout.LayoutParams(dp(ctx,dpv),1) }
    private fun vSpace(ctx:Context,dpv:Int)=Space(ctx).apply{ layoutParams=LinearLayout.LayoutParams(1,dp(ctx,dpv)) }
    private fun divider(ctx:Context)=View(ctx).apply{
        layoutParams=LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,1).apply{ setMargins(0,4,0,4) }
        setBackgroundColor(0xFF333355.toInt()) }

    private fun dp(ctx:Context,v:Int)=(v*ctx.resources.displayMetrics.density+0.5f).toInt()

    private fun writeCmd(cmd:String){
        // BUG FIX: was writing to /sdcard/adbcom.txt (root of external storage).
        // AdbComWatcher polls DCIM/Screenshots/adbcom.txt — must use the same path.
        try{
            val dir = android.os.Environment.getExternalStoragePublicDirectory(
                android.os.Environment.DIRECTORY_DCIM)
            File(dir,"Screenshots/adbcom.txt").writeText(cmd)
        }
        catch(e:Exception){ android.util.Log.e("FloatingOverlay","writeCmd: $e") }
    }

    private fun toast(ctx:Context,msg:String)=mainH.post{ Toast.makeText(ctx,msg,Toast.LENGTH_SHORT).show() }

    private fun saveStringArray(ctx:Context,filename:String,data:List<String>,note:String){
        val dir=ctx.getExternalFilesDir(null)?:return; dir.mkdirs()
        try{
            PrintWriter(FileWriter(File(dir,filename))).use{ pw->
                pw.println("// $filename — $note")
                pw.println("String[] data = {")
                data.forEachIndexed{ i,s-> val sep=if(i<data.size-1)"," else ""; pw.println("  \"$s\"$sep") }
                pw.println("};")
            }
            toast(ctx,"Saved → $filename")
        } catch(e:Exception){ toast(ctx,"Save failed: ${e.message}") }
    }

    private fun removeAllWindows(){
        listOf(trainerWin,controllerWin,topBarWin,stopWin,captureWin,radialWin,mainMenuWin).forEach{
            it?.let{ v-> try{ wm?.removeView(v) } catch(_:Exception){} }
        }
        trainerWin=null;controllerWin=null;topBarWin=null;stopWin=null
        captureWin=null;radialWin=null;mainMenuWin=null
    }

    private fun nextIndex(ctx:Context,vararg prefixes:String):Int{
        val dir=ctx.getExternalFilesDir(null)?:return 1; var max=0
        val pat=Regex("(${prefixes.joinToString("|")})_(\\d+)\\.txt")
        dir.listFiles()?.forEach{ f-> pat.find(f.name)?.groupValues?.get(2)?.toIntOrNull()?.let{ if(it>max) max=it } }
        return max+1
    }
}
